extends Node
## LD-01/LD-03 regression: the title screen's fresh world must never overwrite real progress.
## Runs on the unfixed baseline too (falls back to show_welcome), so it separates before/after.
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func wipe() -> void:
	for path in [SaveManager.SAVE_PATH,SaveManager.SAVE_PATH+".bak",SaveManager.SAVE_PATH+".tmp"]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
func disk_wood(path: String) -> Variant:
	return SaveManager._read_candidate(path).get("inventory",{}).get("wood")
func freeze() -> void:
	world.set_process(false)
	world.player.set_physics_process(false)
	world.family.set_process(false)
	world.family.member.set_physics_process(false)
	world.clock.set_process(false)
	world.trader.set_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
func reload() -> void:
	# A page reload restarts autoloads; reproduce their fresh state before the new world exists.
	if is_instance_valid(world):
		remove_child(world)
		world.free()
	get_tree().paused = false
	InventorySystem.restore({})
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	freeze()
	await get_tree().process_frame
func title() -> void:
	# Same entry the non-headless game uses at startup.
	if world.has_method("open_title"): world.call("open_title")
	else: world.hud.call_deferred("show_welcome")
	await get_tree().process_frame
	await get_tree().process_frame
func press(text: String) -> bool:
	for button in world.hud.content.find_children("*","Button",true,false):
		if button.text==text:
			button.pressed.emit()
			return true
	return false
func backgrounded() -> void:
	world._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("run")
func run() -> void:
	wipe()
	await reload()
	InventorySystem.restore({"wood":17,"stone":5,"food":3})
	world.picked["s01_loot_00"] = true
	expect(SaveManager.save_world(world) and SaveManager.save_world(world),"Seed: real progress saved to primary and backup")
	expect(disk_wood(SaveManager.SAVE_PATH)==17.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==17.0,"Seed: both files hold wood 17")
	# Reload; the title screen shows a fresh default world.
	await reload()
	await title()
	expect(world.hud.current_modal=="welcome" and InventorySystem.items["wood"]==0,"Title screen runs a fresh world over an existing save")
	backgrounded()
	backgrounded()
	expect(disk_wood(SaveManager.SAVE_PATH)==17.0,"LD-01: two app/page backgrounds on the title keep the primary save")
	expect(disk_wood(SaveManager.SAVE_PATH+".bak")==17.0,"LD-01: two app/page backgrounds on the title keep the backup save")
	world.autosave_clock = 0
	world._process(0.016)
	expect(disk_wood(SaveManager.SAVE_PATH)==17.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==17.0,"LD-01: an autosave tick on the title writes nothing")
	expect(press("继续本机存档") and world.hud.current_modal=="" and InventorySystem.items["wood"]==17 and world.picked.has("s01_loot_00"),"Continue restores the real progress after backgrounding on the title")
	InventorySystem.add_item("wood",1)
	backgrounded()
	expect(disk_wood(SaveManager.SAVE_PATH)==18.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==17.0,"After continuing, background saves resume and rotate normally")
	# Settings opened over the title then closed still starts a session that can save.
	await reload()
	await title()
	world.hud.show_settings()
	world.hud.close_modal()
	InventorySystem.add_item("stone",2)
	backgrounded()
	expect(world.hud.current_modal=="" and SaveManager._read_candidate(SaveManager.SAVE_PATH).get("inventory",{}).get("stone")==2.0,"Leaving the title through another menu does not block later saves")
	# A brand-new player is not blocked: no save, Enter, then background.
	wipe()
	await reload()
	await title()
	expect(not press("继续本机存档"),"No continue button without a save")
	expect(press("进入灰松郊区") and world.hud.current_modal=="","New player enters the world")
	InventorySystem.add_item("wood",3)
	backgrounded()
	expect(disk_wood(SaveManager.SAVE_PATH)==3.0,"New player's first background save is written")
	# LD-03: a legacy file with a non-string state_id is rejected without a script error.
	var legacy := {"version":1,"state_id":5,"position":[4,0.5,31],"inventory":{"wood":1},"settings":{},"picked":[],"stamina":100}
	expect(not SaveManager.valid_snapshot(legacy),"LD-03: legacy file with numeric state_id is rejected")
	wipe()
	print("RESULT | %d session-guard checks | %d failures" % [checks,failures])
	get_tree().paused = false
	get_tree().quit(1 if failures>0 else 0)
