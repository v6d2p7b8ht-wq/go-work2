# 交付报告 · 末日十州 QA02302 重建版（Claude）

日期：2026-10-17 · 第二阶段测试候选 · **重建版，不是找回的QA02302原件**

本包承接上一版草案（`LastDawn-Claude-QA02301-draft-fix.zip`），没有重做基线调查。改动只涉及验收缺口、LD-02和QA02302-01重建。

## 1. 主要文件

| 文件 | 说明 |
| --- | --- |
| `LastDawn-0.2.3-QA02302-RECONSTRUCTED-Claude-Source.zip` | 完整Godot源码，441个文件，SHA-256 `1fd6197c43b23a91c7b752e9a00f83e055412668ea20bf1bd6e51e9452eb64ca` |
| `SOURCE-MANIFEST.sha256` | 上述ZIP内441个文件逐个的SHA-256 |
| `HANDOFF.md` | 交接说明（也在源码根目录） |
| `docs/` | 七份管理文档：在协作页的QA02301管理副本基础上，追加了“2026-10-17 QA02302重建版”一节（也在源码根目录） |
| `patches/01…03` | 由QA02301 Review源码生成重建版的完整补丁：运行时 / 测试 / 文档 |
| `patches/incremental-from-draft-v1-runtime.patch` | 相对上一版草案的运行时增量，方便已审过草案的人只看变化 |
| `QA02302R_CHANGED_FILES.json` | 5个运行时文件改动前后的SHA-256 |
| `logs/` | 原始日志与`suite-status.json`（含退出码） |
| `tests/`、`tools/` | 新增测试套件，以及字体字形扫描脚本 |
| `SHA256SUMS` | 本交付包内全部文件的校验和 |

**可复现性（已实际执行）：** 在QA02301 Review源码ZIP（`6106610e…908e`）的全新解压目录上用`git apply -p1`依次应用三个补丁，结果与重建版ZIP解压目录`diff -r`完全一致。上一版草案 + 增量补丁，得到的5个运行时文件与重建版逐字节一致。

## 2. 验收要求与证据

“检查项”是`tests/SessionGuardTests.gd`和`tests/FamilyIncapacitationGateTests.gd`中的测试名，结果见`logs/final-from-zip/`。

| 管理方要求 | 实现 | 对应检查项 |
| --- | --- | --- |
| 关闭普通菜单不得隐式授权新会话 | `SurvivalHUD.close_modal()`在`awaiting_session_choice`为true时回到标题页，不清除标志 | “Closing Settings returns to the title and keeps protection”；“After closing Settings, background still leaves both save files unchanged”；“Dismissing the title keeps it open, protected, files unchanged” |
| 只有成功继续或明确开始新游戏才允许保存 | 标志只在`restore_snapshot()`成功或`start_new_session()`时清除；`SaveManager.save_world`在会话未选择时拒绝一切保存 | “A manual save request on the title is refused…”；“Settings' Save button on the title writes nothing”；“Continue restores… without writing”；“After Continue, background saves resume…” |
| 已有存档时开始新游戏需游戏内确认；取消保持两个存档且保持保护 | 新增确认页`new_game_confirm`；取消或关闭确认页回到标题页 | “Start New Game with a save asks for confirmation first”；“background during the confirmation changes nothing”；“Cancel returns to the title; both files unchanged; protection kept”；“closing the confirmation acts as Cancel” |
| 关闭设置、关闭标题页、读档失败都不得静默开始替换会话 | 同上；读档失败留在标题页并显示原因 | “Failed Continue stays on the title and writes nothing”；“Failed Continue shows its reason on the title” |
| 阻止保存时仍在后台切换时清理触控 | `_on_backgrounded()`无论是否保存都执行`reset_touches()`；Web与Android两条路径共用此函数 | “Background on the title still clears touch ownership although saving is blocked” |
| 删除接受“设置关闭绕过”的旧回归，改为证明两个存档不变 | 旧检查“Leaving the title through another menu does not block later saves”已删除；新检查对主档和备份逐字节比较 | 见上 |
| 保留LD-03 | 保留 | “LD-03: legacy file with numeric state_id is rejected” |
| 重建QA02302失能门禁 | `FamilyQuest.wait_here`/`claim_reward`加存活检查；`QuestMenus`三个按钮在失能时禁用 | `FamilyIncapacitationGateTests` 11项 |

明确开始新游戏后才允许替换存档，这一点也有正向检查：“confirmed Start New Game begins a fresh session”，以及“only after confirmation does saving replace the primary (backup keeps prior progress)”。没有存档的新玩家仍可直接进入，不受阻：“Without a save, the title offers Enter only”；“New player enters without confirmation…”。

## 3. 实际测试结果

环境：云端Linux容器，Godot `4.6.3.stable.official.7d41c59c4`（官方包，SHA-512已核对），headless + `gl_compatibility`。

| # | 对象 | 命令 | 退出码 | 结果 | 日志 |
| --- | --- | --- | --- | --- | --- |
| 1 | 原QA02301（对照，沿用上一轮） | `bash tests/run_phase2_complete.sh` | 0 | 806 / 0失败；9静态 / 0失败 | `logs/baseline-qa02301/` |
| 2 | 原QA02301 + 新套件 | `python3 tests/run_qa_suite.py SessionGuardTests` | 1 | 24项中18项失败，另有1条SCRIPT ERROR | `logs/cmp-orig/` |
| 3 | 同上 | `… FamilyIncapacitationGateTests` | 1 | 11项中5项失败 | `logs/cmp-orig/` |
| 4 | 上一版草案 + 新套件 | `… SessionGuardTests` | 1 | 24项中16项失败（含设置关闭绕过、阻止保存时不清理触控） | `logs/cmp-draft1/` |
| 5 | 上一版草案 + 新套件 | `… FamilyIncapacitationGateTests` | 1 | 11项中5项失败（草案未含门禁） | `logs/cmp-draft1/` |
| 6 | **重建版ZIP全新解压**（全新导入） | `bash tests/run_phase2_complete.sh` | **0** | **841引擎 / 0失败**（17+20+40+53+33+34+24+29+31+26+24+19+7+449+24+11）；**9静态 / 0失败** | `logs/final-from-zip/` |
| 7 | 运行时字形扫描（scripts/systems/ui） | `godot --headless --script tools/runtime_glyph_scan.gd` | 0 | 没有缺失字形 | `logs/glyph-scan-final.log` |

说明：

- 第6组`run.log`首行记录了被测ZIP的SHA-256，与第1节一致。
- 第6组的`import`条目中有4条字体缓存ERROR，是已知的首次导入问题（QA02302报告列为P3）；`import-second`为exit 0且无错误。
- 开发过程中，全套测试曾因确认页文案使用了内嵌字体缺少的字（之改手将题首）而失败1项（`PerformanceTests`字形检查）。已改写文案，并新增扫描覆盖全部运行时脚本，第7组为最终结果。

## 4. 剩余限制

1. **没有Web导出，没有运行浏览器自动化，没有真机测试。** Web的`visibilitychange`路径与引擎内已测的Android暂停路径共用`_on_backgrounded()`，但没有在浏览器中实际执行。
2. 浏览器脚本中，在已有存档的档案上点击“进入灰松郊区”的流程，需要改为“开始新游戏”→“确认开始新游戏”。本轮没有修改浏览器脚本，因为无法运行验证。
3. 标题页的×按钮现在不做任何事（标题页不可关闭），需要真机确认体验是否可以接受。
4. QA02302原有的`PhaseTwoFlowTests`（8项）和浏览器脚本修正无法从报告还原，本包用自己的测试代替，检查项不一一对应。
5. LD-04（Web切后台写入的存档在页面重新可见前不会同步到IndexedDB）、LD-05（玩家可建墙围住小雨）仍待验证或属范围外，未改动。
6. 没有构建APK，没有部署，没有新增玩法，没有进入第三阶段，没有操作GitHub。

## 5. 回退

- 运行时：在源码目录执行`patch -R -p1 < docs/QA02302R-runtime.patch`；或在上一级目录对`patches/01…`执行`git apply -R -p1`。
- 整体：改用QA02301 Review源码ZIP。
- 存档格式没有变化（schema 3），双向读取都不受影响。
