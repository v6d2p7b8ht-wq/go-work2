# 当前架构 / 0.2.3-test接收记录

2026-10-16。基于源码静态审计；旧0.2.2架构记录保存在docs/management/history-v01/ARCHITECTURE.md。53个GDScript、15场景，Godot4.6.3，入口Main.tscn由WorldManager程序化装配。

原玩家/相机/触屏/生存/感染者七脚本与0.2.2保持一致。四个autoload仍为GraphicsManager、PerformanceDiagnostics、InventorySystem、SaveManager。Android Mobile与Web Compatibility渲染覆盖保留。

新增模块：BuildingSystem管理三类设施预览/合法性/碰撞/成本/记录；InventorySystem保留计数API并用24格堆叠与原子transact；HarvestFeedback固定池视觉/音效、CharacterVisual挥动；TradingSystem双边库存/300秒补货；InfectionSystem从infection_zones.json定义当前1/2/3级与噪声倍率；WorldClock推进昼夜/天气；FamilyQuest和FamilyCompanion管理单NPC跟随/等待/撤离/一次奖励；ActorLOD和建造LOD减少远景细节。新UI使用BuildingMenus、TradingMenus、QuestMenus，不新增触摸路径。

SaveManager schema3读取1/2/3，phase2交PhaseTwoSave校验，包含content_revision1、buildings/trader/environment/family；快照/恢复分模块。瞬时路径/预览不回放。测试profile LastDawnPhase2Test，Android org.lastdawn.tenstates.phase2test，Web持久挂载/userfs/LastDawnPhase2Test，与稳定版数据隔离。旧档兼容指副本导入，不是自动跨应用搬移。

架构风险：PhaseTwoSave对schema3缺模块/字段采用默认值，可能误接纳损坏档并清进度（SAVE-023-01，见审计）；WorldManager仍为装配/交互/保存门面；内容ID和地图修订依赖schema边界，新州和资源ID变化须提供迁移。不得简单放松校验。

政府/通用居民/完整职业/多州加载/驾驶/科技装备尚未实现。新增商人及单名家庭任务是有限原型。完整运行/设备表现未在本轮重测；原生测试包独立ID不需要覆盖旧APK，但稳定应用升级签名问题仍未关闭。


## 2026-10-16 项目总监独立接收复核
当前仍为第二阶段 0.2.3-test / QA02301 测试候选。复核 ZIP CRC 与清单 519 个文件哈希一致；现有运行时代码仅修改 PhaseTwoSave、SaveManager、WorldManager。接收方重跑 9 项静态检查通过；806 项引擎及 59 项浏览器通过属于已核对的交付日志，接收方无 Godot/Chromium，未独立重跑。未收到 APK/Web 二进制，未进行手机验收。
下一任务 QA-023-02：取得匹配清单的测试 APK/Web 包，核验哈希，准备独立测试入口；保留现有线上版本，正式切换另行批准。备份测试进度后完成 Android/iPhone 的建造、交易、撤离、重复读取和后台返回验收。进入第三阶段前须解决阻断缺陷，并完成双平台核心路线及存储生命周期、持续性能验收。GitHub继续暂缓。


## 2026-10-17 QA02302重建版（Claude，非原件）
QA02302原始源码、补丁、日志均未取得，本节记录的是在QA02301 Review源码（SHA-256 `6106610e…908e`）上重建的版本，不是找回的QA02302原件，也不能用QA02302报告中的PCK哈希`b838c862…a041`核对。仍处第二阶段测试候选，未构建APK，未部署，未进入第三阶段。
- WorldManager新增会话状态`awaiting_session_choice`：`open_title()`置位；`restore_snapshot()`成功或`start_new_session()`清除。`can_autosave()`统一控制45秒自动保存与后台保存；`_on_backgrounded()`合并Web visibilitychange与Android暂停两条路径，保存受控，触控清理始终执行。
- SaveManager.save_world在会话未选择时拒绝写入，覆盖手动保存与快捷键。存档格式仍为schema 3，无字段变化。
- SurvivalHUD：`close_modal()`在未选择会话时返回标题；新增`confirm_new_game()`、`start_new_game()`。
- FamilyQuest.wait_here/claim_reward增加存活检查；QuestMenus按存活状态禁用按钮。
