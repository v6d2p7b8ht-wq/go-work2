# 原创与第三方资源

## 原创部分

本工程 GDScript、场景构建、界面、图标、材质纹理与风声均为本任务中编写或程序生成。没有下载他人车辆、建筑、人物模型，也没有使用不明来源的音效或品牌素材。`tests/generate_assets.py` 记录了可复现的纹理 / 风声生成过程。

项目所有者可继续使用、修改和开发这些原创成果。未来引入的新资源应单独记录来源及授权。

## 字体

`assets/fonts/LastDawnSans.ttf` 是 **Noto Sans CJK SC Regular** 的字形子集，已改名为 Last Dawn Sans，仅保留本原型用到的字形以减小体积。原字体遵循 SIL Open Font License 1.1。完整声明随 `assets/fonts/Noto-LICENSE.txt` 提供。该许可允许随软件再分发与修改，但字体自身须保留相应许可。字体不改变本游戏其他原创内容的许可。

## 引擎

Godot Engine 使用 MIT 许可，版权属于 Godot contributors 以及 Juan Linietsky、Ariel Manzur。见 `assets/Godot-LICENSE.txt`、`assets/Godot-THIRD-PARTY.json` 和官方 https://godotengine.org/license/ 。第三方清单由实际使用的 Godot 二进制 `Engine.get_license_info()` / `get_copyright_info()` 导出，可能包含编辑器专用依赖，保留其声明以便审计。

Android / Web 引擎运行时包含各自的 Godot 第三方组件；不把引擎、SDK 或字体称为本项目原创。APK 是标准调试签名，本工程不提供正式发行私钥。

新增 assets/audio/chop.wav / mine.wav 为本次原创合成的 22,050 Hz 单声道采集音效；没有外部采样。tests/generate_harvest_audio.py 仅重建这两种音效，不修改原有材质或风声。
