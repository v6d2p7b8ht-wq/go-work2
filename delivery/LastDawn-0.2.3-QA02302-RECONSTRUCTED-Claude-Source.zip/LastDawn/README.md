# ⚠ QA02302 重建版（Claude，2026-10-17）— 不是QA02302原件

本源码在QA02301 Review源码（SHA-256 `6106610ec0297176f28146afc52bc88dee15ac2e8776134df6ff92f3e853908e`）上重建，QA02302原始源码已遗失，未能找回。内部版本号仍为`0.2.3-test`；Android包名、用户目录`LastDawnPhase2Test`和存档schema 3都不变。改动、测试和边界见[HANDOFF.md](HANDOFF.md)。未构建APK，未部署，未进入第三阶段。

---

# 末日十州 · QA-023-01 存档完整性修复候选

本轮基于已交付0.2.3-test做存档校验修复，不新增玩法，不进入第三阶段。开发目录 `/workspace/qa-023-01/work/LastDawn`；原始工程、ZIP、v0.2.2与历史记录保留。

**本轮没有上线或操作GitHub。现有线上0.2.3网址仍是原版本，不含这次修复。** 下方历史功能/操作说明继续适用；本轮实际结果以 [QA报告](docs/QA02301_REPORT.md)、[测试计划](TEST_PLAN.md)、[决策](DECISIONS.md)、[任务记录](CODEX_TASKS.md)和PROGRESS最后条目为准，不能沿用历史357/137记录。

交付文件添加QA02301后缀：完整源码ZIP、Web导出ZIP、Android Debug APK、最小运行时代码差异和本轮日志ZIP。应用内部仍标0.2.3-test / versionCode5，构建以SHA-256和QA任务标识区分，尚未晋升稳定版。`export/build.sh`仍输出原固定构建文件名，交付打包时另存QA02301副本，不覆盖旧文件。

Android包名仍为 `org.lastdawn.tenstates.phase2test`，用户目录仍为 `LastDawnPhase2Test`。本轮没有向手机安装或写入存档；手动安装会针对原测试应用，须先备份自己的测试进度。稳定版独立应用和入口保持。iPhone需要把本轮WebZIP独立托管后再打开；不能在文件App直接运行ZIP，也不能用旧线上入口验收本轮修复。

开发者复现：

```sh
QA_LOG_ROOT=/tmp/qa023-new-logs QA_PROFILE_ROOT=/tmp/qa023-new-users bash tests/run_phase2_complete.sh
bash export/build.sh
python3 -m http.server 8783 --bind 127.0.0.1 --directory export/web-static
# 在另一个终端，用未使用过的浏览器档案目录：
QA_BROWSER_OUTPUT=/tmp/qa023-browser-logs QA_BROWSER_PROFILE=/tmp/qa023-browser-profile python3 tests/phase2_complete_browser.py http://127.0.0.1:8783/
```

脚本保留每套退出码与错误，外置新日志避免覆盖历史。手机真机/系统强杀/温升/90或120FPS未验证。原始README完整保存在 `docs/README_023_ORIGINAL.md`。

---

# 原0.2.3功能与操作说明

Godot **4.6.3 stable / GDScript**。第一阶段 + 第二阶段核心玩法已在独立开发副本中实现，尚未开始第三阶段。手机直接使用实际交付的测试入口或 APK，不需要电脑、Godot 或 GitHub。

本次开发目录为 `/workspace/last-dawn-phase2-dev`。原工程 `/workspace/last-dawn-ten-states`、v0.2.2 工程 / Web / APK 与网站稳定文件完整保留。最新发布结果以交付消息和构建清单为准；不虚构网址或手机测试。

## 手机开始游戏

- iPhone：使用 iOS 16.4+ 的 Safari 打开交付的**独立测试入口**，建议横屏，点「开始生存」和「进入灰松郊区」。不能在「文件」App 中直接打开 Web ZIP 运行。
- Android：下载 `LastDawn-0.2.3-phase2-test-arm64.apk`，在「文件」中点开安装。名称为「末日十州·阶段二测试」，应用 ID `org.lastdawn.tenstates.phase2test`，可以与稳定版并存。需要 ARM64 / Android 7+ 与 Mobile 渲染器所需 Vulkan；不声称已在你的手机上安装测试。
- 测试版使用独立的 `LastDawnPhase2Test` 存档 / 设置目录；Web 挂载也隔离。**稳定版旧进度留在原入口，测试版不自动搬移旧档。** 正常保存后等待数秒再退出；清除网页数据、卸载测试应用或换域名会影响测试进度。强制杀掉 Safari 时不能保证最后一次异步写盘。
- 未提供账号密码、API 密钥或付费服务要求。网站保持原有私有访问权限，可能需要当前 ChatGPT 账号登录。

## 现在可以玩什么

保留 200×200 米道路、8 栋建筑、可进入超市、森林 / 山坡 / 岩石、车辆、守望者、安全区、第三人称跑跳、背包、拾取、生存、3 名感染者和原 Safari 视角修复。

新增：

1. **采矿与砍树**：矿石每处五次，树木每棵四次；成功动作有斧 / 镐占位动画、原创音效和短时反馈。耗尽后显示和碰撞一起移除，读档不会重生。采集消耗体力并发出声音。
2. **背包**：24 格自动堆叠；木 / 石 / 矿物 50，食品 / 饮水 10，元件 20，蓝图 1。旧档超容量不丢物，未能容纳的拾取 / 奖励不吞掉。
3. **基础建造**：左侧「建造」选择简易避难所、围墙、篝火，前方预览，交互确认；再点取消退出。场地、碰撞、坡度、道路 / 营地与材料都检查，失败不扣材料。最多 24 个，位置 / 朝向 / ID 与火焰开关保存。
4. **交易**：营地北侧约 (20,23) 的「周」交换食品、饮水、材料、电子元件和虚构装备蓝图；商品列表可手指滑动。真实库存、五分钟补货和双边原子交换，暂停不计时，结果保存。蓝图暂不解锁完整装备系统。
5. **感染区域**：五级模型已定义，当前地图实际有营地一级、城郊 / 森林二级、北部工业区三级；高等级声音传播更远。四 / 五级没有假装已开放，感染者数量仍为三名。
6. **昼夜天气**：20 分钟一昼夜，日期 / 时间保存；晴、云、小雨低成本变化，夜间局部照明。低画质禁雨粒子，中高档最多 24 粒。
7. **家庭撤离**：修车厂西侧约 (9,15) 找小雨，交谈后带她步行进入公共营地深处约 (20,35)，两人相距七米内停留两秒。可等待 / 继续跟随，不穿墙传送。奖励食品2 / 饮水2，仅领取一次；满包保留待领，任务和位置随存档保存。左侧「任务」查看状态和位置。

避难所木8 / 石3、围墙木3 / 石1、篝火木2 / 石2。避难所可进入休息，围墙有碰撞，篝火可交互开关；没有加入复杂燃料、烹饪、战斗或第三阶段科技树。

## 操作与画质

左摇杆移动，右侧空白滑动转向，右下跳跃 / 跑步 / 交互，＋ / − 调距离；顶部背包 / 设置，左侧建造 / 任务。菜单暂停，后台和尺寸变化清理触摸状态。灵敏度、反转与触控调试保留。

极低 / 低 / 中 / 高 / 极致和 30 / 45 / 60 / 90 / 120 上限保留；Web 默认低 / 30，120 为实验性，60 模式可选。设置 → 性能诊断显示实测 Engine FPS、平均 / 1% Low / ms、渲染器、平台与可用信息。选择上限不保证达到，Web 屏幕 Hz 仍不能可靠获取。没有强行解除 Safari 限制。

## 开发与证据

[完整批次说明](docs/PHASE2_COMPLETE.md)、[实际测试与待真机项目](tests/PHASE2_COMPLETE_RESULTS.md)、[开发进度](PROGRESS.md)。历史 v0.2.2 报告仍在 docs 与 tests 中，不能当作新版本真机结论。

模块包括 BuildingSystem / HarvestFeedback / TradingSystem / InfectionSystem / WorldClock / FamilyQuest / FamilyCompanion / ActorLOD / PhaseTwoSave，以及对应 UI 文件。原玩家、相机、触摸、基础生存和丧尸 AI 脚本保持 v0.2.2 字节一致；现有自动化测试保留，旧档预期升级到 schema 3，v1 / v2 夹具继续验证。

开发者在具备工具的云端运行 `bash tests/run_phase2_complete.sh`、`bash export/build.sh`。Android Mobile / Web Compatibility 平台覆盖未改变。Web 静态托管与纯手机上传步骤见 [export/DEPLOY.md](export/DEPLOY.md)。玩家不需要执行这些命令。

没有 Android / iPhone 真机、真实 GPU、温升、长时间 Safari 内存压力或弱网结果。源工程含原始日志与实际浏览器截图，不用云端软件 WebGL FPS 推断手机能力。新州、职业、政府 AI、完整装备系统等第三阶段内容没有开发；先完成真机验收再评估下一阶段。

代码与资源许可见 [LICENSES.md](LICENSES.md)。新增采集音效是原创合成 WAV，字体为原 Noto OFL 子集的扩充。
