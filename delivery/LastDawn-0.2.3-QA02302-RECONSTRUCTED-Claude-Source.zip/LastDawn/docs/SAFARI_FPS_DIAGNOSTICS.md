# Safari 120 FPS 专项排查 · 0.2.1

## 结论与证据边界

未发现项目里给 Safari 固定 60 FPS 的代码。120 选项确实设置 `Engine.max_fps = 120`；改画质仍保留 120，刷新后从 ConfigFile 读取 120。读世界存档时会恢复该存档里的帧率设置：若旧档保存的是 60，这是明确的读档恢复行为，诊断中的“目标 / 引擎上限”会反映它。

已确认的 Web 引擎约束是：Godot 4.6.3 的单线程 Web 主循环受浏览器动画帧调度。把引擎上限设置为 120，无法让只发出约 60 次/秒 rAF 的浏览器多提供回调。尚无用户 iPhone 的型号、iOS 版本或实测 rAF，因此**不能断言该机一定被 Safari 限 60，也不能断言 GPU 不够**。

此版本加入可在手机上直接读取的诊断与轻量 rAF 对照页，不更换引擎，不重复提交画面制造计数，不把屏幕支持 120Hz 当作网页一定支持 120FPS。

| 路径 | 已确认事实 | 证据 |
| --- | --- | --- |
| GraphicsManager | 30 / 45 / 60 / 90 / 120 均写入 Engine.max_fps；切画质不重置 | PerformanceTests + 真实导出 GUI 测试 |
| 启动 / 恢复 | Web 新用户低画质 / 30；仅 Android 初始硬件启发式可选 60；读设置覆盖初值，读档恢复存档里的目标 | 全赋值检索、原玩法回归 |
| VSync | 原来在 Web 调用 VSYNC_DISABLED 无效；此次仅跳过该空调用，原生策略保留 | 上游 display_server_web.h setter 空实现，cpp getter 固定 enabled |
| 屏幕刷新率 | Web getter 返回 SCREEN_REFRESH_RATE_FALLBACK，不能当作 iPhone 实测 Hz | 上游 display_server_web.cpp |
| 物理 / FPS | 物理保持 60Hz，独立于渲染；原 HUD 持续使用 Engine.get_frames_per_second() | project.godot / HUD / 测试 |
| 渲染瓶颈 | rAF 和游戏帧间隔可测；没有可靠的跨平台 GPU 专用耗时，不能仅据 FPS 判定 GPU 瓶颈 | 新诊断明确标注边界 |

## 上游源码核查

核查本工程实际引擎 **Godot 4.6.3 stable / 7d41c59c4** 对应版本，而非别的 Godot 分支：

- [web_main.cpp](https://github.com/godotengine/godot/blob/4.6.3-stable/platform/web/web_main.cpp#L75)：`main_loop_callback` 读取 `Engine::get_singleton()->get_max_fps()`，增加目标 ticks，回调提前则跳过；启动调用 `emscripten_set_main_loop(main_loop_callback, -1, false)`。没有硬编码的 60 上限。
- [Emscripten main loop API](https://emscripten.org/docs/api_reference/emscripten.h.html#c.emscripten_set_main_loop)：fps <= 0 时用浏览器 requestAnimationFrame。此 API 的浏览器调度能力不是引擎参数能保证的。
- [display_server_web.h](https://github.com/godotengine/godot/blob/4.6.3-stable/platform/web/display_server_web.h#L279)：`window_set_vsync_mode(...) override {}`。
- [display_server_web.cpp](https://github.com/godotengine/godot/blob/4.6.3-stable/platform/web/display_server_web.cpp#L1291)：`screen_get_refresh_rate()` 返回回退值；1458 行 VSync getter 返回 VSYNC_ENABLED。

实际导出的 Emscripten 4.0.20 `index.js` 也核对过：真实 rAF 可用时调用 `requestAnimationFrame`。其中 `fakeRequestAnimationFrame` 的 60Hz 只是缺少该 API 时的后备路径；没有证据表明用户 Safari 在走此路径，未删除引擎后备分支。

以上公开源码链接仅为核查依据，玩家下载、游玩与交付不需要 GitHub 账号。

## 关键修改

```diff
 # GraphicsManager.apply
 Engine.max_fps = target_fps
-if DisplayServer.get_name() != "headless":
+if not OS.has_feature("web") and DisplayServer.get_name() != "headless":
     DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
```

- 新增 `systems/FrameTimeWindow.gd`：真实墙钟间隔的约 10 秒窗口，上限 2400 个间隔。
- 新增 `systems/PerformanceDiagnostics.gd`：`RenderingServer.frame_post_draw` 计时，每 0.5 秒汇总；记录最近游戏窗口，菜单统计单独标注；失焦、后台与相关设置变化清空基线。
- `ui/SurvivalHUD.gd`：设置内新增实时读数及性能诊断页，Web `120*` 实验标记、60 稳定模式。原 FPS 标签继续用实际 Engine FPS。
- 新增 `export/performance_probe.js`：独立 rAF 计数，不更改引擎 main loop，不监听或产生触屏输入。
- 新增 `export/fps-probe.html`：不加载 Godot 的轻量对照页，实际识别标签页 / 主屏幕模式。无法可靠获取的屏幕 Hz、电源限制返回 null。
- `export/web_shell.html` 只引入监测脚本、启动采样重置、版本说明与诊断链接；原 Canvas 尺寸、DPR、输入生命周期和 Safari 手势处理块完全保留。
- `project.godot` 注册诊断 autoload，版本 0.2.1；`export_presets.cfg` Android versionCode 3；`export/prepare_web.py` 打包必要 JS / HTML。
- `assets/fonts/LastDawnSans.ttf` 补充诊断所需中文字形，`tests/update_ui_font.py` 仅更新字体子集，不重新生成地图美术或音频。
- 测试、文档、PROGRESS / README 更新；完整差异见同目录 `SAFARI_FPS_DIAGNOSTICS.patch`。

`TouchInputManager.gd`、`MobileControls.gd`、`CameraController.gd`、`TouchDebugPanel.gd` 的 SHA-256 与本次修改前相同。地图、玩家、生存、感染者、资源、背包、存档模块未改写。

## 如何读取统计

- **目标 FPS / 引擎上限**是用户要求与实际应用的 cap，两者不等于设备已达到该 FPS。
- **引擎实测 FPS**来自 Engine.get_frames_per_second()。
- **实际平均 FPS** = 1000 / 平均渲染提交间隔 ms；这是引擎提交节奏，无法证明物理屏幕呈现次数。
- **1% Low** = 1000 / 最慢 `ceil(间隔数 × 1%)` 个间隔的平均 ms，至少 100 个间隔、3 秒后显示。不是百分位帧时间的另一种混用，也不平均每帧瞬时 FPS。
- 采样采用单调墙钟，不使用物理 tick、目标值、游戏 time_scale 或累计 delta。合法前台卡顿保留在样本里，后台 / 失焦后的长间隙重新开始采样。
- 设置菜单暂停游戏逻辑，菜单 FPS 可比游戏更高。先返回游戏走动 15 秒，再进设置 → 性能诊断读“上次游戏窗口”。改画质或 cap 后需要重新游玩采样。
- rAF 回调也可能被主线程或 GPU 背压拖慢。轻量页应独立打开、保持前台，不与游戏同时作为两个前台负载比较。
- Android 原生刷新率仅在系统返回有效正数时显示，仍不能保证达到。Web 始终明确显示“浏览器无法可靠获取”。

## iPhone 手动验收（尚待真机）

1. 用同一 Safari 网站打开 0.2.1，记录机型、iOS 版本。去 Apple 规格页核对是否支持 ProMotion；浏览器 UA 不可靠地给出具体 iPhone 型号。确认设备已降温，不在低电量模式；在「设置 → 辅助功能 → 动态效果 → 限制帧速率」检查是否开启（只在相关机型上出现）。不要求关闭所有系统限制。
2. 选择极低画质 / 60，关闭菜单走动 15 秒；重新打开设置 → 性能诊断，记录上次游戏窗口、引擎实测、平均 / 1% Low / ms、rAF、平台 / 渲染器 / 运行方式。
3. 选择 120*，确认“目标 120 / 引擎上限 120”，返回同一地点按相同路线游玩至少 15 秒。再记录同一组指标。不要用菜单 FPS 代替游戏 FPS。
4. 在轻量 rAF 对照页保持前台 15 秒，记录回调频率、平均间隔、运行方式。可以显示 JSON 后长按复制，不会自动上传设备信息。若游戏内新标签被 Safari 拦截，使用加载页面或交付报告的普通链接。
5. 在普通 Safari 标签页与「添加到主屏幕」启动方式分别做同样对照；主屏幕模式不保证更高刷新率。记录实际显示的运行方式，不能把普通书签误当 Web App。非 standalone 只能说明没有报告独立模式，不能自动识别所有内嵌 WebView；请从 Safari 直接打开。
6. 若轻量页也约 60：证据指向当前浏览器 / 系统 / 设备组合的轻载调度上限，仍需机型、系统电源与限帧设置区分，不归因 GPU。若轻量页 >100 而游戏只有约 60：比较极低与高画质；降低画质显著提升才支持存在渲染负载影响，但 CPU / GPU 具体归因仍需性能分析，不能据此确定 GPU。
7. 改画质、刷新页面、切后台再回来，确认目标与引擎上限仍正确；读旧存档后目标按该存档恢复。切后台回来 / 横竖屏后统计先重新预热，不把后台等待算作低帧。
8. 验证左摇杆 + 右视角、两指交替松手、设置按钮、地址栏变化、横竖屏与 App 切换，确认视角仍稳定。没有 iPhone 真机，此项未宣称通过。

提交结果可用：机型 / iOS / 模式 / 电源设置 / 目标 / 引擎上限 / 上次游戏平均、1% Low、ms / rAF / 轻量页 rAF。若稳定 60 更合适，可随时切回 60；安卓原生保留 90 / 120 等待对应真机测量。
