# 导出与手机托管说明

## 已经构建的文件

- Android：`LastDawn-0.2.3-phase2-test-arm64.apk`，64 位 ARM 原型调试包，实际结果以 `tests/PHASE2_COMPLETE_RESULTS.md` 为准。
- Web：`LastDawn-Web-0.2.3-Phase2-Test.zip`，真实 Godot Web 导出及流式 gzip 加载器。解压根目录必须直接包含 `index.html`、`index.js`、`index.pck`、`index.wasm.gz`、`wasm-loader.js`、音频 worklet 和图标。
- 工程：`LastDawn-0.2.3-Phase2-Test-Source.zip`，包含源码、资源、导出配置、说明和自动化测试；不重复放入大型 SDK、Godot 安装程序和已导出的二进制。

## 仅用手机部署备用 Web 包

若交付消息已有确认可用的游戏网址，直接打开该网址即可，不必自行托管。以下是备用路径；不需要 GitHub，也不需要把任何密码或密钥交给开发助手。

以支持 **Direct Upload** 的 Cloudflare Pages 为例：

1. 在 Safari 或安卓浏览器中访问 Cloudflare 官方网站，用你自己的邮箱自行创建 / 登录账号。可切换「请求桌面网站」显示完整控制台。
2. 进入 Workers & Pages，创建 Pages 项目，选择直接上传静态文件 / Direct Upload，不选择连接 Git。
3. 从手机「文件」选择 `LastDawn-Web-0.2.3-Phase2-Test.zip` 上传，确认预览根目录有 `index.html`，执行部署。
4. 只使用控制台**实际返回**的 HTTPS 地址，不根据名称猜测网址。用 iPhone Safari 打开并点「开始生存」。
5. 若控制台界面或免费配额变化，可使用其他允许约 10 MiB ZIP、约 37 MiB 解压后 WASM 内存和 WebGL 2 的 HTTPS 静态托管服务。

压缩发布包中最大的实际文件是约 9 MiB 的 `index.wasm.gz`，低于常见的 25 MiB 单文件上限。加载器在浏览器内解压成原始 Godot WASM，因此不需要服务器设置 Content-Encoding，也不要删除 `wasm-loader.js`。需要 Safari iOS 16.4+。原始未压缩的 `index.wasm` 则约 36 MiB，若自行直接上传原始导出，要核实托管的单文件限制。

ZIP 在 iPhone 的「文件」App 内不是可运行的游戏。必须上传全部文件并通过 HTTPS 网站打开；请不要只上传 HTML，或将它放进会再嵌套一层目录的托管根目录。

## Web 配置

- Godot `renderer/rendering_method.web = gl_compatibility`。
- `variant/thread_support=false`、`variant/extensions_support=false`，不依赖 SharedArrayBuffer。
- 静态包无需 COOP / COEP。正式托管应将 `.js` 作为 JavaScript，`.pck` 作为二进制；压缩加载器返回 `application/wasm` 给引擎。
- HTML 使用 `viewport-fit=cover`、CSS `env(safe-area-inset-*)`、画布尺寸监听、1.5 像素比上限，以及独立触摸输入。
- `user://` 由 Godot Web 文件系统持久化到浏览器 IndexedDB。HTTPS 来源 / 域名不同就是不同存档，浏览器隐私策略可能影响持久化。
- 网页未使用远程素材、第三方 CDN、登录 SDK、追踪统计或外部 API。若通过 Sites 托管，平台私有访问验证属于托管层。
- 本阶段不启用离线 PWA；资源首次需联网。添加到主屏幕不代表断网可启动。

## 云端重新构建（供维护者使用）

使用匹配的 Godot 4.6.3 二进制和导出模板。Android 使用官方内置 APK 模板，不启用 Gradle，不需要下载 NDK。当前模板实际采用 minSdk 24、targetSdk 36；本次成功构建使用 Java 21 与 Android SDK build-tools 36.0.0 / platform 36。若 Godot 导出模板版本变化，请按该版本要求重新验证。

在 Godot 编辑器设置中配置 `export/android/java_sdk_path` 和 `export/android/android_sdk_path`。这些是当前机器的路径，不应硬编码进可移植工程。Godot 会使用本机标准调试签名；正式发行需由项目所有者在自己的环境中管理签名密钥，本工程不包含发布密钥。

```sh
godot --headless --rendering-method gl_compatibility --path . --editor --import
godot --headless --rendering-method gl_compatibility --path . --export-debug "Android Debug"
python3 export/finalize_android.py --sdk /你的/Android/Sdk
godot --headless --rendering-method gl_compatibility --path . --export-release "iPhone Safari Web"
python3 export/prepare_web.py
```

上面给编辑器进程选择 Compatibility，只为无图形云端构建，不修改导出项目的 Android Mobile 平台设置。构建前后均检查 `project.godot` 与实际导出日志。

4.6.3 官方 APK 模板中存在缺失的 themed-icon XML 引用，本次导出后用 `finalize_android.py` 补充已有图标 XML、重新对齐并用相同 Debug 密钥签名。它只操作 Debug 包，不创建或读取正式发行密钥；默认从本机 Godot 编辑器配置选择 SDK / Debug 密钥路径，也可显式传 `--sdk`、`--keystore`。不能把修补前的旧 `.idsig` 与修补后的 APK 一起使用，本次不交付 `.idsig`。

普通 Linux 开发预览可对 `export/web-static` 启动 HTTP 静态服务器；`localhost` 是浏览器安全来源例外，手机访问外网应使用 HTTPS。不要把云端进程的临时端口当作永久游戏网址。

测试版必须保留 project.godot 的 LastDawnPhase2Test 自定义用户目录，以及 Shell 的 /userfs/LastDawnPhase2Test persistentPaths。不要改回稳定版挂载；否则可能混用设置 / 存档。Android 独立包 ID 也应保留。
