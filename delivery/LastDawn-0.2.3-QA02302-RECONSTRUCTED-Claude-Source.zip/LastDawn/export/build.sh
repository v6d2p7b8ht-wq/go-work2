#!/usr/bin/env bash
# Developer/cloud build convenience. Players install the supplied APK or open the hosted Web version.
set -eu
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
godot --headless --rendering-method gl_compatibility --path "$project_dir" --editor --import
godot --headless --rendering-method gl_compatibility --path "$project_dir" --export-debug "Android Debug"
python3 "$project_dir/export/finalize_android.py"
godot --headless --rendering-method gl_compatibility --path "$project_dir" --export-release "iPhone Safari Web"
python3 "$project_dir/export/prepare_web.py"
