#!/usr/bin/env python3
"""Repair a missing themed-icon XML reference in the official 4.6.3 APK template.
Only modifies debug exports; then re-aligns and re-signs with the local standard debug key.
No release key or password is stored in the project. No changes to native/game code.
"""
from pathlib import Path
import argparse
import os
import re
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--apk', type=Path)
parser.add_argument('--sdk', type=Path)
parser.add_argument('--keystore', type=Path)
args = parser.parse_args()
if args.apk is None:
    preset = re.search(r'^export_path="([^"\n]+\.apk)"', (ROOT/'export_presets.cfg').read_text(), re.M)
    if not preset:
        raise SystemExit('Pass --apk or configure an Android APK export path.')
    args.apk = ROOT/preset.group(1)
missing = 'res/mipmap-anydpi-v26/themed_icon.xml'
source = 'res/mipmap-anydpi-v26/icon.xml'
with zipfile.ZipFile(args.apk) as archive:
    if missing in archive.namelist():
        print('Themed icon already present; no repair needed.')
        raise SystemExit(0)
    icon = archive.read(source)
sdk = args.sdk
if sdk is None and os.environ.get('LAST_DAWN_ANDROID_SDK'):
    sdk = Path(os.environ['LAST_DAWN_ANDROID_SDK'])
if sdk is None or args.keystore is None:
    for settings in sorted((Path.home()/'.config/godot').glob('editor_settings-*.tres'),reverse=True):
        match = re.search(r'^export/android/android_sdk_path = "([^"]+)"',settings.read_text(),re.M)
        if match and sdk is None:
            sdk = Path(match.group(1))
        key = re.search(r'^export/android/debug_keystore = "([^"]+)"',settings.read_text(),re.M)
        if key and args.keystore is None:
            args.keystore = Path(key.group(1))
        if sdk is not None and args.keystore is not None:
            break
if sdk is None:
    raise SystemExit('Use --sdk or LAST_DAWN_ANDROID_SDK to select Android SDK.')
if args.keystore is None or not args.keystore.is_file():
    raise SystemExit('The local Godot debug keystore was not found; pass --keystore. Never use a release key here.')
tools = sorted((sdk/'build-tools').iterdir(),key=lambda p:tuple(int(n) for n in re.findall(r'\d+',p.name)))
tool = tools[-1]
with tempfile.TemporaryDirectory(prefix='last-dawn-apk-') as temp:
    patched = Path(temp)/'patched.apk'
    aligned = Path(temp)/'aligned.apk'
    shutil.copyfile(args.apk, patched)
    with zipfile.ZipFile(patched, 'a') as archive:
        archive.writestr(missing, icon, compress_type=zipfile.ZIP_DEFLATED)
    subprocess.run([str(tool/'zipalign'),'-f','-P','16','4',str(patched),str(aligned)],check=True)
    subprocess.run([str(tool/'apksigner'),'sign','--ks',str(args.keystore),'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--v4-signing-enabled','false',str(aligned)],check=True)
    subprocess.run([str(tool/'apksigner'),'verify','--verbose',str(aligned)],check=True)
    subprocess.run([str(tool/'zipalign'),'-c','-P','16','4',str(aligned)],check=True)
    shutil.copyfile(aligned,args.apk)
print('Repaired themed-icon reference; debug APK re-aligned (16 KiB) and signature verified.')
