/* Read-only browser scheduler probe; no touch listeners, input synthesis or engine timers. */
(() => {
  'use strict';
  const capacity = 2400;
  let intervals = [], total = 0, previous = null, id = null, reason = 'startup';
  let focused = true, epoch = 0;
  function reset(why = 'manual') { intervals = []; total = 0; previous = null; reason = why; epoch += 1; }
  function active() { return focused && !document.hidden; }
  function tick(timestamp) {
    id = null;
    if (!active()) return;
    if (previous !== null) {
      const ms = timestamp - previous;
      if (Number.isFinite(ms) && ms > 0) {
        intervals.push(ms); total += ms;
        while (intervals.length > 1 && (total > 10000 || intervals.length > capacity)) total -= intervals.shift();
      }
    }
    previous = timestamp;
    id = requestAnimationFrame(tick);
  }
  function reconcile(why) {
    if (id !== null) cancelAnimationFrame(id);
    id = null; reset(why);
    if (active()) id = requestAnimationFrame(tick);
  }
  function sample() {
    const count = intervals.length;
    const mean = count ? total / count : 0;
    const ready = count >= 100 && total >= 3000;
    let low = 0;
    if (ready) {
      const sorted = intervals.slice().sort((a,b) => b-a);
      const n = Math.max(1, Math.ceil(count * .01));
      low = 1000 / (sorted.slice(0,n).reduce((a,b) => a+b,0) / n);
    }
    return {raf:{samples:count, seconds:total/1000, average_fps:mean ? 1000/mean : 0,
      mean_ms:mean, low_1_percent:low, ready}, mode:(navigator.standalone === true ||
      (window.matchMedia && matchMedia('(display-mode: standalone)').matches)) ? '主屏幕 Web App' : '浏览器页面',
      visibility:document.visibilityState, focused, epoch, screen_refresh_hz:null,
      low_power_mode:null, reset_reason:reason, user_agent:navigator.userAgent};
  }
  window.addEventListener('blur', () => { focused = false; reconcile('blur'); });
  window.addEventListener('focus', () => { focused = true; reconcile('focus'); });
  window.addEventListener('pagehide', () => { focused = false; reconcile('pagehide'); });
  window.addEventListener('pageshow', () => { focused = true; reconcile('pageshow'); });
  document.addEventListener('visibilitychange', () => reconcile('visibilitychange'));
  window.LastDawnPerformance = Object.freeze({sample, reset});
  reconcile('startup');
})();
