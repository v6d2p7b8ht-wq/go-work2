#!/usr/bin/env python3
"""Package the genuine Godot export for static hosts with a 25 MiB per-file limit.
WASM stays byte-for-byte identical after streaming gzip decompression in modern browsers.
No server functions, cross-origin isolation, SharedArrayBuffer or third-party CDN are needed.
"""
from pathlib import Path
import argparse
import gzip
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=ROOT/'export/web')
parser.add_argument('--destination', type=Path, default=ROOT/'export/web-static')
args = parser.parse_args()
source = args.source.resolve()
destination = args.destination.resolve()
if source == destination:
    raise SystemExit('Source and destination must differ.')
if not (source/'index.wasm').is_file() or not (source/'index.html').is_file():
    raise SystemExit('Export Godot Web successfully before packaging.')
destination.mkdir(parents=True, exist_ok=True)
# Custom shell dependencies must accompany both the raw and static Web export.
for name in ('performance_probe.js', 'fps-probe.html'):
    shutil.copy2(ROOT/'export'/name, source/name)
# Portable investigation report/evidence, if present in the source checkout.
for name, path in [('fps-diagnostics.html', ROOT/'export/fps-diagnostics.html'),
                   ('SAFARI_FPS_DIAGNOSTICS.patch', ROOT/'docs/SAFARI_FPS_DIAGNOSTICS.patch'),
                   ('FPS_DIAGNOSTICS_RESULTS.json', ROOT/'tests/fps-browser-results/results.json'),
                   ('quality-audit.html', ROOT/'export/quality-audit.html'),
                   ('QUALITY_AUDIT.md', ROOT/'docs/QUALITY_AUDIT.md'),
                   ('QUALITY_INITIAL_REPORT.md', ROOT/'docs/QUALITY_INITIAL_REPORT.md'),
                   ('QUALITY_AUDIT.patch', ROOT/'docs/QUALITY_AUDIT.patch'),
                   ('QUALITY_RESULTS.md', ROOT/'tests/QUALITY_RESULTS.md'),
                   ('QUALITY_RESULTS.json', ROOT/'tests/quality-results/browser/results.json'),
                   ('SAVE_COMPATIBILITY.md', ROOT/'docs/SAVE_COMPATIBILITY.md'),
                   ('phase2-report.html', ROOT/'export/phase2-report.html'),
                   ('PHASE2_COMPLETE.md', ROOT/'docs/PHASE2_COMPLETE.md'),
                   ('PHASE2_COMPLETE.patch', ROOT/'docs/PHASE2_COMPLETE.patch'),
                   ('PHASE2_CHANGED_FILES.json', ROOT/'docs/PHASE2_CHANGED_FILES.json'),
                   ('PHASE2_COMPLETE_RESULTS.md', ROOT/'tests/PHASE2_COMPLETE_RESULTS.md'),
                   ('PHASE2_TEST_SUMMARY.json', ROOT/'tests/phase2-results/summary.json'),
                   ('PHASE2_GAMEPLAY_RESULTS.json', ROOT/'tests/phase2-browser-results/gameplay/results.json'),
                   ('PHASE2_UI_RESULTS.json', ROOT/'tests/phase2-browser-results/ui-final/results.json'),
                   ('PHASE2_PROFILE_ISOLATION.json', ROOT/'tests/phase2-browser-results/isolation/results.json'),
                   ('PHASE2_PACK_SCOPE.json', ROOT/'tests/phase2-results/packed-scope.json')]:
    if path.is_file():
        shutil.copy2(path, source/name)
for path in source.iterdir():
    if path.is_file() and not path.name.startswith('.') and path.suffix not in ('.wasm','.import'):
        shutil.copy2(path, destination/path.name)
binary = (source/'index.wasm').read_bytes()
(destination/'index.wasm.gz').write_bytes(gzip.compress(binary, compresslevel=9, mtime=0))
loader = r'''// Original release WASM, transported compressed. Requires Safari 16.4+ / modern browsers.
(() => {
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input, options) => {
    const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url, location.href);
    if (url.origin !== location.origin || !url.pathname.endsWith('/index.wasm')) return originalFetch(input, options);
    const packedURL = new URL(url.href); packedURL.pathname += '.gz';
    const packed = await originalFetch(packedURL, options);
    if (!packed.ok) throw new Error('引擎下载失败：HTTP ' + packed.status);
    const reader = packed.body.getReader();
    const first = await reader.read();
    const isGzip = first.value && first.value[0] === 31 && first.value[1] === 139;
    if (isGzip && typeof DecompressionStream === 'undefined') throw new Error('请使用 iOS 16.4 或更新版本的 Safari，或更新 Android 浏览器。');
    const stream = new ReadableStream({
      start(controller) { if (!first.done) controller.enqueue(first.value); else controller.close(); },
      async pull(controller) { const chunk = await reader.read(); if (chunk.done) controller.close(); else controller.enqueue(chunk.value); },
      cancel(reason) { return reader.cancel(reason); }
    });
    const decoded = isGzip ? stream.pipeThrough(new DecompressionStream('gzip')) : stream;
    return new Response(decoded, {status:200, headers:{'Content-Type':'application/wasm','Content-Length':'WASM_SIZE'}});
  };
})();
'''.replace('WASM_SIZE',str(len(binary)))
(destination/'wasm-loader.js').write_text(loader,encoding='utf-8')
html=(destination/'index.html').read_text(encoding='utf-8')
html=html.replace('<script src="index.js"></script>','<script src="wasm-loader.js"></script>\n<script src="index.js"></script>')
(destination/'index.html').write_text(html,encoding='utf-8')
(destination/'_headers').write_text('''/*.pck
  Content-Type: application/octet-stream
  Cache-Control: no-cache
/*.js
  Cache-Control: no-cache
/index.wasm.gz
  Content-Type: application/gzip
/index.html
  Cache-Control: no-cache
''',encoding='utf-8')
(destination/'BUILD.json').write_text(json.dumps({'version':'0.2.3-phase2-test','engine':'Godot 4.6.3.stable','rendering':'Compatibility / WebGL2','threads':False,'save_profile':'LastDawnPhase2Test','persistent_mount':'/userfs/LastDawnPhase2Test','wasm_bytes':len(binary),'wasm_gzip_bytes':(destination/'index.wasm.gz').stat().st_size,'requires':'Safari iOS 16.4+ with WebGL2 and DecompressionStream; physical device verification pending'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Static package ready:',destination)
print('WASM:',len(binary),'bytes →',(destination/'index.wasm.gz').stat().st_size,'transfer bytes')
