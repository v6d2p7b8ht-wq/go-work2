class_name Atmosphere
extends Node3D
var sun: DirectionalLight3D
var dust: CPUParticles3D
var wind: AudioStreamPlayer
var environment: Environment
var sky_material: ProceduralSkyMaterial

func _ready() -> void:
	var environment_node := WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	sky_material = ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("647e83")
	sky_material.sky_horizon_color = Color("c6bea1")
	sky_material.ground_bottom_color = Color("313d3c")
	sky_material.ground_horizon_color = Color("b0ae91")
	sky_material.sun_angle_max = 8.0
	sky_material.sun_curve = 0.10
	sky.sky_material = sky_material
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("a6b6b1")
	env.ambient_light_energy = 0.68
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.15
	env.fog_enabled = true
	env.fog_light_color = Color("929f94")
	env.fog_light_energy = 0.7
	env.fog_density = 0.0045
	environment = env
	environment_node.environment = env
	add_child(environment_node)
	sun = DirectionalLight3D.new()
	sun.name = "LateAfternoonSun"
	sun.rotation_degrees = Vector3(-28, -33, 0)
	sun.light_color = Color("ffe0a2")
	sun.light_energy = 1.5
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_blend_splits = true
	sun.shadow_bias = 0.05
	add_child(sun)
	dust = CPUParticles3D.new()
	dust.name = "LowCostDust"
	dust.amount = 40
	dust.lifetime = 9
	dust.preprocess = 2
	dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	dust.emission_box_extents = Vector3(17, 5, 17)
	dust.direction = Vector3(1, 0, -0.3)
	dust.spread = 18
	dust.gravity = Vector3(0.015, -0.025, 0)
	dust.initial_velocity_min = 0.1
	dust.initial_velocity_max = 0.5
	dust.scale_amount_min = 0.025
	dust.scale_amount_max = 0.06
	dust.color = Color(0.7, 0.69, 0.5, 0.6)
	dust.mesh = GeometryFactory.sphere_mesh()
	dust.material_override = GeometryFactory.material("dust", Color("a9a187"))
	dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(dust)
	wind = AudioStreamPlayer.new()
	wind.stream = load("res://assets/wind.ogg")
	if wind.stream is AudioStreamOggVorbis:
		wind.stream.loop = true
	wind.volume_db = -22
	add_child(wind)
	GraphicsManager.settings_changed.connect(apply_quality)
	apply_quality()

func start_audio() -> void:
	if DisplayServer.get_name() != "headless" and not wind.playing:
		wind.play()

func _exit_tree() -> void:
	if is_instance_valid(wind):
		wind.stop()

func apply_quality() -> void:
	var preset := GraphicsManager.preset()
	sun.shadow_enabled = int(preset["shadow"]) > 0
	sun.directional_shadow_max_distance = minf(float(preset["distance"]) * 0.62, 85.0)
	var count: int = preset["particles"]
	dust.emitting = count > 0
	dust.visible = count > 0
	if count > 0:
		dust.amount = count
