class_name CameraController
extends Node3D
const INPUT_CONFIG := "user://camera_input.cfg"
const MIN_PITCH := -1.1
const MAX_PITCH := 0.34
var yaw := 0.0
var pitch := -0.27
var distance := 5.8
var invert_y := false
var touch_debug_enabled := false
var arm: SpringArm3D
var camera: Camera3D

func _ready() -> void:
	_load_input_preferences()
	position.y = 1.4
	arm = SpringArm3D.new()
	arm.collision_mask = 1
	arm.margin = 0.2
	arm.spring_length = distance
	var probe := SphereShape3D.new()
	probe.radius = 0.20
	arm.shape = probe
	add_child(arm)
	if get_parent() is CollisionObject3D:
		arm.add_excluded_object(get_parent().get_rid())
	camera = Camera3D.new()
	camera.current = true
	camera.fov = 72.0
	camera.near = 0.15
	arm.add_child(camera)
	GraphicsManager.settings_changed.connect(_apply_quality)
	_apply_quality()

func orbit(relative: Vector2) -> void:
	if not relative.is_finite():
		return
	# Sensitivity is radians per Godot logical viewport pixel. Never multiply by frame time.
	var sensitivity := clampf(GraphicsManager.sensitivity, 0.001, 0.009)
	yaw = wrapf(yaw - relative.x * sensitivity, -PI, PI)
	var vertical_sign := -1.0 if invert_y else 1.0
	pitch = clampf(pitch - relative.y * sensitivity * vertical_sign, MIN_PITCH, MAX_PITCH)

func set_invert_y(value: bool) -> void:
	invert_y = value
	_save_input_preferences()

func set_touch_debug(value: bool) -> void:
	touch_debug_enabled = value
	_save_input_preferences()

func _load_input_preferences() -> void:
	var config := ConfigFile.new()
	if config.load(INPUT_CONFIG) == OK:
		invert_y = config.get_value("camera", "invert_y", false) == true
		touch_debug_enabled = config.get_value("debug", "touch_panel", false) == true

func _save_input_preferences() -> void:
	var config := ConfigFile.new()
	config.set_value("camera", "invert_y", invert_y)
	config.set_value("debug", "touch_panel", touch_debug_enabled)
	config.save(INPUT_CONFIG)

func zoom(amount: float) -> void:
	distance = clampf(distance + amount, 3.0, 10.0)

func _process(delta: float) -> void:
	rotation = Vector3(pitch, yaw, 0)
	arm.spring_length = lerpf(arm.spring_length, distance, 1.0 - exp(-10.0 * delta))

func _apply_quality() -> void:
	if camera:
		camera.far = float(GraphicsManager.preset()["distance"]) + 25.0
