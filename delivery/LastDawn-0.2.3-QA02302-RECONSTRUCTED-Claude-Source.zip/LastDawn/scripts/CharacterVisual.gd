class_name CharacterVisual
extends Node3D
## Articulated proxy with an animated gait, backpack, clothing and a separate head.
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var phase := 0.0
var infected := false
var harvest_time := 0.0
var harvest_kind := ""
var tool: Node3D
var tool_head: MeshInstance3D

func build(is_infected: bool = false, npc: bool = false) -> void:
	infected = is_infected
	var coat := GeometryFactory.material("infected_coat" if infected else ("npc_coat" if npc else "survivor_coat"), Color("444b37") if infected else (Color("a29a73") if npc else Color("414f4d")), "cloth")
	var trousers := GeometryFactory.material("trousers", Color("202a2b"), "cloth")
	var skin := GeometryFactory.material("infected_skin" if infected else "skin", Color("919780") if infected else Color("ae9679"))
	var boot := GeometryFactory.material("boots", Color("252b29"))
	GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), coat, Vector3(0, 1.18, 0), Vector3(0.49, 0.63, 0.30))
	GeometryFactory.mesh_node(self, GeometryFactory.sphere_mesh(), skin, Vector3(0, 1.72, 0), Vector3(0.33, 0.41, 0.33))
	if not infected:
		GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), trousers, Vector3(0, 1.88, 0.01), Vector3(0.36, 0.10, 0.36))
		var pack := GeometryFactory.material("backpack", Color("6c6042"), "cloth")
		GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), pack, Vector3(0, 1.25, 0.25), Vector3(0.40, 0.46, 0.23))
		GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), boot, Vector3(0, 1.28, 0.38), Vector3(0.26, 0.05, 0.025))
	else:
		var eyes := GeometryFactory.material("eyes", Color("a24b39"), "", 0.8)
		for side in [-1.0, 1.0]:
			GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), eyes, Vector3(side * 0.075, 1.75, -0.155), Vector3(0.055, 0.034, 0.02))
	left_leg = _limb(Vector3(-0.14, 0.88, 0), Vector3(0.19, 0.68, 0.23), trousers, boot, true)
	right_leg = _limb(Vector3(0.14, 0.88, 0), Vector3(0.19, 0.68, 0.23), trousers, boot, true)
	left_arm = _limb(Vector3(-0.34, 1.42, 0), Vector3(0.16, 0.55, 0.18), coat, skin, false)
	right_arm = _limb(Vector3(0.34, 1.42, 0), Vector3(0.16, 0.55, 0.18), coat, skin, false)
	if not infected and not npc:
		tool = Node3D.new()
		right_arm.add_child(tool)
		GeometryFactory.mesh_node(tool,GeometryFactory.box_mesh(),GeometryFactory.material("tool_handle",Color("766247"),"wood"),Vector3(0,-0.64,-0.03),Vector3(0.055,0.55,0.055))
		tool_head = GeometryFactory.mesh_node(tool,GeometryFactory.box_mesh(),GeometryFactory.material("tool_steel",Color("8d9995"),"rust"),Vector3(0,-0.88,-0.06),Vector3(0.4,0.12,0.12))
		tool.visible = false

func _limb(at: Vector3, size: Vector3, mat: Material, end_mat: Material, leg: bool) -> Node3D:
	var pivot := Node3D.new()
	add_child(pivot)
	pivot.position = at
	GeometryFactory.mesh_node(pivot, GeometryFactory.box_mesh(), mat, Vector3(0, -size.y * 0.5, 0), size)
	GeometryFactory.mesh_node(pivot, GeometryFactory.box_mesh(), end_mat, Vector3(0, -size.y, -0.035 if leg else 0.0), Vector3(size.x * 1.06, 0.16, 0.32 if leg else 0.16))
	return pivot

func animate(delta: float, speed: float, grounded: bool = true) -> void:
	if left_leg == null:
		return
	phase += delta * (speed * 1.7 + 0.8)
	var swing := sin(phase) * minf(speed * 0.11, 0.68) if grounded else 0.12
	left_leg.rotation.x = swing
	right_leg.rotation.x = -swing
	left_arm.rotation.x = -swing * 0.8 - (0.65 if infected else 0.0)
	right_arm.rotation.x = swing * 0.8 - (0.65 if infected else 0.0)
	if infected:
		rotation.z = sin(phase * 0.5) * 0.035

	if harvest_time > 0 and is_instance_valid(tool):
		harvest_time = maxf(0,harvest_time-delta)
		var progress := (0.64-harvest_time)/0.64
		right_arm.rotation.x = 0.7 + sin(progress*PI)*1.8
		left_arm.rotation.x = 0.8 + sin(progress*PI)*0.5
		tool.visible = harvest_time > 0

func begin_harvest(kind: String) -> void:
	if not is_instance_valid(tool): return
	harvest_kind = kind
	harvest_time = 0.64
	tool.visible = true
	tool_head.scale = Vector3(1,1.8,1.8) if kind=="tree" else Vector3(1.9,0.65,0.8)
