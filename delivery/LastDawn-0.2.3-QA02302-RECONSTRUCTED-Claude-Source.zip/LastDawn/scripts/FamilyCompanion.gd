class_name FamilyCompanion
extends CharacterBody3D
const HOME := Vector3(8.8,0.05,14.5)
var world: Node3D
var quest: Node
var visual: CharacterVisual
var route := PackedVector3Array()
var route_index := 0
var think_clock := 0.0
var repath_clock := 0.0
var desired := Vector3.ZERO
var decisions := 0
var paths := 0
var sleeping := false

func _ready() -> void:
	name = "FamilyXiaoyu"
	position = HOME
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 0.35
	var shape := CapsuleShape3D.new()
	shape.radius = 0.29
	shape.height = 1.65
	var collider := CollisionShape3D.new()
	collider.shape = shape
	collider.position.y = 0.83
	add_child(collider)
	visual = CharacterVisual.new()
	add_child(visual)
	visual.build(false,true)
	visual.scale = Vector3.ONE*0.92
	GeometryFactory.mesh_node(visual,GeometryFactory.box_mesh(),GeometryFactory.material("family_scarf",Color("a38991"),"cloth"),Vector3(0,1.5,-0.17),Vector3(0.48,0.14,0.07))
	var label := GeometryFactory.label(self,"小雨 · 家人",Vector3(0,2.3,0),26,Color("d2b4be"))
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.visibility_range_end = 28

func _physics_process(delta: float) -> void:
	think_clock -= delta
	repath_clock -= delta
	if think_clock <= 0:
		_think()
		think_clock = 1.0 if sleeping else 0.25
	if sleeping: return
	var speed := 4.4 if position.distance_squared_to(world.player.position)>36 else 3.4
	velocity.x = desired.x*speed
	velocity.z = desired.z*speed
	velocity.y = 0.0 if is_on_floor() else velocity.y-20*delta
	move_and_slide()
	if desired.length_squared()>0.01:
		visual.rotation.y = lerp_angle(visual.rotation.y,atan2(-desired.x,-desired.z),minf(1,delta*8))
	visual.animate(delta,desired.length()*speed)

func _think() -> void:
	decisions += 1
	desired = Vector3.ZERO
	var offset: Vector3 = world.player.position-position
	offset.y = 0
	var sq := offset.length_squared()
	sleeping = sq>55*55
	visible = sq<pow(float(GraphicsManager.preset()["distance"]),2)
	if sleeping:
		velocity = Vector3.ZERO
		return
	if quest.stage!="following" or not world.player.survival.alive() or sq<2.2*2.2: return
	if sq>40*40: return # Lost separation: wait here. Never teleport across walls or into camp.
	if repath_clock<=0:
		repath_clock = 1.2
		route = world.navigation.path(position,world.player.position)
		route_index = 1 if route.size()>1 else 0
		paths += 1
	var ray := PhysicsRayQueryParameters3D.create(position+Vector3.UP,world.player.position+Vector3.UP,1)
	if sq<6*6 and get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
		desired = offset.normalized()
		return
	while route_index<route.size():
		var next := route[route_index]
		next.y = position.y
		if position.distance_squared_to(next)<0.7: route_index += 1
		else:
			desired = (next-position).normalized()
			break

func reset_route() -> void:
	route.clear()
	route_index = 0
	think_clock = 0
	repath_clock = 0
	velocity = Vector3.ZERO
	desired = Vector3.ZERO
