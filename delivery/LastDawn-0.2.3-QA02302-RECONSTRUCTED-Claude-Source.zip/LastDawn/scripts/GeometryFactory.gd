class_name GeometryFactory
extends RefCounted
## Shared resources: materials, primitive meshes and surface textures are never cloned per prop.
static var materials: Dictionary = {}
static var meshes: Dictionary = {}

static func material(id: String, color: Color, texture_name: String = "", emission: float = 0.0) -> StandardMaterial3D:
	if materials.has(id):
		return materials[id]
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	if not texture_name.is_empty():
		mat.albedo_texture = load("res://assets/materials/%s.png" % texture_name)
		mat.uv1_triplanar = true
		mat.uv1_world_triplanar = true
		mat.uv1_scale = Vector3.ONE * 0.32
	if emission > 0.0:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = emission
	materials[id] = mat
	return mat

static func box_mesh() -> BoxMesh:
	if not meshes.has("box"):
		meshes["box"] = BoxMesh.new()
		meshes["box"].size = Vector3.ONE
	return meshes["box"]

static func cylinder_mesh() -> CylinderMesh:
	if not meshes.has("cylinder"):
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.5
		mesh.bottom_radius = 0.5
		mesh.height = 1.0
		mesh.radial_segments = 8
		mesh.rings = 1
		meshes["cylinder"] = mesh
	return meshes["cylinder"]

static func sphere_mesh() -> SphereMesh:
	if not meshes.has("sphere"):
		var mesh := SphereMesh.new()
		mesh.radius = 0.5
		mesh.height = 1.0
		mesh.radial_segments = 10
		mesh.rings = 5
		meshes["sphere"] = mesh
	return meshes["sphere"]

static func cone_mesh() -> CylinderMesh:
	if not meshes.has("cone"):
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.0
		mesh.bottom_radius = 0.5
		mesh.height = 1.0
		mesh.radial_segments = 8
		mesh.rings = 1
		meshes["cone"] = mesh
	return meshes["cone"]

static func mesh_node(parent: Node3D, mesh: Mesh, mat: Material, at: Vector3, size: Vector3) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	node.position = at
	node.scale = size
	parent.add_child(node)
	return node

static func box_collider(parent: Node3D, at: Vector3, size: Vector3, yaw: float = 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = at
	body.rotation.y = yaw
	body.collision_layer = 1
	body.collision_mask = 0
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	parent.add_child(body)
	return body

static func label(parent: Node3D, text: String, at: Vector3, font_size: int = 48, color: Color = Color(0.89, 0.84, 0.69)) -> Label3D:
	var node := Label3D.new()
	node.text = text
	node.position = at
	node.font = load("res://assets/fonts/LastDawnSans.ttf")
	node.font_size = font_size
	node.pixel_size = 0.016
	node.modulate = color
	node.outline_size = 4
	node.outline_modulate = Color(0.05, 0.10, 0.10)
	node.no_depth_test = false
	node.visibility_range_end = 70.0
	parent.add_child(node)
	return node
