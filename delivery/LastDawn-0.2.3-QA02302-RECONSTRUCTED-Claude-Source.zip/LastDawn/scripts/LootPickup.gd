class_name LootPickup
extends Node3D
var id := ""
var item := "wood"
var amount := 1

func build(pickup_id: String, item_id: String, count: int) -> void:
	id = pickup_id
	item = item_id
	amount = count
	var wood := GeometryFactory.material("loot_wood", Color("9b8054"), "wood")
	var stone := GeometryFactory.material("loot_stone", Color("a3a392"), "rock")
	var food := GeometryFactory.material("loot_food", Color("b5a072"), "rust")
	if item == "wood":
		for i in range(3):
			GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), wood, Vector3(i * 0.15 - 0.15, 0.12 + i * 0.07, 0), Vector3(0.15, 0.16, 0.75)).rotation.y = i * 0.22
	elif item == "stone":
		GeometryFactory.mesh_node(self, GeometryFactory.sphere_mesh(), stone, Vector3(0, 0.18, 0), Vector3(0.6, 0.4, 0.5))
	elif item == "water":
		var water := GeometryFactory.material("loot_water", Color("7ca1ad"))
		var cap := GeometryFactory.material("water_cap", Color("d2d4bf"))
		for i in range(2):
			GeometryFactory.mesh_node(self, GeometryFactory.cylinder_mesh(), water, Vector3(i * 0.23, 0.22, 0), Vector3(0.20, 0.44, 0.20))
			GeometryFactory.mesh_node(self, GeometryFactory.cylinder_mesh(), cap, Vector3(i * 0.23, 0.46, 0), Vector3(0.10, 0.06, 0.10))
	else:
		for i in range(2):
			GeometryFactory.mesh_node(self, GeometryFactory.cylinder_mesh(), food, Vector3(i * 0.23, 0.2, 0), Vector3(0.20, 0.38, 0.20))
	var marker := GeometryFactory.material("loot_marker", Color("bea66b"), "", 0.6)
	GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), marker, Vector3(0, 0.75, 0), Vector3(0.08, 0.08, 0.08)).rotation.z = PI / 4
