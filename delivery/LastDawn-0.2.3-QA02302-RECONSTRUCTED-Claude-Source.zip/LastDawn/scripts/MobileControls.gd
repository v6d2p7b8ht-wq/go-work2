class_name MobileControls
extends Control
## UI/keyboard adapter. TouchInputManager is the only ScreenTouch/ScreenDrag input path.
signal look_changed(delta: Vector2)
signal zoom_changed(amount: float)
signal interact_requested
signal inventory_requested
signal settings_requested
signal save_requested
signal load_requested
var enabled := true
var sprint_toggled := false
var touch_manager: TouchInputManager
var ui_hit_test: Callable
var joystick_touch: int:
	get:
		return touch_manager.joystick_touch if touch_manager else -1
var look_touch: int:
	get:
		return touch_manager.look_touch if touch_manager else -1
var jump_pending := false
var stick: Vector2:
	get:
		return touch_manager.stick if touch_manager else Vector2.ZERO
var joystick_center := Vector2.ZERO
var jump_center := Vector2.ZERO
var sprint_center := Vector2.ZERO
var interact_center := Vector2.ZERO
var zoom_in_center := Vector2.ZERO
var zoom_out_center := Vector2.ZERO
var radius := 70.0
var action_radius := 37.0
var font: Font
var safe := Vector4.ZERO

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = load("res://assets/fonts/LastDawnSans.ttf")
	touch_manager = TouchInputManager.new()
	touch_manager.controls = self
	touch_manager.look_delta.connect(func(relative: Vector2): look_changed.emit(relative))
	touch_manager.action_pressed.connect(_perform_action)
	touch_manager.reset_occurred.connect(_on_touch_reset)
	add_child(touch_manager)
	resized.connect(_layout)
	_layout()
	_setup_keyboard()

func _setup_keyboard() -> void:
	var bindings := {
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"move_forward": [KEY_W, KEY_UP], "move_back": [KEY_S, KEY_DOWN],
		"jump": [KEY_SPACE], "sprint": [KEY_SHIFT], "interact": [KEY_E],
		"inventory": [KEY_I, KEY_TAB], "settings": [KEY_ESCAPE],
		"quick_save": [KEY_F5], "quick_load": [KEY_F9]
	}
	for action in bindings:
		if InputMap.has_action(action):
			continue
		InputMap.add_action(action)
		for key in bindings[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)

func _layout() -> void:
	if touch_manager:
		touch_manager.reset("viewport-size-changed")
	safe = safe_margins()
	joystick_center = Vector2(safe.x + 119, size.y - safe.w - 120)
	jump_center = Vector2(size.x - safe.z - 67, size.y - safe.w - 78)
	sprint_center = Vector2(size.x - safe.z - 162, size.y - safe.w - 66)
	interact_center = Vector2(size.x - safe.z - 72, size.y - safe.w - 180)
	zoom_in_center = Vector2(size.x - safe.z - 56, size.y - safe.w - 304)
	zoom_out_center = Vector2(size.x - safe.z - 116, size.y - safe.w - 304)
	queue_redraw()

func safe_margins() -> Vector4:
	var screen := DisplayServer.window_get_size()
	var area := DisplayServer.get_display_safe_area()
	if screen.x <= 0 or screen.y <= 0 or area.size.x <= 0 or OS.has_feature("web"):
		return Vector4(16, 12, 16, 12)
	var factor := size / Vector2(screen)
	return Vector4(maxf(16, area.position.x * factor.x), maxf(12, area.position.y * factor.y), maxf(16, (screen.x - area.end.x) * factor.x), maxf(12, (screen.y - area.end.y) * factor.y))

func reset_touches() -> void:
	if touch_manager:
		touch_manager.reset("controls-reset")

func _on_touch_reset(_reason: String) -> void:
	jump_pending = false
	sprint_toggled = false
	queue_redraw()

func set_enabled(value: bool) -> void:
	enabled = value
	if touch_manager:
		touch_manager.reset("controls-enabled" if value else "menu-opened")
	queue_redraw()

func touch_role_at(at: Vector2) -> String:
	if not enabled or (ui_hit_test.is_valid() and bool(ui_hit_test.call(at))) or at.y < safe.y + 110:
		return "ui"
	var action := _action_at(at)
	if not action.is_empty():
		return "action:" + action
	if at.distance_to(joystick_center) < radius * 1.65 and at.x < size.x * 0.48:
		return "joystick"
	# Leave the browser's reserved back-swipe edge outside camera ownership.
	if at.x < safe.x + 18 or at.x > size.x - safe.z - 18:
		return "edge"
	return "look" if at.x > size.x * 0.52 else "ignored"

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("settings") and not event.is_echo():
		settings_requested.emit()
		return
	if not enabled:
		return
	if event is InputEventMouseMotion:
		if touch_manager.permits_mouse_look(event) and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			look_changed.emit(event.relative)
	elif event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_changed.emit(-0.5)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_changed.emit(0.5)
		elif event.pressed and event.button_index == MOUSE_BUTTON_LEFT and event.device != InputEvent.DEVICE_ID_EMULATION:
			_action_touch(event.position, -2)
	if event.is_action_pressed("jump"):
		jump_pending = true
	if event.is_action_pressed("interact"):
		interact_requested.emit()
	if event.is_action_pressed("inventory"):
		inventory_requested.emit()
	if event.is_action_pressed("quick_save"):
		save_requested.emit()
	if event.is_action_pressed("quick_load"):
		load_requested.emit()

func _action_at(at: Vector2) -> String:
	if at.distance_to(jump_center) <= action_radius + 12:
		return "jump"
	if at.distance_to(sprint_center) <= action_radius + 12:
		return "sprint"
	if at.distance_to(interact_center) <= action_radius + 14:
		return "interact"
	if at.distance_to(zoom_in_center) < 25:
		return "zoom-in"
	if at.distance_to(zoom_out_center) < 25:
		return "zoom-out"
	return ""

func _action_touch(at: Vector2, _index: int) -> bool:
	var action := _action_at(at)
	if action.is_empty():
		return false
	_perform_action(action)
	return true

func _perform_action(action: String) -> void:
	match action:
		"jump": jump_pending = true
		"sprint": sprint_toggled = not sprint_toggled
		"interact": interact_requested.emit()
		"zoom-in": zoom_changed.emit(-0.7)
		"zoom-out": zoom_changed.emit(0.7)
	queue_redraw()

func movement_vector() -> Vector2:
	var keys := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	return (keys + stick).limit_length(1.0) if enabled else Vector2.ZERO

func consume_jump() -> bool:
	var result := jump_pending
	jump_pending = false
	return result

func wants_sprint() -> bool:
	return enabled and (sprint_toggled or Input.is_action_pressed("sprint"))

func _draw() -> void:
	if not enabled or font == null:
		return
	var ink := Color(0.74, 0.81, 0.76, 0.55)
	draw_circle(joystick_center, radius, Color(0.03, 0.09, 0.09, 0.32))
	draw_arc(joystick_center, radius, 0, TAU, 56, ink, 1.5, true)
	draw_arc(joystick_center, 24, 0, TAU, 28, Color(0.74, 0.81, 0.76, 0.20), 1, true)
	draw_circle(joystick_center + stick * radius * 0.66, 28, Color(0.79, 0.84, 0.76, 0.32))
	draw_string(font, joystick_center + Vector2(-18, -radius - 17), "移动", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, ink)
	_action_circle(jump_center, "跳跃", false)
	_action_circle(sprint_center, "奔跑", sprint_toggled)
	_action_circle(interact_center, "交互", true)
	for point in [zoom_in_center, zoom_out_center]:
		draw_circle(point, 23, Color(0.03, 0.09, 0.09, 0.40))
		draw_arc(point, 23, 0, TAU, 24, ink, 1, true)
	draw_string(font, zoom_in_center + Vector2(-7, 8), "+", HORIZONTAL_ALIGNMENT_LEFT, -1, 26, ink)
	draw_string(font, zoom_out_center + Vector2(-6, 8), "−", HORIZONTAL_ALIGNMENT_LEFT, -1, 26, ink)
	draw_string(font, Vector2(size.x - safe.z - 152, size.y - safe.w - 344), "相机距离", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, ink)
	var center := size * 0.5
	draw_line(center + Vector2(-5, 0), center + Vector2(5, 0), Color(0.9, 0.9, 0.8, 0.35), 1)
	draw_line(center + Vector2(0, -5), center + Vector2(0, 5), Color(0.9, 0.9, 0.8, 0.35), 1)

func _action_circle(at: Vector2, text: String, accent: bool) -> void:
	var color := Color(0.85, 0.62, 0.38, 0.8) if accent else Color(0.78, 0.85, 0.8, 0.6)
	draw_circle(at, action_radius, Color(0.05, 0.10, 0.10, 0.48))
	draw_arc(at, action_radius, 0, TAU, 36, color, 1.5, true)
	draw_string(font, at + Vector2(-20, 7), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, color)
