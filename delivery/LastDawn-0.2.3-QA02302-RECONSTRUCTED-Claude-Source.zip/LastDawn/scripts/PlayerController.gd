class_name PlayerController
extends CharacterBody3D
signal noise_emitted(at: Vector3, radius: float)
const WALK_SPEED := 3.6
const RUN_SPEED := 6.5
const JUMP_SPEED := 7.2
var controls: Control
var rig: CameraController
var visual: CharacterVisual
var survival := SurvivalSystem.new()
var stamina: float:
	get:
		return survival.stamina
	set(value):
		survival.stamina = clampf(value, 0, 100)
var safety_check: Callable
var noise_clock := 0.0
var running := false
var distance_walked := 0.0

func _ready() -> void:
	add_child(survival)
	name = "Survivor"
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 0.35
	floor_max_angle = deg_to_rad(47)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.8
	collision.shape = capsule
	collision.position.y = 0.9
	add_child(collision)
	visual = CharacterVisual.new()
	add_child(visual)
	visual.build()
	rig = CameraController.new()
	add_child(rig)

func _physics_process(delta: float) -> void:
	var movement := Vector2.ZERO
	var jumping := false
	running = false
	if controls and controls.enabled and survival.alive():
		movement = controls.movement_vector()
		jumping = controls.consume_jump()
		running = controls.wants_sprint() and movement.length_squared() > 0.1 and stamina > 2.0
	survival.step(delta, running, safety_check.is_valid() and bool(safety_check.call(position)))
	if stamina <= 2.0 and controls:
		controls.sprint_toggled = false
	var direction := Vector3(movement.x, 0, movement.y).rotated(Vector3.UP, rig.yaw)
	var speed := RUN_SPEED if running else WALK_SPEED
	velocity.x = move_toward(velocity.x, direction.x * speed, 20.0 * delta)
	velocity.z = move_toward(velocity.z, direction.z * speed, 20.0 * delta)
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	elif jumping:
		velocity.y = JUMP_SPEED
		noise_emitted.emit(position, 12.0)
	if direction.length_squared() > 0.01:
		visual.rotation.y = lerp_angle(visual.rotation.y, atan2(-direction.x, -direction.z), 1.0 - exp(-12.0 * delta))
	var old := position
	move_and_slide()
	distance_walked += Vector2(position.x - old.x, position.z - old.z).length()
	noise_clock -= delta
	if noise_clock <= 0 and Vector2(velocity.x, velocity.z).length() > 1.0 and is_on_floor():
		noise_clock = 0.6
		noise_emitted.emit(position, 17.0 if running else 6.0)
	position.x = clampf(position.x, -98.0, 98.0)
	position.z = clampf(position.z, -98.0, 98.0)
	visual.animate(delta, Vector2(velocity.x, velocity.z).length(), is_on_floor())
	if position.y < -12.0:
		rescue()

func rescue() -> void:
	position = Vector3(6, 1.0, 32)
	velocity = Vector3.ZERO
	stamina = 100.0
	if not survival.alive():
		survival.recover()
		position = Vector3(18, 0.5, 36)
