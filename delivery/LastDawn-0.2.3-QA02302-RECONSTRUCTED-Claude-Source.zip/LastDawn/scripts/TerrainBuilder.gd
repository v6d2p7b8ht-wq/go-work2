class_name TerrainBuilder
extends RefCounted
const GRID := 81
const STEP := 2.5
static var noise: FastNoiseLite

static func height_at(x: float, z: float) -> float:
	if noise == null:
		noise = FastNoiseLite.new()
		noise.seed = 80421
		noise.frequency = 0.028
		noise.fractal_octaves = 3
	var edge := smoothstep(38.0, 90.0, absf(x))
	var ridge := maxf(absf(x) - 43.0, 0.0) * 0.29
	var north := smoothstep(70.0, 100.0, absf(z)) * 5.0 * smoothstep(9.0, 40.0, absf(x))
	return maxf(0.0, ridge + noise.get_noise_2d(x, z) * 8.0 * edge + north)

static func build(parent: Node3D) -> void:
	var heights := PackedFloat32Array()
	heights.resize(GRID * GRID)
	for z in range(GRID):
		for x in range(GRID):
			heights[z * GRID + x] = height_at(x * STEP - 100.0, z * STEP - 100.0)
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for z in range(GRID - 1):
		for x in range(GRID - 1):
			# Godot front faces use clockwise winding; normals must face the sky.
			for corner in [Vector2i(x, z), Vector2i(x + 1, z), Vector2i(x, z + 1), Vector2i(x + 1, z), Vector2i(x + 1, z + 1), Vector2i(x, z + 1)]:
				var px: float = corner.x * STEP - 100.0
				var pz: float = corner.y * STEP - 100.0
				surface.set_uv(Vector2(px, pz) / 4.0)
				surface.add_vertex(Vector3(px, heights[corner.y * GRID + corner.x], pz))
	surface.generate_normals()
	surface.index()
	var mesh := surface.commit()
	var mat := GeometryFactory.material("earth", Color("77796a"), "ground")
	var terrain := GeometryFactory.mesh_node(parent, mesh, mat, Vector3.ZERO, Vector3.ONE)
	terrain.name = "TerrainSurface"
	var body := StaticBody3D.new()
	body.name = "HeightMapTerrain200m"
	var shape := CollisionShape3D.new()
	var heightmap := HeightMapShape3D.new()
	heightmap.map_width = GRID
	heightmap.map_depth = GRID
	heightmap.map_data = heights
	shape.shape = heightmap
	shape.scale = Vector3(STEP, 1.0, STEP)
	body.add_child(shape)
	parent.add_child(body)
