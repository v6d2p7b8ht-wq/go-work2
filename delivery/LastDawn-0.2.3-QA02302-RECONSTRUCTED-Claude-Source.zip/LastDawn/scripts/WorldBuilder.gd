class_name WorldBuilder
extends RefCounted
## Architecture and props. Static transforms are submitted to chunk-local batches.
var root: Node3D
var batch: StaticBatcher
var obstacles: Array[Rect2] = []
var building_count := 0
var vehicle_count := 0
var rng := RandomNumberGenerator.new()
var concrete: Material
var rust: Material
var wood: Material
var glass: Material
var dark: Material
var metal: Material

func build(parent: Node3D, batching: StaticBatcher) -> void:
	root = parent
	batch = batching
	rng.seed = 11276
	concrete = GeometryFactory.material("concrete", Color("97968a"), "plaster")
	rust = GeometryFactory.material("rust", Color("79513b"), "rust")
	wood = GeometryFactory.material("wood", Color("75654c"), "wood")
	glass = GeometryFactory.material("glass", Color("273e40"))
	dark = GeometryFactory.material("dark_metal", Color("303735"), "rust")
	metal = GeometryFactory.material("metal", Color("606d68"), "rust")
	_road()
	_supermarket()
	_building(Vector3(21, 0, -8), Vector3(13, 6, 12), "b_house", Color("a39a7c"), true, "PINE RESIDENCE")
	_building(Vector3(24, 0, -34), Vector3(16, 8, 14), "b_apartment", Color("787c75"), false, "BLOCK 04")
	_building(Vector3(-23, 0, -36), Vector3(19, 10, 15), "b_hotel", Color("8d7765"), false, "MOTEL")
	_building(Vector3(-24, 0, -65), Vector3(22, 7, 19), "b_warehouse", Color("626c67"), false, "DEPOT 09")
	_building(Vector3(21, 0, 13), Vector3(12, 4, 10), "b_garage", Color("8b8270"), false, "AUTO SERVICE")
	_building(Vector3(-22, 0, 33), Vector3(17, 6, 13), "b_clinic", Color("9d9d8c"), false, "FIELD CLINIC")
	_building(Vector3(36, 0, 60), Vector3(9, 4, 8), "b_cabin", Color("756b50"), true, "RANGER")
	_camp()
	_car(Vector3(-3, 0, -12), 0.22, Color("7d887b"), false)
	_car(Vector3(4, 0, -38), -0.36, Color("897563"), false)
	_car(Vector3(-6, 0, 53), 0.1, Color("646f77"), false)
	_car(Vector3(-31, 0, 15), 1.2, Color("7f6d57"), true)
	_car(Vector3(24, 0, 42), PI / 2, Color("9b9b81"), true)
	_rocks_and_debris()
	batch.build()

func _solid(at: Vector3, size: Vector3, mat: Material, collide: bool = true, yaw: float = 0.0) -> void:
	batch.box(mat, at, size, yaw)
	if collide:
		GeometryFactory.box_collider(root, at, size, yaw)

func _road() -> void:
	var asphalt := GeometryFactory.material("asphalt", Color("454b47"), "asphalt")
	var paint := GeometryFactory.material("road_paint", Color("b5ae83"), "plaster")
	var pavement := GeometryFactory.material("pavement", Color("777b71"), "plaster")
	batch.box(asphalt, Vector3(0, 0.012, 0), Vector3(11.0, 0.025, 200.0))
	for side in [-1.0, 1.0]:
		batch.box(pavement, Vector3(side * 7.2, 0.022, 0), Vector3(3.3, 0.045, 198))
		for z in range(-96, 98, 4):
			batch.box(concrete, Vector3(side * 5.6, 0.08, z), Vector3(0.22, 0.16, 3.85))
			batch.box(paint, Vector3(side * 4.7, 0.034, z), Vector3(0.09, 0.015, 3.7))
	for z in range(-98, 99, 7):
		batch.box(paint, Vector3(0, 0.034, z), Vector3(0.14, 0.018, 3.0))
	for z in range(-81, 81, 23):
		for side in [-1.0, 1.0]:
			var x: float = side * 8.2
			batch.add_prop(GeometryFactory.cylinder_mesh(), dark, Vector3(x, 4.7, z), Vector3(0.16, 9.4, 0.16))
			batch.box(dark, Vector3(x - side * 1.1, 9.2, z), Vector3(2.3, 0.12, 0.12))
			batch.box(metal, Vector3(x - side * 2.0, 9.05, z), Vector3(0.7, 0.16, 0.38))
			GeometryFactory.box_collider(root, Vector3(x, 3, z), Vector3(0.22, 6, 0.22))
		# Two sagging cable segments on the west utility line.
		if z < 70:
			for i in range(8):
				var t := float(i) / 8.0
				batch.box(dark, Vector3(-8.2, 8.9 - sin(t * PI) * 0.55, z + t * 23 + 1.4), Vector3(0.035, 0.035, 2.92))
	var sign_prop := GeometryFactory.material("sign_green", Color("314f45"))
	_solid(Vector3(9, 2, 5), Vector3(0.15, 4, 0.15), dark)
	batch.box(sign_prop, Vector3(9, 3.2, 5), Vector3(4.6, 1.35, 0.13))
	GeometryFactory.label(root, "灰松郊区  /  PINE CREEK\n森林 →     安全区 ↓", Vector3(9, 3.2, 5.08), 35)

func _building(at: Vector3, size: Vector3, id: String, color: Color, pitched: bool, title: String) -> void:
	building_count += 1
	var base := at + Vector3.UP * TerrainBuilder.height_at(at.x, at.z)
	var mat := GeometryFactory.material(id, color, "plaster" if pitched else "brick")
	_solid(base + Vector3.UP * size.y * 0.5, size, mat)
	obstacles.append(Rect2(Vector2(at.x - size.x / 2, at.z - size.z / 2), Vector2(size.x, size.z)))
	batch.box(concrete, base + Vector3(0, 0.20, 0), Vector3(size.x + 0.35, 0.4, size.z + 0.35))
	batch.box(dark, base + Vector3(0, size.y + 0.15, 0), Vector3(size.x + 0.7, 0.3, size.z + 0.7))
	if pitched:
		var roof := PrismMesh.new()
		roof.size = Vector3.ONE
		batch.add_prop(roof, rust, base + Vector3(0, size.y + 1, 0), Vector3(size.x + 1.0, 2.0, size.z + 1.0))
	else:
		batch.box(concrete, base + Vector3(size.x * 0.22, size.y + 0.65, 0), Vector3(2.6, 1.0, 2.6))
	var facing := -1.0 if at.x > 0 else 1.0
	var front_x := facing * (size.x * 0.5 + 0.035)
	for floor_id in range(maxi(1, int(size.y / 3.2))):
		for z_offset in range(-int(size.z / 2) + 2, int(size.z / 2) - 1, 3):
			var window := base + Vector3(front_x, 2.1 + floor_id * 3.0, z_offset)
			batch.box(dark, window, Vector3(0.10, 1.68, 1.55))
			batch.box(glass, window + Vector3(facing * 0.06, 0, 0), Vector3(0.04, 1.45, 1.32))
			batch.box(concrete, window + Vector3(facing * 0.08, -0.85, 0), Vector3(0.2, 0.1, 1.75))
			if rng.randf() < 0.4:
				batch.box(wood, window + Vector3(facing * 0.10, 0.2, 0), Vector3(0.10, 0.22, 1.85))
	batch.box(wood, base + Vector3(front_x + facing * 0.08, 1.1, 0), Vector3(0.12, 2.2, 1.15))
	var sign_prop := GeometryFactory.label(root, title, base + Vector3(front_x + facing * 0.13, size.y - 0.5, 0), 38)
	sign_prop.rotation.y = facing * PI / 2

func _supermarket() -> void:
	building_count += 1
	var wall := GeometryFactory.material("market_wall", Color("aaa48a"), "plaster")
	var red := GeometryFactory.material("market_red", Color("824a3c"), "rust")
	# 20 x 18 m, with a real 3.6 m entrance on the east facade.
	_solid(Vector3(-29, 2.5, -7), Vector3(0.45, 5, 18), wall)
	_solid(Vector3(-19, 2.5, -16), Vector3(20, 5, 0.45), wall)
	_solid(Vector3(-19, 2.5, 2), Vector3(20, 5, 0.45), wall)
	for center in [-12.35, -1.65]:
		_solid(Vector3(-9, 2.5, center), Vector3(0.4, 5, 7.3), wall)
		batch.box(glass, Vector3(-8.77, 2.3, center), Vector3(0.03, 2.2, 5.8))
		batch.box(wood, Vector3(-8.70, 1.9, center), Vector3(0.08, 0.25, 6))
	_solid(Vector3(-19, 5.05, -7), Vector3(21, 0.3, 19), dark)
	batch.box(concrete, Vector3(-19, 0.035, -7), Vector3(20, 0.07, 18))
	batch.box(red, Vector3(-8.55, 4.3, -7), Vector3(0.8, 1.2, 19.3))
	var title := GeometryFactory.label(root, "灰松生活超市  /  PINE MART", Vector3(-8.10, 4.35, -7), 56)
	title.rotation.y = PI / 2
	# Real walls are obstacles, not the entire building footprint.
	for rect in [Rect2(-29.3, -16.3, 0.8, 18.6), Rect2(-29, -16.3, 20, 0.8), Rect2(-29, 1.7, 20, 0.8), Rect2(-9.3, -16, 0.8, 7.3), Rect2(-9.3, -5.3, 0.8, 7.3)]:
		obstacles.append(rect)
	for x in [-24.0, -18.0]:
		for z in [-11.0, -2.0]:
			_solid(Vector3(x, 0.8, z), Vector3(1.0, 1.6, 4.0), metal)
			obstacles.append(Rect2(x - 0.5, z - 2, 1, 4))
			for level in [0.5, 1.25]:
				batch.box(wood, Vector3(x, level, z), Vector3(1.2, 0.08, 4.2))
				for i in range(4):
					batch.box(red, Vector3(x - 0.30, level + 0.15, z - 1.3 + i * 0.8), Vector3(0.23, 0.3, 0.35))
	_solid(Vector3(-12, 0.6, -1), Vector3(2, 1.2, 1), wood)
	var lamp := GeometryFactory.material("interior_lamp", Color("c0bf96"), "", 1.0)
	batch.box(lamp, Vector3(-18, 4.82, -7), Vector3(0.35, 0.08, 4))

func _camp() -> void:
	var safe_color := GeometryFactory.material("safe_color", Color("a78a56"), "cloth")
	var fabric := GeometryFactory.material("tarp", Color("4e5c45"), "cloth")
	for x in [13.0, 30.0]:
		for z in range(27, 48, 4):
			_solid(Vector3(x, 0.5, z), Vector3(0.6, 1, 3.4), wood)
			obstacles.append(Rect2(x-0.3,z-1.7,0.6,3.4))
	for x in range(16, 31, 4):
		_solid(Vector3(x, 0.5, 48), Vector3(3.5, 1, 0.6), wood)
		obstacles.append(Rect2(x-1.75,47.7,3.5,0.6))
	for at in [Vector3(17, 1.5, 37), Vector3(26, 1.5, 37), Vector3(17, 1.5, 44), Vector3(26, 1.5, 44)]:
		_solid(at, Vector3(0.12, 3, 0.12), wood)
	batch.box(fabric, Vector3(21.5, 3.1, 40.5), Vector3(10, 0.12, 8.5))
	for i in range(4):
		_solid(Vector3(28, 0.45 + (i % 2) * 0.9, 28 + floori(i / 2.0) * 1.0), Vector3(0.85, 0.85, 0.85), safe_color)
	batch.box(fabric, Vector3(18, 0.3, 41), Vector3(0.8, 0.25, 2))
	batch.box(safe_color, Vector3(15.4, 2.2, 27), Vector3(4.5, 0.85, 0.1))
	GeometryFactory.label(root, "安全区  /  SAFE HAVEN", Vector3(15.4, 2.2, 27.07), 34, Color("e4d8af"))
	# A visible marker on the ground, without a transparent full-screen overlay.
	var stripe := GeometryFactory.material("safe_stripe", Color("96966a"))
	for i in range(10):
		batch.box(stripe, Vector3(12.5, 0.027, 28.0 + i * 1.9), Vector3(0.15, 0.02, 0.9))

func _car(at: Vector3, yaw: float, color: Color, van: bool) -> void:
	vehicle_count += 1
	var paint := GeometryFactory.material("car_%d" % vehicle_count, color, "rust")
	var origin := at + Vector3.UP * TerrainBuilder.height_at(at.x, at.z)
	var length := 4.8 if van else 4.0
	var height := 2.0 if van else 1.25
	batch.box(paint, origin + Vector3(0, 0.65, 0), Vector3(1.85, 0.75, length), yaw)
	batch.box(paint, origin + Vector3(0, height, 0.2).rotated(Vector3.UP, yaw), Vector3(1.65, 1.1 if van else 0.7, 3.7 if van else 2.15), yaw)
	for side in [-1.0, 1.0]:
		batch.box(glass, origin + Vector3(side * 0.84, height + 0.05, 0.0).rotated(Vector3.UP, yaw), Vector3(0.04, 0.54, 1.5), yaw)
		for z in [-length * 0.32, length * 0.32]:
			batch.add_prop(GeometryFactory.sphere_mesh(), dark, origin + Vector3(side * 0.95, 0.38, z).rotated(Vector3.UP, yaw), Vector3(0.24, 0.76, 0.76), yaw)
	batch.box(glass, origin + Vector3(0, height, -1.08 if not van else -1.7).rotated(Vector3.UP, yaw), Vector3(1.5, 0.55, 0.05), yaw)
	batch.box(rust, origin + Vector3(0, 0.47, -length / 2 - 0.03).rotated(Vector3.UP, yaw), Vector3(1.95, 0.18, 0.15), yaw)
	for side in [-1.0, 1.0]:
		batch.box(concrete, origin + Vector3(side * 0.6, 0.76, -length / 2 - 0.03).rotated(Vector3.UP, yaw), Vector3(0.38, 0.16, 0.05), yaw)
	GeometryFactory.box_collider(root, origin + Vector3(0, height * 0.5 + 0.15, 0), Vector3(1.9, height + 0.3, length), yaw)
	obstacles.append(Rect2(Vector2(at.x - 2.8, at.z - 2.8), Vector2(5.6, 5.6)))

func _rocks_and_debris() -> void:
	var stone := GeometryFactory.material("rock", Color("747a70"), "rock")
	for i in range(65):
		var x := rng.randf_range(40, 94) * (-1.0 if i % 2 == 0 else 1.0)
		var z := rng.randf_range(-92, 92)
		var scale := rng.randf_range(0.8, 4.1)
		var at := Vector3(x, TerrainBuilder.height_at(x, z) + scale * 0.25, z)
		batch.add_prop(GeometryFactory.sphere_mesh(), stone, at, Vector3(scale * 1.4, scale, scale * 1.1), rng.randf() * TAU)
		GeometryFactory.box_collider(root, at, Vector3(scale, scale * 0.7, scale * 0.85))
	for i in range(120):
		var x := rng.randf_range(-10, 10)
		var z := rng.randf_range(-95, 95)
		var size := rng.randf_range(0.05, 0.18)
		batch.box(stone if i % 2 else wood, Vector3(x, 0.08, z), Vector3(size * 2, size, size * 3), rng.randf() * TAU)
