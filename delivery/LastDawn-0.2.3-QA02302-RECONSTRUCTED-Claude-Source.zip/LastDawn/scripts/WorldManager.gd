class_name WorldManager
extends Node3D
var player: PlayerController
var hud: SurvivalHUD
var atmosphere: Atmosphere
var batcher: StaticBatcher
var vegetation: VegetationSystem
var builder: WorldBuilder
var navigation: NavigationGrid
var noises: NoiseSystem
var resources: ResourceSystem
var buildings: BuildingSystem
var trader: TradingSystem
var infection: InfectionSystem
var clock: WorldClock
var family: FamilyQuest
var guard_visual: CharacterVisual
var actor_lod: ActorLOD
var harvest_feedback: HarvestFeedback
var nearest_resource: Dictionary = {}
var registry := WorldRegistry.new()
var zombies: Array[ZombieAI] = []
var pickups: Array[LootPickup] = []
var picked: Dictionary = {}
var pickup_specs: Array[Dictionary] = []
var npc_position := Vector3(18, 0, 32)
var talked_to_npc := false
var interaction_text := ""
var nearest_pickup: LootPickup
var npc_in_range := false
var proximity_clock := 0.0
var autosave_clock := 45.0
var telemetry_clock := 1.0
var ready_for_saves := false
# The title screen runs a fresh default world. Nothing may be written until the player
# continues a save or explicitly starts a new game; otherwise real progress is replaced.
var awaiting_session_choice := false
var web_visibility_callback: JavaScriptObject

func _ready() -> void:
	atmosphere = Atmosphere.new()
	add_child(atmosphere)
	TerrainBuilder.build(self)
	batcher = StaticBatcher.new()
	add_child(batcher)
	builder = WorldBuilder.new()
	builder.build(self, batcher)
	vegetation = VegetationSystem.new()
	add_child(vegetation)
	vegetation.build(builder.obstacles)
	resources = ResourceSystem.new()
	add_child(resources)
	resources.build(self, vegetation)
	navigation = NavigationGrid.new()
	navigation.build(builder.obstacles, _navigation_clear)
	noises = NoiseSystem.new()
	add_child(noises)
	player = PlayerController.new()
	player.safety_check = is_safe
	player.noise_emitted.connect(_player_noise)
	player.position = Vector3(4, 0.5, 31)
	add_child(player)
	buildings = BuildingSystem.new()
	buildings.world = self
	add_child(buildings)
	harvest_feedback = HarvestFeedback.new()
	harvest_feedback.player = player
	add_child(harvest_feedback)
	resources.harvested.connect(harvest_feedback.harvest)
	infection = InfectionSystem.new()
	add_child(infection)
	infection.build_markers(self)
	trader = TradingSystem.new()
	trader.world = self
	add_child(trader)
	clock = WorldClock.new()
	clock.world = self
	add_child(clock)
	_build_npc()
	family = FamilyQuest.new()
	family.world = self
	add_child(family)
	refresh_navigation()
	_build_pickup_specs()
	_spawn_pickups()
	for at in [Vector3(-3, 0.5, -25), Vector3(5, 0.5, -52), Vector3(34, 0.5, -12)]:
		var zombie := ZombieAI.new()
		zombie.id = "s01_infected_%02d" % zombies.size()
		zombie.position = at
		zombie.player = player
		zombie.world = self
		zombie.navigation = navigation
		add_child(zombie)
		zombies.append(zombie)
	actor_lod = ActorLOD.new()
	actor_lod.world = self
	add_child(actor_lod)
	var layer := CanvasLayer.new()
	layer.name = "MobileInterface"
	add_child(layer)
	hud = SurvivalHUD.new()
	hud.world = self
	layer.add_child(hud)
	player.controls = hud.controls
	family.changed.connect(func(): hud.toast(family.last_message))
	player.survival.damaged.connect(func(_amount: float): hud.flash_damage())
	player.survival.incapacitated.connect(func():
		buildings.cancel()
		hud.controls.reset_touches()
		hud.call_deferred("show_incapacitated")
	)
	hud.controls.look_changed.connect(player.rig.orbit)
	hud.controls.zoom_changed.connect(player.rig.zoom)
	hud.controls.interact_requested.connect(interact)
	GraphicsManager.settings_changed.connect(_apply_quality)
	_apply_quality()
	ready_for_saves = true
	if OS.has_feature("web"):
		web_visibility_callback = JavaScriptBridge.create_callback(_web_visibility_changed)
		JavaScriptBridge.get_interface("document").addEventListener("visibilitychange", web_visibility_callback)
	if DisplayServer.get_name() != "headless" and "--test" not in OS.get_cmdline_user_args():
		open_title()

func open_title() -> void:
	awaiting_session_choice = true
	hud.call_deferred("show_welcome")

func start_new_session() -> void:
	# Only the title's explicit new-game action (confirmed when a save exists) reaches here.
	awaiting_session_choice = false

func can_autosave() -> bool:
	return ready_for_saves and not awaiting_session_choice

func _on_backgrounded() -> void:
	if can_autosave():
		SaveManager.save_world(self)
	# Touch cleanup never depends on whether saving is currently allowed.
	if is_instance_valid(hud):
		hud.controls.reset_touches()

func _build_npc() -> void:
	var npc := CharacterVisual.new()
	guard_visual = npc
	npc.position = npc_position
	npc.rotation.y = -PI / 2
	add_child(npc)
	npc.build(false, true)
	var label := GeometryFactory.label(self, "林 · 营地守望者", npc_position + Vector3(0, 2.4, 0), 27, Color("c9cba4"))
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.pixel_size = 0.009
	label.visibility_range_end = 35
	GeometryFactory.box_collider(self, npc_position + Vector3.UP * 0.9, Vector3(0.6, 1.8, 0.6))

func _build_pickup_specs() -> void:
	var entries := [
		["food", 1, Vector3(5, 0, 29)], ["wood", 2, Vector3(9.5, 0, 31)],
		["stone", 2, Vector3(7.6, 0, 21)], ["food", 1, Vector3(3.5, 0, 12)],
		["food", 2, Vector3(-12, 0, -8)], ["food", 1, Vector3(-21, 0, -7)],
		["food", 1, Vector3(-26, 0, -13)], ["wood", 3, Vector3(44, 0, 22)],
		["wood", 2, Vector3(48, 0, 31)], ["wood", 2, Vector3(54, 0, 19)],
		["wood", 3, Vector3(59, 0, 38)], ["wood", 2, Vector3(-44, 0, 15)],
		["wood", 2, Vector3(-48, 0, 39)], ["stone", 3, Vector3(53, 0, 8)],
		["stone", 2, Vector3(-47, 0, -3)], ["stone", 3, Vector3(66, 0, 44)],
		["food", 1, Vector3(7.5, 0, -5)], ["food", 1, Vector3(-7, 0, 48)],
		["water", 3, Vector3(6, 0, 35)], ["water", 2, Vector3(-12, 0, -4)],
		["water", 3, Vector3(21, 0, 35)]
	]
	for i in range(entries.size()):
		var at: Vector3 = entries[i][2]
		at.y = TerrainBuilder.height_at(at.x, at.z) + 0.05
		pickup_specs.append({"id": "s01_loot_%02d" % i, "item": entries[i][0], "amount": entries[i][1], "at": at})

func _spawn_pickups() -> void:
	for pickup in pickups:
		if is_instance_valid(pickup):
			remove_child(pickup)
			pickup.queue_free()
	pickups.clear()
	nearest_pickup = null
	for spec in pickup_specs:
		if picked.has(spec["id"]):
			continue
		var pickup := LootPickup.new()
		pickup.position = spec["at"]
		add_child(pickup)
		pickup.build(spec["id"], spec["item"], spec["amount"])
		pickups.append(pickup)

func _process(delta: float) -> void:
	proximity_clock -= delta
	autosave_clock -= delta
	telemetry_clock -= delta
	if proximity_clock <= 0:
		proximity_clock = 0.16
		_update_proximity()
	if autosave_clock <= 0 and can_autosave():
		autosave_clock = 45
		SaveManager.save_world(self)
	if telemetry_clock <= 0:
		telemetry_clock = 1.0
		atmosphere.dust.position = player.position + Vector3.UP * 4

func publish_telemetry() -> void:
	# Read-only diagnostics for reproducible browser verification; no gameplay commands.
	var telemetry := {"fps": Engine.get_frames_per_second(), "quality": GraphicsManager.quality, "target_fps": GraphicsManager.target_fps, "position": [player.position.x, player.position.y, player.position.z], "inventory": InventorySystem.snapshot(), "modal": hud.current_modal, "picked_count": picked.size(), "zombies": zombies.size(), "stamina": player.stamina, "viewport": [hud.size.x, hud.size.y], "camera_yaw": player.rig.yaw, "camera_distance": player.rig.distance, "on_floor": player.is_on_floor(), "touches": [hud.controls.joystick_touch, hud.controls.look_touch], "buttons": hud.button_regions()}
	telemetry["build"] = ProjectSettings.get_setting("application/config/version")
	telemetry["save_state"] = {"persistent": SaveManager.persistence_available(), "error": SaveManager.last_error, "exists": SaveManager.exists()}
	telemetry["optimization"] = {"actor_lod":actor_lod.counters,"harvest_mark_pool":harvest_feedback.marks.size(),"harvest_sound_pool":harvest_feedback.sounds.size(),"rain_budget":clock.rain.amount,"building_shapes":buildings.placement_shapes.size()}
	telemetry["family"] = family.snapshot()
	telemetry["family_ai"] = {"decisions":family.member.decisions,"paths":family.member.paths,"sleeping":family.member.sleeping}
	telemetry["trader"] = trader.snapshot()
	telemetry["zone"] = infection.zone_at(player.position)
	telemetry["environment"] = clock.snapshot()
	telemetry["lighting"] = {"sun_energy":atmosphere.sun.light_energy,"rain":clock.rain.emitting,"headlamp":clock.headlamp.visible}
	telemetry["profile"] = OS.get_user_data_dir()
	telemetry["buildings"] = buildings.snapshot()
	telemetry["building_visuals"] = buildings.visual_snapshot()
	telemetry["safe"] = is_safe(player.position)
	telemetry["building_preview"] = {"type":buildings.selected,"at":[buildings.proposed.x,buildings.proposed.y,buildings.proposed.z],"reason":buildings.placement_reason}
	telemetry["feedback"] = {"count":harvest_feedback.accepted,"kind":harvest_feedback.last_kind,"animation":player.visual.harvest_time}
	telemetry["inventory_slots"] = InventorySystem.slots_used()
	telemetry["survival"] = player.survival.snapshot()
	telemetry["resources"] = resources.snapshot()
	telemetry["resource_hint"] = nearest_resource.get("id", "")
	telemetry["harvest_debug"] = resources.debug_snapshot()
	telemetry["infected"] = []
	for zombie in zombies:
		telemetry["infected"].append({"id": zombie.id, "state": ZombieAI.State.keys()[zombie.state], "attacks": zombie.attacks_landed})
	JavaScriptBridge.eval("window.lastDawnTelemetry = " + JSON.stringify(telemetry) + ";", true)

func _update_proximity() -> void:
	if not buildings.selected.is_empty():
		interaction_text = "建造 %s · %s / 交互确认" % [BuildingSystem.TYPES[buildings.selected]["name"],buildings.placement_reason if not buildings.placement_reason.is_empty() else "可放置"]
		return
	nearest_pickup = null
	var nearest := 3.0 * 3.0
	for pickup in pickups:
		var sq := player.position.distance_squared_to(pickup.position)
		if sq < nearest:
			# Prevent picking through supermarket walls.
			var ray := PhysicsRayQueryParameters3D.create(player.global_position + Vector3.UP, pickup.global_position + Vector3.UP * 0.5, 1)
			if get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
				nearest = sq
				nearest_pickup = pickup
	npc_in_range = player.position.distance_squared_to(npc_position) < 3.5 * 3.5
	nearest_resource = resources.nearest(player) if nearest_pickup == null and not npc_in_range else {}
	if nearest_pickup:
		interaction_text = "%s × %d   ·   点击交互拾取" % [InventorySystem.ITEMS[nearest_pickup.item]["name"], nearest_pickup.amount]
	elif npc_in_range:
		interaction_text = "林 · 营地守望者   /   点击交互交谈"
	elif trader.in_range():
		interaction_text = "周 · 流浪商人 / 点击交互交换物资"
	elif not nearest_resource.is_empty():
		interaction_text = "%s · 剩余 %d   /   点击交互采集" % ["树木" if nearest_resource["kind"] == "tree" else "矿石", nearest_resource["remaining"]]
	elif family.in_range():
		interaction_text = "小雨 · 家人 / 点击交互交谈"
	elif not buildings.nearest_fire(player.position).is_empty():
		interaction_text = "篝火 · 交互点燃或熄灭"
	else:
		interaction_text = ""

func interact() -> void:
	if hud.current_modal != "" or not player.survival.alive():
		return
	if not buildings.selected.is_empty():
		buildings.place_preview()
		hud.toast(buildings.last_message)
		return
	_update_proximity()
	if nearest_pickup:
		var pickup := nearest_pickup
		if not InventorySystem.add_item(pickup.item, pickup.amount):
			hud.toast("物品数量已达上限，物资仍在原处")
			return
		picked[pickup.id] = true
		hud.toast("获得 %s × %d" % [InventorySystem.ITEMS[pickup.item]["name"], pickup.amount])
		pickups.erase(pickup)
		pickup.queue_free()
		nearest_pickup = null
		_update_proximity()
	elif npc_in_range:
		talked_to_npc = true
		hud.show_npc()
	elif trader.in_range():
		hud.show_trading()
	elif not nearest_resource.is_empty():
		resources.harvest(nearest_resource["id"], player)
		hud.toast(resources.last_message)
		_update_proximity()
	elif family.in_range():
		hud.show_family()
	elif not buildings.nearest_fire(player.position).is_empty():
		buildings.toggle_fire(buildings.nearest_fire(player.position)["id"])
		hud.toast(buildings.last_message)
	else:
		hud.toast("靠近物资、树木、矿石或营地守望者后再交互")

func use_item(id: String) -> bool:
	if not player.survival.can_consume(id) or int(InventorySystem.items.get(id, 0)) <= 0:
		hud.toast("无需补充，或背包中没有该物品")
		return false
	if not InventorySystem.remove_item(id, 1):
		return false
	player.survival.consume(id)
	hud.toast("已使用 %s" % InventorySystem.ITEMS[id]["name"])
	return true

func is_safe(at: Vector3) -> bool:
	return Rect2(11, 25, 22, 25).has_point(Vector2(at.x, at.z)) or (is_instance_valid(buildings) and buildings.safe_shelter(at))

func create_snapshot() -> Dictionary:
	var data := {"version": SaveManager.VERSION, "state_id": "state_01", "position": [player.position.x, player.position.y, player.position.z], "inventory": InventorySystem.snapshot(), "settings": GraphicsManager.snapshot(), "picked": picked.keys(), "stamina": player.stamina, "camera_yaw": player.rig.yaw, "camera_pitch": player.rig.pitch, "camera_distance": player.rig.distance, "talked_to_npc": talked_to_npc}
	data["phase2"] = {"content_revision":1,"buildings":buildings.snapshot(),"trader":trader.snapshot(),"environment":clock.snapshot(),"family":family.snapshot()}
	data["survival"] = player.survival.snapshot()
	data["resources"] = resources.snapshot()
	data["infected"] = []
	for zombie in zombies:
		data["infected"].append(zombie.snapshot())
	return data

func restore_snapshot(data: Dictionary) -> void:
	# Direct callers have the same validation boundary as disk loading.
	data = SaveManager.prepare_snapshot(data)
	if data.is_empty():
		return
	var pos: Array = data["position"]
	player.position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
	player.position.y = maxf(player.position.y, TerrainBuilder.height_at(player.position.x, player.position.z) + 0.05)
	player.velocity = Vector3.ZERO
	player.stamina = clampf(float(data.get("stamina", 100)), 0, 100)
	player.survival.restore(data.get("survival", {"stamina": player.stamina, "settings": player.survival.settings.duplicate()}))
	player.rig.yaw = wrapf(float(data.get("camera_yaw", 0)), -PI, PI)
	player.rig.pitch = clampf(float(data.get("camera_pitch", -0.27)), -1.1, 0.34)
	player.rig.distance = clampf(float(data.get("camera_distance", 5.8)), 3, 10)
	InventorySystem.restore(data["inventory"])
	GraphicsManager.restore(data["settings"])
	picked.clear()
	for id in data.get("picked", []):
		picked[id] = true
	talked_to_npc = bool(data.get("talked_to_npc", false))
	hud.controls.reset_touches()
	_spawn_pickups()
	resources.restore(data.get("resources", {}))
	buildings.restore(data["phase2"]["buildings"])
	trader.restore(data["phase2"]["trader"])
	clock.restore(data["phase2"]["environment"])
	family.restore(data["phase2"]["family"])
	awaiting_session_choice = false # A validated save was restored: this is a real session.
	noises.clear()
	for zombie in zombies:
		var saved_ai := {}
		for entry in data.get("infected", []):
			if entry["id"] == zombie.id:
				saved_ai = entry
		zombie.restore(saved_ai)
	_update_proximity()
	if not player.survival.alive():
		hud.call_deferred("show_incapacitated")

func request_state(id: String) -> bool:
	# One playable state in this phase; other entries remain explicitly unavailable.
	return id == "state_01" and registry.can_enter(id)

func _apply_quality() -> void:
	batcher.apply_distance(float(GraphicsManager.preset()["distance"]))
	for zombie in zombies:
		for mesh in zombie.visual.find_children("*", "GeometryInstance3D", true, false):
			mesh.visibility_range_end = float(GraphicsManager.preset()["distance"])

func _web_visibility_changed(_args: Array) -> void:
	if JavaScriptBridge.get_interface("document").hidden:
		_on_backgrounded()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED:
		_on_backgrounded()

func _exit_tree() -> void:
	if OS.has_feature("web") and web_visibility_callback != null:
		JavaScriptBridge.get_interface("document").removeEventListener("visibilitychange", web_visibility_callback)

func _navigation_clear(from_point: Vector3, to_point: Vector3) -> bool:
	var query := PhysicsRayQueryParameters3D.create(from_point + Vector3.UP, to_point + Vector3.UP, 1)
	return get_world_3d().direct_space_state.intersect_ray(query).is_empty()

func refresh_navigation() -> void:
	var obstacles: Array[Rect2] = builder.obstacles.duplicate()
	if is_instance_valid(buildings): obstacles.append_array(buildings.navigation_obstacles())
	obstacles.append(Rect2(Vector2(npc_position.x-0.35,npc_position.z-0.35),Vector2(0.7,0.7)))
	if is_instance_valid(trader): obstacles.append(Rect2(Vector2(trader.at.x-0.4,trader.at.z-0.4),Vector2(0.8,0.8)))
	navigation.build(obstacles,_navigation_clear)
	for zombie in zombies: zombie.repath_clock = 0

func _player_noise(at: Vector3, radius: float) -> void:
	noises.emit_noise(at,radius*infection.noise_factor(at) if is_instance_valid(infection) else radius)
