class_name ZombieAI
extends CharacterBody3D
enum State { PATROL, CHASE, INVESTIGATE, SLEEP, ATTACK, RETURN }
const THINK_INTERVAL := 0.25
const ATTACK_RANGE := 1.65
const WINDUP := 0.55
var id := ""
var state := State.PATROL
var player: PlayerController
var world: Node3D
var navigation: NavigationGrid
var visual: CharacterVisual
var home := Vector3.ZERO
var last_seen := Vector3.ZERO
var target := Vector3.ZERO
var route := PackedVector3Array()
var route_index := 0
var think_clock := 0.0
var repath_clock := 0.0
var investigate_time := 0.0
var patrol_index := 0
var patrol_points: Array[Vector3] = []
var decision_count := 0
var path_count := 0
var last_noise_serial := 0
var attack_cooldown := 0.0
var windup := 0.0
var attacks_landed := 0

func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	floor_snap_length = 0.35
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.30
	shape.height = 1.8
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	visual = CharacterVisual.new()
	add_child(visual)
	visual.build(true)
	home = position
	patrol_points = [home + Vector3(0, 0, -8), home + Vector3(4, 0, -3), home + Vector3(0, 0, 5), home + Vector3(-3, 0, 0)]
	target = patrol_points[0]
	think_clock = float(get_index() % 4) * THINK_INTERVAL / 4.0

func _physics_process(delta: float) -> void:
	if player == null:
		return
	think_clock -= delta
	repath_clock -= delta
	attack_cooldown = maxf(0, attack_cooldown - delta)
	if think_clock <= 0:
		_think()
		think_clock = 1.0 if state == State.SLEEP else THINK_INTERVAL
	if state == State.SLEEP:
		return
	if state == State.INVESTIGATE:
		investigate_time = maxf(0, investigate_time - delta)
		if investigate_time <= 0:
			state = State.RETURN
	_combat_step(delta)
	var direction := Vector3.ZERO
	if route_index < route.size():
		var next := route[route_index]
		next.y = position.y
		if position.distance_squared_to(next) < 1.0:
			route_index += 1
		else:
			direction = (next - position).normalized()
	# A 2 m grid endpoint plus the waypoint arrival radius can stop outside melee reach.
	# CHASE is sight-confirmed at 4 Hz; complete the last few metres toward the real target.
	var close_target := player.position - position
	close_target.y = 0
	var finish_approach := route_index >= route.size() and not route.is_empty() and close_target.length_squared() < 6.0 * 6.0
	if state == State.CHASE and (close_target.length_squared() < 3.0 * 3.0 or finish_approach):
		direction = close_target.normalized()
	if state == State.ATTACK:
		direction = Vector3.ZERO
	if world.is_safe(position + direction * 1.5):
		direction = Vector3.ZERO
		state = State.RETURN
	var speed := 2.25 if state == State.CHASE else 0.85
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	velocity.y = 0.0 if is_on_floor() else velocity.y - 20.0 * delta
	move_and_slide()
	if direction.length_squared() > 0.05:
		visual.rotation.y = lerp_angle(visual.rotation.y, atan2(-direction.x, -direction.z), delta * 5)
	visual.animate(delta, direction.length() * speed)
	visual.rotation.x = -0.16 if windup > 0 else 0.0
	if windup > 0:
		visual.left_arm.rotation.x = -1.3
		visual.right_arm.rotation.x = -1.3

func _think() -> void:
	decision_count += 1
	var distance_sq := position.distance_squared_to(player.position)
	if distance_sq > 55.0 * 55.0 or not player.survival.alive():
		state = State.SLEEP
		velocity = Vector3.ZERO
		windup = 0
		return
	if state == State.SLEEP:
		state = State.PATROL
	var protected: bool = world.is_safe(player.position)
	var visible_player := false
	if not protected and distance_sq < 18.0 * 18.0:
		visible_player = _clear_sight()
	if visible_player:
		state = State.ATTACK if _in_attack_range() else State.CHASE
		last_seen = player.position
		investigate_time = 7.0
		last_noise_serial = world.noises.serial
	elif state == State.CHASE or state == State.ATTACK:
		state = State.INVESTIGATE
		investigate_time = 7.0
		windup = 0
	if not visible_player and not protected:
		var heard: Dictionary = world.noises.heard(position, last_noise_serial)
		if not heard.is_empty():
			last_noise_serial = heard["serial"]
			last_seen = heard["at"]
			state = State.INVESTIGATE
			investigate_time = 5.0
	if state == State.CHASE or state == State.ATTACK:
		target = player.position
	elif state == State.INVESTIGATE:
		target = last_seen
	elif state == State.RETURN:
		target = home
		if Vector2(position.x - home.x, position.z - home.z).length_squared() < 3:
			state = State.PATROL
	else:
		if Vector2(position.x - target.x, position.z - target.z).length_squared() < 3.0:
			patrol_index = (patrol_index + 1) % patrol_points.size()
		target = patrol_points[patrol_index]
	if repath_clock <= 0:
		repath_clock = 1.0 if state == State.CHASE else 1.8
		route = navigation.path(position, target)
		route_index = 1 if route.size() > 1 else 0
		path_count += 1

func _in_attack_range() -> bool:
	return Vector2(position.x - player.position.x, position.z - player.position.z).length_squared() <= ATTACK_RANGE * ATTACK_RANGE and absf(position.y - player.position.y) < 1.6

func _clear_sight() -> bool:
	var ray := PhysicsRayQueryParameters3D.create(global_position + Vector3.UP * 1.5, player.global_position + Vector3.UP * 1.3, 1)
	return get_world_3d().direct_space_state.intersect_ray(ray).is_empty()

func _combat_step(delta: float) -> void:
	if state != State.ATTACK or world.is_safe(player.position) or not player.survival.alive() or not _in_attack_range():
		windup = 0
		return
	if windup > 0:
		windup = maxf(0, windup - delta)
		if windup == 0 and _clear_sight():
			if player.survival.take_damage(float(player.survival.settings["zombie_damage"])):
				attacks_landed += 1
	elif attack_cooldown <= 0 and _clear_sight():
		windup = WINDUP
		attack_cooldown = float(player.survival.settings["attack_interval"])

func snapshot() -> Dictionary:
	return {"id": id, "position": [position.x, position.y, position.z], "state": state,
		"last_seen": [last_seen.x, last_seen.y, last_seen.z], "investigate_time": investigate_time,
		"patrol_index": patrol_index, "attack_cooldown": attack_cooldown}

func restore(data: Dictionary) -> void:
	var at: Array = data.get("position", [home.x, home.y, home.z])
	position = Vector3(float(at[0]), float(at[1]), float(at[2]))
	position.y = maxf(position.y, TerrainBuilder.height_at(position.x, position.z) + 0.05)
	var seen: Array = data.get("last_seen", [home.x, home.y, home.z])
	last_seen = Vector3(float(seen[0]), float(seen[1]), float(seen[2]))
	state = clampi(int(data.get("state", State.PATROL)), 0, State.RETURN) as State
	if state == State.ATTACK:
		state = State.CHASE # Loading never resolves an old pending hit.
	investigate_time = clampf(float(data.get("investigate_time", 0)), 0, 7)
	patrol_index = clampi(int(data.get("patrol_index", 0)), 0, patrol_points.size() - 1)
	attack_cooldown = clampf(float(data.get("attack_cooldown", 0)), 0.8, 4)
	windup = 0
	velocity = Vector3.ZERO
	route.clear()
	target = home
	last_noise_serial = world.noises.serial
	repath_clock = 0
	think_clock = 0
