class_name ActorLOD
extends Node3D
## Six fixed proxies; visual LOD never changes AI, collision, or touch ownership.
const NEAR_DISTANCES := [12.0,16.0,24.0,28.0,32.0]
var world: Node3D
var entries: Array[Dictionary] = []
var clock := 0.0
var counters := {"near":0,"far":0,"culled":0}
var capsule: CapsuleMesh

func _ready() -> void:
	capsule = CapsuleMesh.new()
	capsule.radius = 0.28
	capsule.height = 1.75
	capsule.radial_segments = 6
	capsule.rings = 2
	_add(world.guard_visual,world.guard_visual,false)
	_add(world.trader,world.trader.visual,false)
	_add(world.family.member,world.family.member.visual,false)
	for zombie in world.zombies: _add(zombie,zombie.visual,true)
	refresh()

func _add(body: Node3D, detail: Node3D, infected: bool) -> void:
	var mat := GeometryFactory.material("infected_far" if infected else "survivor_far",Color("515741") if infected else Color("8e8c71"))
	var proxy := GeometryFactory.mesh_node(self,capsule,mat,Vector3.ZERO,Vector3.ONE)
	proxy.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	entries.append({"body":body,"detail":detail,"proxy":proxy})

func _process(delta: float) -> void:
	clock -= delta
	if clock <= 0:
		clock = 0.5
		refresh()

func refresh() -> void:
	var limit: float = GraphicsManager.preset()["distance"]
	var near_distance: float = NEAR_DISTANCES[GraphicsManager.quality]
	counters = {"near":0,"far":0,"culled":0}
	for entry in entries:
		var body: Node3D = entry["body"]
		var detail: Node3D = entry["detail"]
		var proxy: MeshInstance3D = entry["proxy"]
		var sq := body.global_position.distance_squared_to(world.player.global_position)
		detail.visible = sq<near_distance*near_distance
		proxy.visible = sq>=near_distance*near_distance and sq<limit*limit
		proxy.global_position = body.global_position+Vector3.UP*0.88
		proxy.rotation.y = detail.global_rotation.y
		var key := "near" if detail.visible else ("far" if proxy.visible else "culled")
		counters[key] += 1
