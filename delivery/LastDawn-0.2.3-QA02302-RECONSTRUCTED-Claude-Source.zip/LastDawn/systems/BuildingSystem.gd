class_name BuildingSystem
extends Node3D
signal changed
const LIMIT := 24
const TYPES := {
	"shelter": {"name":"简易避难所", "cost":{"wood":8,"stone":3}, "size":Vector3(3.6,2.6,3.2)},
	"wall": {"name":"围墙", "cost":{"wood":3,"stone":1}, "size":Vector3(2.4,1.8,0.45)},
	"campfire": {"name":"篝火", "cost":{"wood":2,"stone":2}, "size":Vector3(1.4,0.8,1.4)}
}
var world: Node3D
var records: Array[Dictionary] = []
var nodes: Dictionary = {}
var selected := ""
var proposed := Vector3.ZERO
var proposed_yaw := 0.0
var placement_reason := ""
var last_message := ""
var ghost: MeshInstance3D
var ghost_material: StandardMaterial3D
var clock := 0.0
var visual_clock := 0.0
var next_id := 1
var placement_shapes: Dictionary = {}
var placement_query := PhysicsShapeQueryParameters3D.new()

func _ready() -> void:
	ghost_material = StandardMaterial3D.new()
	ghost_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ghost_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ghost = GeometryFactory.mesh_node(self, GeometryFactory.box_mesh(), ghost_material, Vector3.ZERO, Vector3.ONE)
	ghost.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ghost.visible = false
	for kind in TYPES:
		var shape := BoxShape3D.new()
		var dimensions: Vector3 = TYPES[kind]["size"]
		shape.size = Vector3(dimensions.x+0.2,dimensions.y-0.15,dimensions.z+0.2)
		placement_shapes[kind] = shape
	placement_query.collision_mask = 7

func begin(kind: String) -> void:
	if not TYPES.has(kind): return
	selected = kind
	clock = 0
	update_preview()

func cancel() -> void:
	selected = ""
	ghost.visible = false

func _process(delta: float) -> void:
	clock -= delta
	visual_clock -= delta
	if not selected.is_empty() and clock <= 0:
		clock = 0.16
		update_preview()
	if selected.is_empty(): ghost.visible = false
	if visual_clock <= 0:
		visual_clock = 0.5
		_update_visibility()

func update_preview() -> void:
	if selected.is_empty(): return
	proposed_yaw = roundf(world.player.rig.yaw / (PI * 0.5)) * PI * 0.5
	proposed = world.player.position + Vector3(0,0,-4.5).rotated(Vector3.UP, world.player.rig.yaw)
	proposed.x = snappedf(proposed.x, 0.5)
	proposed.z = snappedf(proposed.z, 0.5)
	proposed.y = TerrainBuilder.height_at(proposed.x, proposed.z)
	placement_reason = check_place(selected, proposed, proposed_yaw)
	if placement_reason.is_empty() and not InventorySystem.can_pay(TYPES[selected]["cost"]): placement_reason = "材料不足"
	ghost.position = proposed + Vector3.UP * 0.08
	var dimensions: Vector3 = TYPES[selected]["size"]
	ghost.scale = Vector3(dimensions.x,0.08,dimensions.z)
	ghost.rotation.y = proposed_yaw
	ghost_material.albedo_color = Color(0.4,0.8,0.5,0.5) if placement_reason.is_empty() else Color(0.9,0.35,0.25,0.5)
	ghost.visible = world.hud.current_modal.is_empty() and world.player.survival.alive()

func footprint(kind: String, at: Vector3, yaw: float) -> Rect2:
	var dimensions: Vector3 = TYPES[kind]["size"]
	var extent := Vector2(dimensions.x, dimensions.z)
	if absf(sin(yaw)) > 0.7: extent = Vector2(extent.y,extent.x)
	return Rect2(Vector2(at.x,at.z) - extent * 0.5, extent)

func check_place(kind: String, at: Vector3, yaw: float) -> String:
	if not TYPES.has(kind): return "未知建造物"
	if records.size() >= LIMIT: return "已达到 24 个建造物上限"
	if not world.player.survival.alive(): return "失能时不能建造"
	if not at.is_finite() or absf(at.x) > 93 or absf(at.z) > 93: return "超出地图建造范围"
	if world.player.position.distance_to(at) > 6: return "距离太远"
	var rect := footprint(kind,at,yaw).grow(0.3)
	if rect.intersects(Rect2(-5.5,-98,11,196)) or rect.intersects(Rect2(10.5,24,23,28)):
		return "请避开公路和公共营地"
	for obstacle in world.builder.obstacles:
		if rect.intersects(obstacle): return "与原有建筑或车辆重叠"
	for record in records:
		if rect.intersects(footprint(record["type"],_position(record),record["yaw"]).grow(0.2)): return "与建造物重叠"
	var heights := []
	for point in [rect.position, rect.end, Vector2(rect.position.x,rect.end.y), Vector2(rect.end.x,rect.position.y)]:
		heights.append(TerrainBuilder.height_at(point.x,point.y))
	if float(heights.max()) - float(heights.min()) > 0.45: return "坡度过大"
	var dimensions: Vector3 = TYPES[kind]["size"]
	var query := placement_query
	query.shape = placement_shapes[kind]
	query.transform = Transform3D(Basis(Vector3.UP,yaw),at+Vector3.UP*(dimensions.y*0.5+0.16))
	if not get_world_3d().direct_space_state.intersect_shape(query,8).is_empty(): return "场地有树木、岩石或角色"
	var ray := PhysicsRayQueryParameters3D.create(world.player.position+Vector3.UP,at+Vector3.UP,1)
	if not get_world_3d().direct_space_state.intersect_ray(ray).is_empty(): return "无法隔墙建造"
	return ""

func place_preview() -> bool:
	if selected.is_empty(): return false
	update_preview()
	return place(selected,proposed,proposed_yaw)

func place(kind: String, at: Vector3, yaw: float) -> bool:
	last_message = check_place(kind,at,yaw)
	if not last_message.is_empty(): return false
	if not InventorySystem.transact(TYPES[kind]["cost"],{}):
		last_message = "材料不足，未扣除物品"
		return false
	var record := {"id":"s01_build_%04d" % next_id,"type":kind,"position":[at.x,at.y,at.z],"yaw":yaw,"lit":kind=="campfire"}
	next_id += 1
	records.append(record)
	_spawn(record)
	last_message = "已建造 %s" % TYPES[kind]["name"]
	world.refresh_navigation()
	changed.emit()
	return true

func _position(record: Dictionary) -> Vector3:
	var at: Array = record["position"]
	return Vector3(at[0],at[1],at[2])

func _box(root: Node3D, at: Vector3, size: Vector3, material: Material, collision: bool = true) -> void:
	GeometryFactory.mesh_node(root,GeometryFactory.box_mesh(),material,at,size)
	if collision: GeometryFactory.box_collider(root,at,size)

func _spawn(record: Dictionary) -> void:
	var root := Node3D.new()
	root.position = _position(record)
	root.rotation.y = record["yaw"]
	add_child(root)
	nodes[record["id"]] = root
	var timber := GeometryFactory.material("built_wood",Color("786a4d"),"wood")
	var stone := GeometryFactory.material("built_stone",Color("79796c"),"rock")
	var cloth := GeometryFactory.material("built_tarp",Color("58664e"),"cloth")
	match record["type"]:
		"wall":
			_box(root,Vector3(0,0.9,0),Vector3(2.4,1.8,0.4),timber)
			for x in [-1.1,1.1]: _box(root,Vector3(x,1,0),Vector3(0.16,2.0,0.55),stone)
		"shelter":
			_box(root,Vector3(0,1.15,1.5),Vector3(3.6,2.3,0.14),timber)
			for x in [-1.7,1.7]: _box(root,Vector3(x,1.15,0),Vector3(0.14,2.3,3.2),timber)
			_box(root,Vector3(0,2.5,0),Vector3(3.8,0.18,3.5),cloth)
			_box(root,Vector3(0,0.12,0.8),Vector3(1.5,0.2,1.1),cloth,false)
		"campfire":
			for i in range(6):
				var angle := float(i)*TAU/6
				GeometryFactory.mesh_node(root,GeometryFactory.sphere_mesh(),stone,Vector3(cos(angle)*0.5,0.12,sin(angle)*0.5),Vector3(0.3,0.24,0.3))
			_box(root,Vector3(0,0.18,0),Vector3(0.8,0.16,0.25),timber)
			var flame := GeometryFactory.mesh_node(root,GeometryFactory.sphere_mesh(),GeometryFactory.material("built_flame",Color("d99447"),"",1.5),Vector3(0,0.5,0),Vector3(0.28,0.58,0.28))
			flame.name = "Flame"
			flame.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var light := OmniLight3D.new()
			light.name = "FireLight"
			light.position.y = 0.8
			light.omni_range = 7
			light.light_color = Color("f2b370")
			light.light_energy = 1.1
			light.shadow_enabled = false
			root.add_child(light)
			GeometryFactory.box_collider(root,Vector3(0,0.18,0),Vector3(0.9,0.35,0.9))
	var detail := Node3D.new()
	detail.name = "Detail"
	root.add_child(detail)
	for child in root.get_children():
		if child is MeshInstance3D and child.name!="Flame":
			root.remove_child(child)
			detail.add_child(child)
	var dimensions: Vector3 = TYPES[record["type"]]["size"]
	var proxy := GeometryFactory.mesh_node(root,GeometryFactory.box_mesh(),cloth if record["type"]=="shelter" else timber,Vector3.UP*dimensions.y*0.5,dimensions)
	proxy.name = "FarProxy"
	proxy.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_update_visibility()

func _update_visibility() -> void:
	if not is_instance_valid(world) or not is_instance_valid(world.player): return
	var distance: float = GraphicsManager.preset()["distance"]
	var light_budget := 2 if GraphicsManager.quality >= 2 else 0
	for record in records:
		var root: Node3D = nodes[record["id"]]
		var nearby := root.position.distance_squared_to(world.player.position) < distance*distance
		root.visible = nearby
		var near_detail := root.position.distance_squared_to(world.player.position)<pow(minf(28,distance*0.5),2)
		root.get_node("Detail").visible = near_detail
		root.get_node("FarProxy").visible = not near_detail
		if record["type"] == "campfire":
			root.get_node("Flame").visible = record["lit"]
			var light: OmniLight3D = root.get_node("FireLight")
			light.visible = nearby and record["lit"] and light_budget > 0 and root.position.distance_squared_to(world.player.position) < 18*18
			if light.visible: light_budget -= 1

func safe_shelter(at: Vector3) -> bool:
	for record in records:
		if record["type"]=="shelter" and footprint("shelter",_position(record),record["yaw"]).grow(-0.3).has_point(Vector2(at.x,at.z)):
			return true
	return false

func nearest_fire(at: Vector3) -> Dictionary:
	for record in records:
		if record["type"]=="campfire" and _position(record).distance_squared_to(at)<2.8*2.8: return record
	return {}

func toggle_fire(id: String) -> void:
	for record in records:
		if record["id"]==id and record["type"]=="campfire":
			record["lit"] = not record["lit"]
			last_message = "篝火已点燃" if record["lit"] else "篝火已熄灭"
			_update_visibility()
			changed.emit()

func navigation_obstacles() -> Array[Rect2]:
	var result: Array[Rect2] = []
	for record in records:
		result.append(footprint(record["type"],_position(record),record["yaw"]))
	return result

func snapshot() -> Dictionary:
	return {"next_id":next_id,"records":records.duplicate(true)}

func visual_snapshot() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for record in records:
		var root: Node3D = nodes[record["id"]]
		result.append({"id":record["id"],"visible":root.visible,"detail":root.get_node("Detail").visible,"proxy":root.get_node("FarProxy").visible,"flame":root.get_node("Flame").visible if record["type"]=="campfire" else false})
	return result

func restore(data: Dictionary) -> void:
	cancel()
	for root in nodes.values():
		remove_child(root)
		root.queue_free()
	nodes.clear()
	records.clear()
	next_id = int(data.get("next_id",1))
	for entry in data.get("records",[]):
		var record: Dictionary = entry.duplicate(true)
		records.append(record)
		_spawn(record)
	world.refresh_navigation()
	changed.emit()
