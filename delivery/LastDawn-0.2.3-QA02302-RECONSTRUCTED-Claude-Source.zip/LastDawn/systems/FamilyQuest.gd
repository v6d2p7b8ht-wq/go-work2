class_name FamilyQuest
extends Node
signal changed
const STAGES := ["not_started","following","waiting","evacuated"]
const DESTINATION := Rect2(14,30,14,16)
const REWARD := {"food":2,"water":2}
var world: Node3D
var member: FamilyCompanion
var stage := "not_started"
var reward_claimed := false
var arrival_time := 0.0
var last_message := ""
var clock := 0.0

func _ready() -> void:
	member = FamilyCompanion.new()
	member.world = world
	member.quest = self
	world.add_child(member)

func in_range() -> bool:
	return world.player.position.distance_squared_to(member.position)<3.5*3.5

func start_following() -> bool:
	if stage=="evacuated" or not in_range() or not world.player.survival.alive(): return false
	stage = "following"
	arrival_time = 0
	member.reset_route()
	last_message = "小雨开始跟随 · 步行带她进入东侧营地深处"
	changed.emit()
	return true

func wait_here() -> bool:
	if stage!="following" or not in_range() or not world.player.survival.alive(): return false
	stage = "waiting"
	arrival_time = 0
	member.reset_route()
	last_message = "小雨在原地等待；回来靠近她可继续带领"
	changed.emit()
	return true

func _process(delta: float) -> void:
	clock += minf(delta,0.25)
	if clock>=0.25:
		check_arrival(clock)
		clock = 0

func _inside(at: Vector3) -> bool:
	return DESTINATION.has_point(Vector2(at.x,at.z))

func check_arrival(seconds: float) -> void:
	if stage!="following": return
	if not world.player.survival.alive() or not _inside(member.position) or not _inside(world.player.position) or member.position.distance_squared_to(world.player.position)>7*7:
		arrival_time = 0
		return
	arrival_time = minf(2,arrival_time+maxf(0,seconds))
	if arrival_time>=2:
		stage = "evacuated"
		member.reset_route()
		last_message = "家人撤离完成 · 小雨留在营地"
		if not claim_reward(): last_message += "；行囊已满，可在任务页稍后领取补给"
		world.registry.publish(&"family_changed",{"id":"family_xiaoyu","stage":stage})
		changed.emit()

func claim_reward() -> bool:
	if stage!="evacuated" or reward_claimed or not world.player.survival.alive() or not InventorySystem.transact({},REWARD): return false
	reward_claimed = true
	last_message = "撤离补给已领取 · 食品2 / 饮水2"
	changed.emit()
	return true

func snapshot() -> Dictionary:
	return {"id":"family_xiaoyu","stage":stage,"position":[member.position.x,member.position.y,member.position.z],"reward_claimed":reward_claimed,"arrival_time":arrival_time}

func restore(data: Dictionary) -> void:
	stage = data.get("stage","not_started")
	reward_claimed = bool(data.get("reward_claimed",false))
	arrival_time = float(data.get("arrival_time",0))
	var at: Array = data.get("position",[FamilyCompanion.HOME.x,FamilyCompanion.HOME.y,FamilyCompanion.HOME.z])
	member.position = Vector3(float(at[0]),float(at[1]),float(at[2]))
	member.position.y = maxf(member.position.y,TerrainBuilder.height_at(member.position.x,member.position.z)+0.05)
	member.reset_route()
	clock = 0
	last_message = ""
