class_name FrameTimeWindow
extends RefCounted
## Wall-clock intervals, not delta, target FPS, physics ticks or repeated frames.
const WINDOW_MS := 10000.0
const MAX_SAMPLES := 2400
var intervals: Array[float] = []
var total_ms := 0.0

func clear() -> void:
	intervals.clear()
	total_ms = 0.0

func push_ms(ms: float) -> void:
	if not is_finite(ms) or ms <= 0:
		return
	intervals.append(ms)
	total_ms += ms
	while intervals.size() > 1 and (total_ms > WINDOW_MS or intervals.size() > MAX_SAMPLES):
		total_ms -= intervals.pop_front()

func snapshot() -> Dictionary:
	var count := intervals.size()
	if count == 0:
		return {"samples": 0, "seconds": 0.0, "average_fps": 0.0, "mean_ms": 0.0, "low_1_percent": 0.0, "ready": false}
	var mean := total_ms / count
	var ready := count >= 100 and total_ms >= 3000
	var low := 0.0
	if ready:
		var sorted := intervals.duplicate()
		sorted.sort()
		var slow_count := maxi(1, ceili(count * 0.01))
		var slow_ms := 0.0
		for i in range(slow_count):
			slow_ms += sorted[count - 1 - i]
		low = 1000.0 / (slow_ms / slow_count)
	return {"samples": count, "seconds": total_ms / 1000.0, "average_fps": 1000.0 / mean,
		"mean_ms": mean, "low_1_percent": low, "ready": ready}
