extends Node
signal settings_changed
const CONFIG_PATH := "user://graphics.cfg"
const LABELS := ["极低", "低", "中", "高", "极致"]
const FRAME_RATES := [30, 45, 60, 90, 120]
const PRESETS := [
	{"scale": 0.55, "shadow": 0, "foliage": 0.20, "distance": 48.0, "particles": 0, "lod": 5.0},
	{"scale": 0.67, "shadow": 512, "foliage": 0.36, "distance": 68.0, "particles": 0, "lod": 3.5},
	{"scale": 0.80, "shadow": 1024, "foliage": 0.58, "distance": 92.0, "particles": 12, "lod": 2.4},
	{"scale": 1.00, "shadow": 2048, "foliage": 0.80, "distance": 120.0, "particles": 24, "lod": 1.6},
	{"scale": 1.10, "shadow": 4096, "foliage": 1.00, "distance": 155.0, "particles": 40, "lod": 1.0}
]
var quality: int = 2
var target_fps: int = 30
var sensitivity: float = 0.0032
var loaded_from_disk := false
var status_message := ""

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.has_feature("web"):
		quality = 1
	elif OS.has_feature("android"):
		# An initial heuristic only; this does not assert measured performance.
		var memory := OS.get_memory_info()
		if OS.get_processor_count() >= 8 and int(memory.get("physical", 0)) >= 8 * 1024 * 1024 * 1024:
			quality = 4
			target_fps = 60
	load_settings()
	get_tree().root.size_changed.connect(_fit_orientation)
	call_deferred("_fit_orientation")
	call_deferred("apply")

func _fit_orientation() -> void:
	var window := get_tree().root
	var base := Vector2i(720, 1280) if window.size.y > window.size.x else Vector2i(1280, 720)
	if window.content_scale_size != base:
		window.content_scale_size = base

func preset() -> Dictionary:
	return PRESETS[quality]

func set_quality(value: int) -> void:
	quality = clampi(value, 0, 4)
	apply()
	persist()

func set_frame_rate(value: int) -> void:
	if value in FRAME_RATES:
		target_fps = value
		apply()
		persist()

func apply() -> void:
	Engine.max_fps = target_fps
	var view := get_viewport()
	view.scaling_3d_scale = float(preset()["scale"])
	view.mesh_lod_threshold = float(preset()["lod"])
	var shadow_size: int = int(preset()["shadow"])
	view.positional_shadow_atlas_size = maxi(shadow_size, 256)
	RenderingServer.directional_shadow_atlas_set_size(maxi(shadow_size, 256), true)
	# Web's setter is a no-op; its main loop is still driven by browser rAF.
	# Preserve the native high-refresh policy without pretending to unlock Safari.
	if not OS.has_feature("web") and DisplayServer.get_name() != "headless":
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	settings_changed.emit()

func snapshot() -> Dictionary:
	return {"quality": quality, "target_fps": target_fps, "sensitivity": sensitivity}

func restore(value: Dictionary) -> void:
	var q = value.get("quality", quality)
	var fps = value.get("target_fps", target_fps)
	var sense = value.get("sensitivity", sensitivity)
	if q is int or q is float:
		quality = clampi(int(q), 0, 4)
	if (fps is int or fps is float) and int(fps) in FRAME_RATES:
		target_fps = int(fps)
	if (sense is int or sense is float) and is_finite(float(sense)):
		sensitivity = clampf(float(sense), 0.001, 0.009)
	apply()
	persist()

func load_settings() -> bool:
	var config := ConfigFile.new()
	if config.load(CONFIG_PATH) != OK:
		return false
	var q = config.get_value("graphics", "quality", quality)
	var fps = config.get_value("graphics", "target_fps", target_fps)
	var sense = config.get_value("input", "sensitivity", sensitivity)
	if q is int:
		quality = clampi(q, 0, 4)
	if fps is int and fps in FRAME_RATES:
		target_fps = fps
	if (sense is float or sense is int) and is_finite(float(sense)):
		sensitivity = clampf(float(sense), 0.001, 0.009)
	loaded_from_disk = true
	return true

func persist() -> Error:
	var config := ConfigFile.new()
	config.set_value("graphics", "quality", quality)
	config.set_value("graphics", "target_fps", target_fps)
	config.set_value("input", "sensitivity", sensitivity)
	var result := config.save(CONFIG_PATH)
	status_message = "设置已保存" if result == OK else "设置保存失败：%s" % error_string(result)
	return result
