class_name HarvestFeedback
extends Node3D
## Fixed-size visual/audio pool. A successful transaction alone triggers feedback.
var player: PlayerController
var marks: Array[MeshInstance3D] = []
var timers: Array[float] = []
var sounds: Array[AudioStreamPlayer3D] = []
var cursor := 0
var accepted := 0
var last_kind := ""
var wood_sound: AudioStream
var ore_sound: AudioStream

func _ready() -> void:
	wood_sound = load("res://assets/audio/chop.wav")
	ore_sound = load("res://assets/audio/mine.wav")
	var material := GeometryFactory.material("harvest_flash", Color("e7c894"), "", 0.7)
	for i in range(4):
		var mark := GeometryFactory.mesh_node(self, GeometryFactory.sphere_mesh(), material, Vector3.ZERO, Vector3.ONE * 0.1)
		mark.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mark.visible = false
		marks.append(mark)
		timers.append(0.0)
	for i in range(2):
		var sound := AudioStreamPlayer3D.new()
		sound.max_distance = 25
		sound.unit_size = 4
		sound.volume_db = -8
		add_child(sound)
		sounds.append(sound)
	set_process(false)

func harvest(kind: String, at: Vector3, _rewards: Dictionary) -> void:
	accepted += 1
	last_kind = kind
	var index := cursor % marks.size()
	cursor += 1
	marks[index].position = at + Vector3.UP * 0.9
	marks[index].visible = true
	timers[index] = 0.48
	var sound := sounds[index % sounds.size()]
	sound.position = at + Vector3.UP
	sound.stream = wood_sound if kind == "tree" else ore_sound
	if DisplayServer.get_name() != "headless": sound.play()
	if is_instance_valid(player):
		player.visual.begin_harvest(kind)
		var toward := at - player.position
		if Vector2(player.velocity.x, player.velocity.z).length_squared() < 0.1:
			player.visual.rotation.y = atan2(-toward.x, -toward.z)
	set_process(true)

func _process(delta: float) -> void:
	var active := false
	for i in range(marks.size()):
		timers[i] = maxf(0, timers[i] - delta)
		marks[i].visible = timers[i] > 0
		if timers[i] > 0:
			active = true
			var radius := 0.08 + (0.48 - timers[i]) * 0.55
			marks[i].scale = Vector3(radius, radius * 0.35, radius)
	set_process(active)
