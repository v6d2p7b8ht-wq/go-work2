class_name InfectionSystem
extends Node
var model: Dictionary = {}

func _init() -> void:
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string("res://data/infection_zones.json"))==OK:
		model = parser.data

func zone_at(at: Vector3) -> Dictionary:
	var selected := {}
	var priority := -100
	for zone in model.get("zones",[]):
		var rect: Array = zone["rect"]
		if Rect2(rect[0],rect[1],rect[2],rect[3]).has_point(Vector2(at.x,at.z)) and int(zone["priority"])>priority:
			selected = zone
			priority = int(zone["priority"])
	return selected

func level_at(at: Vector3) -> int:
	return int(zone_at(at).get("level",2))

func noise_factor(at: Vector3) -> float:
	return float(model["levels"][level_at(at)-1]["noise_factor"])

func build_markers(root: Node3D) -> void:
	var material := GeometryFactory.material("infection_sign",Color("8a553f"),"rust")
	var post := GeometryFactory.material("infection_post",Color("5c665b"))
	for x in [-6.5,6.5]:
		var at := Vector3(x,0,-20)
		GeometryFactory.mesh_node(root,GeometryFactory.box_mesh(),post,at+Vector3.UP,Vector3(0.1,2,0.1))
		GeometryFactory.mesh_node(root,GeometryFactory.box_mesh(),material,at+Vector3.UP*1.7,Vector3(2,0.8,0.1))
		var label := GeometryFactory.label(root,"三级感染区\n降低声响",at+Vector3(0,1.7,0.07),25,Color("edd4a1"))
		label.visibility_range_end = 24
