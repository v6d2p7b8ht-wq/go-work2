extends Node
## Small, bounded inventory. Only known IDs can cross the save boundary.
signal changed
const ITEMS := {
	"wood": {"name": "木材", "unit": "块", "description": "从森林树木采集。用于简易避难所、围墙和篝火。"},
	"stone": {"name": "石头", "unit": "块", "description": "从矿石采集。用于建造与商人交换。"},
	"food": {"name": "食品", "unit": "份", "description": "罐头。使用后恢复 32 饱食、8 体力。"},
	"water": {"name": "饮水", "unit": "瓶", "description": "密封饮水。使用后恢复 45 饮水、5 体力。"},
	"ore": {"name": "矿物", "unit": "块", "description": "从矿石采集的金属矿物，可用于交换。"},
	"electronics": {"name":"电子元件","unit":"个","description":"商人供应的电子零件，可用于交换虚构装备蓝图。"},
	"blueprint": {"name":"曙光护具蓝图","unit":"份","description":"虚构装备设计图。目前作为物品保存，尚未解锁完整装备科技树。"}
}
const MAX_PER_ITEM := 9999
const MAX_SLOTS := 24
const STACKS := {"wood":50,"stone":50,"ore":50,"food":10,"water":10,"electronics":20,"blueprint":1}

var items: Dictionary = {"wood": 0, "stone": 0, "food": 0, "water": 0, "ore": 0, "electronics":0, "blueprint":0}

func can_add_items(rewards: Dictionary) -> bool:
	if rewards.is_empty():
		return false
	for id in rewards:
		var amount = rewards[id]
		if not ITEMS.has(id) or not amount is int or amount <= 0 or amount > MAX_PER_ITEM - int(items.get(id, 0)):
			return false
	var candidate := items.duplicate()
	for id in rewards: candidate[id] = int(candidate.get(id,0)) + int(rewards[id])
	return slots_used(candidate) <= MAX_SLOTS

func add_items(rewards: Dictionary) -> bool:
	# All or nothing: ore harvesting must never grant only half its output.
	if not can_add_items(rewards):
		return false
	for id in rewards:
		items[id] = int(items.get(id, 0)) + int(rewards[id])
	changed.emit()
	return true

func add_item(id: String, amount: int = 1) -> bool:
	return add_items({id: amount})

func snapshot() -> Dictionary:
	return items.duplicate(true)

func remove_item(id: String, amount: int = 1) -> bool:
	if not ITEMS.has(id) or amount <= 0 or int(items.get(id, 0)) < amount:
		return false
	items[id] -= amount
	changed.emit()
	return true

func restore(value: Dictionary) -> void:
	for id in ITEMS:
		var count = value.get(id, 0)
		items[id] = clampi(int(count), 0, 9999) if (count is int or count is float) and is_finite(float(count)) else 0
	changed.emit()

func total() -> int:
	var count := 0
	for value in items.values():
		count += int(value)
	return count

func slots_used(value: Dictionary = {}) -> int:
	if value.is_empty(): value = items
	var count := 0
	for id in value:
		count += ceili(float(value[id]) / float(STACKS.get(id,50)))
	return count

func transact(cost: Dictionary, reward: Dictionary) -> bool:
	if not can_pay(cost): return false
	var candidate := items.duplicate()
	for id in cost:
		candidate[id] = int(candidate.get(id,0)) - int(cost[id])
	for id in reward:
		if not ITEMS.has(id) or not reward[id] is int or reward[id] <= 0 or reward[id] > MAX_PER_ITEM - int(candidate.get(id,0)): return false
		candidate[id] = int(candidate.get(id,0)) + int(reward[id])
	var used := slots_used(candidate)
	if used > MAX_SLOTS and used > slots_used(): return false
	items = candidate
	changed.emit()
	return true

func can_pay(cost: Dictionary) -> bool:
	for id in cost:
		if not ITEMS.has(id) or not cost[id] is int or cost[id]<=0 or int(items.get(id,0))<cost[id]: return false
	return true
