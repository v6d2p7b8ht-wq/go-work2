class_name NavigationGrid
extends RefCounted
## One shared, coarse 2 m A* grid. No per-frame navmesh baking or navigation servers.
const CELL := 2.0
var grid: AStarGrid2D
var endpoint_clear: Callable

func build(obstacles: Array[Rect2], projection_clear: Callable = Callable()) -> void:
	endpoint_clear = projection_clear
	grid = AStarGrid2D.new()
	grid.region = Rect2i(-49, -49, 99, 99)
	grid.cell_size = Vector2.ONE * CELL
	grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	grid.default_estimate_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	grid.update()
	for rect in obstacles:
		# A thin fence halfway between 2 m sample points must occupy a grid column.
		# Retain existing clearance for larger walls so real doorways stay open.
		var padding := maxf(0.65,CELL*0.5-minf(rect.size.x,rect.size.y)*0.5+0.05)
		var padded := rect.grow(padding)
		for x in range(floori(padded.position.x / CELL), ceili(padded.end.x / CELL) + 1):
			for z in range(floori(padded.position.y / CELL), ceili(padded.end.y / CELL) + 1):
				var cell := Vector2i(x, z)
				if grid.is_in_boundsv(cell) and padded.has_point(Vector2(cell) * CELL):
					grid.set_point_solid(cell, true)

func path(from: Vector3, to: Vector3) -> PackedVector3Array:
	var result := PackedVector3Array()
	var start := Vector2i(roundi(from.x / CELL), roundi(from.z / CELL))
	var target := Vector2i(roundi(to.x / CELL), roundi(to.z / CELL))
	if not grid.is_in_boundsv(start) or not grid.is_in_boundsv(target):
		return result
	start = _walkable_near(start, from, to)
	target = _walkable_near(target, to, from)
	if not grid.is_in_boundsv(start) or not grid.is_in_boundsv(target):
		return result
	var points := grid.get_point_path(start, target, true)
	for point in points:
		result.append(Vector3(point.x, from.y, point.y))
	return result

func _walkable_near(cell: Vector2i, at: Vector3, approach: Vector3) -> Vector2i:
	if not grid.is_point_solid(cell):
		return cell
	var point := Vector2(at.x, at.z)
	var best := Vector2i(-1000, -1000)
	var distance := INF
	# Bounded endpoint projection, only during low-frequency A* queries.
	for x in range(-2, 3):
		for y in range(-2, 3):
			var candidate := cell + Vector2i(x, y)
			if grid.is_in_boundsv(candidate) and not grid.is_point_solid(candidate):
				var candidate_point := Vector2(candidate) * CELL
				var sq := point.distance_to(candidate_point) + Vector2(approach.x, approach.z).distance_to(candidate_point) * 0.6
				if sq < distance and (not endpoint_clear.is_valid() or bool(endpoint_clear.call(at, Vector3(candidate.x * CELL, at.y, candidate.y * CELL)))):
					distance = sq
					best = candidate
	return best
