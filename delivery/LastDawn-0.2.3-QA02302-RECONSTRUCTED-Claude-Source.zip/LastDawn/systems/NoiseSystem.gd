class_name NoiseSystem
extends Node
## Bounded reusable noise-event pool. No node allocation during footsteps or harvesting.
const CAPACITY := 12
var events: Array[Dictionary] = []
var cursor := 0
var serial := 0
var clock := 0.0
func _ready() -> void:
	for i in range(CAPACITY):
		events.append({"serial": 0, "at": Vector3.ZERO, "radius": 0.0, "expires": -1.0})
func _process(delta: float) -> void:
	clock += minf(delta, 0.25)
func emit_noise(at: Vector3, radius: float) -> void:
	if not at.is_finite() or not is_finite(radius) or radius <= 0 or events.is_empty():
		return
	serial += 1
	var event: Dictionary = events[cursor]
	event["serial"] = serial
	event["at"] = at
	event["radius"] = minf(radius, 40)
	event["expires"] = clock + 1.4
	cursor = (cursor + 1) % CAPACITY
func heard(listener: Vector3, after_serial: int) -> Dictionary:
	var result: Dictionary = {}
	var score := -INF
	for event in events:
		if event["serial"] <= after_serial or event["expires"] < clock:
			continue
		var distance := listener.distance_to(event["at"])
		var strength: float = event["radius"] - distance
		if strength >= 0 and strength > score:
			score = strength
			result = event
	return result

func clear() -> void:
	for event in events:
		event["expires"] = -1.0
