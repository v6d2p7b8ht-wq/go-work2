extends Node
## Render-submission timing. This cannot measure physical panel presentation or GPU-only time.
var frames := FrameTimeWindow.new()
var last_gameplay: Dictionary = {}
var report: Dictionary = {}
var previous_us: int = 0
var refresh_at_us: int = 0
var context := "gameplay"
var suspended := false
var browser_epoch := -1

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	RenderingServer.frame_post_draw.connect(_frame_drawn)
	GraphicsManager.settings_changed.connect(_settings_changed)
	get_tree().root.size_changed.connect(reset)
	_refresh()

func _settings_changed() -> void:
	last_gameplay.clear()
	reset()
	if OS.has_feature("web"):
		JavaScriptBridge.eval("if (window.LastDawnPerformance) window.LastDawnPerformance.reset('settings-change');")

func reset() -> void:
	frames.clear()
	previous_us = 0
	refresh_at_us = 0

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		suspended = true
		reset()
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN or what == NOTIFICATION_APPLICATION_RESUMED:
		suspended = false
		reset()

func _frame_drawn() -> void:
	if suspended or DisplayServer.get_name() == "headless":
		return
	var next_context := "menu" if get_tree().paused else "gameplay"
	if context != next_context:
		if context == "gameplay":
			last_gameplay = frames.snapshot()
		context = next_context
		reset()
	var now := Time.get_ticks_usec()
	if previous_us > 0:
		frames.push_ms((now - previous_us) / 1000.0)
	previous_us = now

func _process(_delta: float) -> void:
	if Time.get_ticks_usec() >= refresh_at_us:
		_refresh()
		refresh_at_us = Time.get_ticks_usec() + 500000

func _refresh() -> void:
	var browser: Dictionary = {}
	if OS.has_feature("web"):
		var raw = JavaScriptBridge.eval("window.LastDawnPerformance ? JSON.stringify(window.LastDawnPerformance.sample()) : '{}'")
		if raw is String:
			var decoded = JSON.parse_string(raw)
			if decoded is Dictionary:
				browser = decoded
		if not browser.is_empty():
			var epoch := int(browser.get("epoch", -1))
			if epoch != browser_epoch:
				browser_epoch = epoch
				last_gameplay.clear()
				reset()
			suspended = browser.get("visibility", "visible") != "visible" or not bool(browser.get("focused", true))
	var refresh_hz := -1.0
	# Godot Web screen_get_refresh_rate() returns a fallback, NOT hardware information.
	if not OS.has_feature("web") and DisplayServer.get_name() != "headless":
		var reported := DisplayServer.screen_get_refresh_rate()
		if is_finite(reported) and reported > 0:
			refresh_hz = reported
	var texture_bytes := int(Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED)) if DisplayServer.get_name() != "headless" else -1
	var draws := int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)) if DisplayServer.get_name() != "headless" else -1
	var nodes := int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
	report = {"target_fps": GraphicsManager.target_fps, "engine_max_fps": Engine.max_fps,
		"engine_actual_fps": Engine.get_frames_per_second(), "render": frames.snapshot(),
		"last_gameplay": last_gameplay.duplicate(), "context": context,
		"renderer": RenderingServer.get_current_rendering_method(), "platform": OS.get_name(),
		"display_server": DisplayServer.get_name(), "display_refresh_hz": refresh_hz,
		"physics_hz": Engine.physics_ticks_per_second, "browser": browser,
		"gpu_time_available": false, "storage_persistent": not OS.has_feature("web") or OS.is_userfs_persistent(), "scale_3d": get_viewport().scaling_3d_scale, "quality": GraphicsManager.quality, "version": ProjectSettings.get_setting("application/config/version"),
		"static_memory_bytes": int(Performance.get_monitor(Performance.MEMORY_STATIC)) if OS.is_debug_build() else -1,
		"static_memory_scope": "Godot allocator only; excludes complete browser/WASM/GPU usage",
		"texture_memory_bytes": texture_bytes if texture_bytes > 0 else -1,
		"draw_calls": draws if draws > 0 else -1,
		"object_count": int(Performance.get_monitor(Performance.OBJECT_COUNT)),
		"node_count": nodes if nodes > 0 else -1}
	if OS.has_feature("web"):
		JavaScriptBridge.eval("window.lastDawnPerformance = " + JSON.stringify(report) + ";")

func _line_stats(value: Dictionary) -> String:
	if int(value.get("samples", 0)) == 0:
		return "等待渲染采样"
	var low := "%.1f" % value["low_1_percent"] if value["ready"] else "采样中"
	return "平均 %.1f FPS · 1%% Low %s · %.2f ms\n窗口 %.1f 秒 / %d 帧间隔" % [value["average_fps"], low, value["mean_ms"], value["seconds"], value["samples"]]

func summary_text() -> String:
	var refresh := "浏览器无法可靠获取" if OS.has_feature("web") else "不可获取"
	if float(report.get("display_refresh_hz", -1)) > 0:
		refresh = "系统报告 %.1f Hz（不保证可达到）" % report["display_refresh_hz"]
	var text := "目标 %d FPS · 引擎上限 %d · 引擎实测 %d FPS\n%s\n%s / %s · 屏幕刷新率：%s" % [GraphicsManager.target_fps, Engine.max_fps,
		Engine.get_frames_per_second(), _line_stats(frames.snapshot()), OS.get_name(), RenderingServer.get_current_rendering_method(), refresh]
	text += "\n当前采样：菜单（游戏逻辑已暂停）" if context == "menu" else "\n当前采样：游戏中"
	if not last_gameplay.is_empty() and context == "menu":
		text += "\n上次游戏窗口：" + _line_stats(last_gameplay)
	if OS.has_feature("web"):
		var browser: Dictionary = report.get("browser", {})
		var raf: Dictionary = browser.get("raf", {})
		text += "\n浏览器 rAF：" + _line_stats(raf)
		text += "\n运行方式：%s · 页面：%s" % [browser.get("mode", "未知"), browser.get("visibility", "未知")]
		text += "\nWeb VSync / 刷新调度由浏览器控制。rAF 不是屏幕 Hz。"
	var memory_bytes := int(report.get("static_memory_bytes", -1))
	text += "\n引擎分配器内存：%s（非总内存）" % ("%.1f MiB" % (memory_bytes / 1048576.0) if memory_bytes > 0 else "当前导出不可获取")
	text += "\n绘制调用 %s · 节点 %s" % [str(report.get("draw_calls", -1)) if int(report.get("draw_calls", -1)) >= 0 else "不可获取", str(report.get("node_count", -1)) if int(report.get("node_count", -1)) > 0 else "不可获取"]
	return text
