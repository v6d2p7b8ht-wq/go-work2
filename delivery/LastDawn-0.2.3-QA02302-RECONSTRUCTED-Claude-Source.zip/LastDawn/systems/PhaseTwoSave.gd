class_name PhaseTwoSave
extends RefCounted
## Schema 3 is complete. Defaults belong only to explicit schema 1/2 migration.
static func number(value: Variant, low: float, high: float, whole: bool = false) -> bool:
	if not (value is int or value is float) or not is_finite(float(value)): return false
	return float(value)>=low and float(value)<=high and (not whole or float(value)==int(value))

static func fields(value: Variant, required: Array, exact: bool = false) -> bool:
	return value is Dictionary and value.has_all(required) and (not exact or value.size()==required.size())

static func position(value: Variant) -> bool:
	return value is Array and value.size()==3 and number(value[0],-98,98) and number(value[1],-5,90) and number(value[2],-98,98)

static func validate(value: Variant) -> bool:
	if not fields(value,["content_revision","buildings","trader","environment","family"],true): return false
	if not number(value["content_revision"],1,1,true): return false
	return buildings(value["buildings"]) and trader(value["trader"]) and environment(value["environment"]) and family(value["family"])

static func buildings(value: Variant) -> bool:
	if not fields(value,["records","next_id"],true) or not value["records"] is Array or value["records"].size()>BuildingSystem.LIMIT: return false
	if not number(value["next_id"],1,1000000,true): return false
	var seen := {}
	for record in value["records"]:
		if not fields(record,["id","type","position","yaw","lit"],true) or not record["id"] is String: return false
		var id: String = record["id"]
		if not id.begins_with("s01_build_") or seen.has(id) or not id.trim_prefix("s01_build_").is_valid_int(): return false
		var serial := int(id.trim_prefix("s01_build_"))
		if serial<1 or serial>=int(value["next_id"]): return false
		seen[id] = true
		if not record["type"] is String or not BuildingSystem.TYPES.has(record["type"]) or not position(record["position"]) or not number(record["yaw"],-TAU,TAU) or not record["lit"] is bool: return false
	return true

static func trader(value: Variant) -> bool:
	if not fields(value,["stock","restock_left","trades"],true) or not fields(value["stock"],TradingSystem.INITIAL.keys(),true): return false
	if not number(value["restock_left"],0.000001,300) or not number(value["trades"],0,1000000,true): return false
	for id in value["stock"]:
		if not number(value["stock"][id],0,9999,true): return false
	return true

static func environment(value: Variant) -> bool:
	if not fields(value,["hour","day","day_seconds","weather_index","weather_left"],true): return false
	return number(value["hour"],0,24) and float(value["hour"])<24 and number(value["day"],1,1000000,true) and number(value["day_seconds"],600,3600) and number(value["weather_index"],0,3,true) and number(value["weather_left"],0.000001,240)

static func family(value: Variant) -> bool:
	if not fields(value,["id","stage","position","reward_claimed","arrival_time"],true): return false
	var stage = value["stage"]
	var claimed = value["reward_claimed"]
	if not value["id"] is String or value["id"]!="family_xiaoyu" or not stage is String or stage not in FamilyQuest.STAGES or not claimed is bool: return false
	if claimed and stage!="evacuated": return false
	return position(value["position"]) and number(value["arrival_time"],0,2)

static func legacy_defaults() -> Dictionary:
	# Called only after a schema 1/2 file passes its own validation. Never repair schema 3.
	var home := FamilyCompanion.HOME
	return {"content_revision":1,"buildings":{"next_id":1,"records":[]},
		"trader":{"stock":TradingSystem.INITIAL.duplicate(),"restock_left":TradingSystem.RESTOCK_SECONDS,"trades":0},
		"environment":{"hour":16.5,"day":1,"day_seconds":1200.0,"weather_index":0,"weather_left":WorldClock.WEATHER_INTERVAL},
		"family":{"id":"family_xiaoyu","stage":"not_started","position":[home.x,home.y,home.z],"reward_claimed":false,"arrival_time":0.0}}
