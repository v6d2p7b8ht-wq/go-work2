class_name ResourceSystem
extends Node
## Stable IDs, small spatial buckets, fixed resource nodes and reused MultiMesh trees.
signal harvested(kind: String, at: Vector3, rewards: Dictionary)
const REACH := 3.3
const CELL_SIZE := 8.0
const HARVEST_INTERVAL := 0.8
var vegetation: VegetationSystem
var world: Node3D
var records: Dictionary = {}
var cells: Dictionary = {}
var cooldown := 0.0
var last_message := ""
var queries := 0
var candidates_checked := 0
var last_harvest := ""
var landmarks: Array[String] = []

func build(owner_world: Node3D, trees: VegetationSystem) -> void:
	world = owner_world
	vegetation = trees
	for tree in vegetation.harvest_entries:
		_register({"id": tree["id"], "kind": "tree", "at": tree["at"], "remaining": 4, "maximum": 4, "tree": tree, "body": tree["body"]})
	var ore_positions := [Vector2(12, 18), Vector2(41, 22), Vector2(52, 12), Vector2(65, 42), Vector2(-43, 20), Vector2(-48, -8)]
	var rock := GeometryFactory.material("harvest_rock", Color("767b73"), "rock")
	var ore := GeometryFactory.material("harvest_ore", Color("ba8d5d"), "rust", 0.15)
	for i in range(ore_positions.size()):
		var point: Vector2 = ore_positions[i]
		var at := Vector3(point.x, TerrainBuilder.height_at(point.x, point.y), point.y)
		var node := Node3D.new()
		node.position = at
		world.add_child(node)
		GeometryFactory.mesh_node(node, GeometryFactory.sphere_mesh(), rock, Vector3(0, 0.65, 0), Vector3(1.6, 1.3, 1.4))
		for offset in [Vector3(-0.45, 1.0, -0.28), Vector3(0.35, 1.1, 0.12), Vector3(0.57, 0.6, 0.3)]:
			GeometryFactory.mesh_node(node, GeometryFactory.box_mesh(), ore, offset, Vector3(0.25, 0.15, 0.35)).rotation.z = 0.35
		var body := GeometryFactory.box_collider(node, Vector3(0, 0.5, 0), Vector3(1.0, 1.0, 0.9))
		var label := GeometryFactory.label(node, "矿石 / ORE", Vector3(0, 1.6, 0), 24, Color("d7ba85"))
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.visibility_range_end = 16
		_register({"id": "s01_ore_%02d" % i, "kind": "ore", "at": at, "remaining": 5, "maximum": 5, "node": node, "body": body})
	GraphicsManager.settings_changed.connect(_apply_quality)
	_apply_quality()

func _register(record: Dictionary) -> void:
	records[record["id"]] = record
	var key := _cell(record["at"])
	if not cells.has(key):
		cells[key] = []
	cells[key].append(record["id"])

func _cell(at: Vector3) -> Vector2i:
	return Vector2i(floori(at.x / CELL_SIZE), floori(at.z / CELL_SIZE))

func _process(delta: float) -> void:
	cooldown = maxf(0, cooldown - minf(delta, 0.25))

func available(record: Dictionary) -> bool:
	if record["remaining"] <= 0:
		return false
	if record["kind"] == "tree":
		var tree: Dictionary = record["tree"]
		return tree["index"] < tree["trunks"].multimesh.visible_instance_count
	return true

func can_reach(record: Dictionary, player: PlayerController) -> bool:
	if player.position.distance_squared_to(record["at"]) > REACH * REACH:
		return false
	var ray := PhysicsRayQueryParameters3D.create(player.global_position + Vector3.UP, Vector3(record["at"]) + Vector3.UP, 1)
	var hit := world.get_world_3d().direct_space_state.intersect_ray(ray)
	return hit.is_empty() or hit["collider"] == record["body"]

func nearest(player: PlayerController) -> Dictionary:
	queries += 1
	var center := _cell(player.position)
	var best: Dictionary = {}
	var best_distance := REACH * REACH
	for x in range(-1, 2):
		for y in range(-1, 2):
			for id in cells.get(center + Vector2i(x, y), []):
				candidates_checked += 1
				var record: Dictionary = records[id]
				var distance := player.position.distance_squared_to(record["at"])
				if distance < best_distance and available(record) and can_reach(record, player):
					best = record
					best_distance = distance
	return best

func harvest(id: String, player: PlayerController) -> bool:
	if not records.has(id) or not available(records[id]) or not can_reach(records[id], player):
		last_message = "靠近可采集的树木或矿石"
		return false
	if cooldown > 0:
		last_message = "采集中，请稍候"
		return false
	var record: Dictionary = records[id]
	var rewards := {"wood": 1} if record["kind"] == "tree" else {"stone": 1, "ore": 1}
	if not InventorySystem.can_add_items(rewards):
		last_message = "物品数量已达上限，未消耗资源"
		return false
	var cost: float = player.survival.settings["gather_cost"]
	if not player.survival.spend_stamina(cost):
		last_message = "体力不足，请休息后采集"
		return false
	InventorySystem.add_items(rewards)
	record["remaining"] -= 1
	last_harvest = id
	cooldown = HARVEST_INTERVAL
	if record["kind"] == "tree":
		last_message = "采集 木材 × 1"
	else:
		last_message = "采集 石头 × 1 / 矿物 × 1"
	world._player_noise(record["at"], 24.0)
	if record["remaining"] == 0:
		_set_depleted(record, true)
		_apply_quality() # Refresh the small diagnostic landmark cache only on depletion.
	harvested.emit(record["kind"],record["at"],rewards)
	return true

func _set_depleted(record: Dictionary, value: bool) -> void:
	if record["kind"] == "tree":
		vegetation.set_tree_depleted(record["id"], value)
	else:
		record["node"].visible = not value
		for shape in record["body"].get_children():
			if shape is CollisionShape3D:
				shape.set_deferred("disabled", value)

func snapshot() -> Dictionary:
	var remaining := {}
	for id in records:
		if records[id]["remaining"] != records[id]["maximum"]:
			remaining[id] = records[id]["remaining"]
	return {"remaining": remaining, "cooldown": cooldown}

func restore(data: Dictionary) -> void:
	var saved: Dictionary = data.get("remaining", {})
	for id in records:
		var record: Dictionary = records[id]
		record["remaining"] = clampi(int(saved.get(id, record["maximum"])), 0, record["maximum"])
		_set_depleted(record, record["remaining"] == 0)
	cooldown = clampf(float(data.get("cooldown", 0)), 0, HARVEST_INTERVAL)

func _apply_quality() -> void:
	landmarks.clear()
	landmarks.append("s01_ore_00")
	var tree_id := ""
	var best := INF
	for record in records.values():
		if record["kind"] == "ore":
			for mesh in record["node"].find_children("*", "GeometryInstance3D", true, false):
				mesh.visibility_range_end = float(GraphicsManager.preset()["distance"])
		elif available(record):
			var sq: float = Vector3(record["at"]).distance_squared_to(Vector3(42, 0, 30))
			if sq < best:
				best = sq
				tree_id = record["id"]
	if not tree_id.is_empty():
		landmarks.append(tree_id)

func debug_snapshot() -> Dictionary:
	var markers := []
	for id in landmarks:
		var record: Dictionary = records[id]
		var at: Vector3 = record["at"]
		markers.append({"id": id, "kind": record["kind"], "at": [at.x, at.y, at.z], "remaining": record["remaining"]})
	var geometry := {}
	if records.has(last_harvest):
		var record: Dictionary = records[last_harvest]
		geometry = {"id": last_harvest, "remaining": record["remaining"]}
		if record["kind"] == "tree":
			var tree: Dictionary = record["tree"]
			geometry["scale_length"] = tree["trunks"].multimesh.get_instance_transform(tree["index"]).basis.get_scale().length()
			geometry["collider_disabled"] = tree["shape"].disabled
		else:
			geometry["visible"] = record["node"].visible
	return {"landmarks": markers, "last_harvest": geometry}
