extends Node
## Atomic replacement, one backup and explicit validation. Never uses object deserialization.
signal completed(success: bool, message: String)
const SAVE_PATH := "user://survivor_v1.json"
const VERSION := 3
const MAX_BYTES := 1024 * 1024
var last_error := ""

func exists() -> bool:
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(SAVE_PATH + ".bak")

func save_world(world: Node) -> bool:
	# Manual and automatic saves alike: the title's fresh world never replaces real progress.
	var waiting = world.get("awaiting_session_choice")
	if waiting is bool and waiting:
		last_error = "请先继续本机存档或确认开始新游戏，未写入"
		completed.emit(false, last_error)
		return false
	var data: Dictionary = world.create_snapshot()
	data["version"] = VERSION
	data["saved_at_utc"] = Time.get_datetime_string_from_system(true)
	var ok := write_snapshot(data)
	var message := ("存档已写入，请稍候再退出网页" if OS.has_feature("web") else "存档已写入本机") if ok else last_error
	completed.emit(ok, message)
	return ok

func persistence_available() -> bool:
	return not OS.has_feature("web") or OS.is_userfs_persistent()

func write_snapshot(data: Dictionary) -> bool:
	if not persistence_available():
		last_error = "浏览器存储不可用，进度无法持久保存，请保留页面并检查存储权限"
		return false
	if not valid_snapshot(data):
		last_error = "存档内容无效，未写入"
		return false
	if _has_protected_save():
		last_error = "存档版本较新或文件无法安全读取，已保护原文件"
		return false
	var payload := JSON.stringify(data)
	if payload.to_utf8_buffer().size() > MAX_BYTES:
		last_error = "存档过大，未写入，已保留旧存档"
		return false
	var temporary := SAVE_PATH + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		last_error = "无法写入存档：%s" % error_string(FileAccess.get_open_error())
		return false
	file.store_string(payload)
	file.flush()
	var result := file.get_error()
	file.close()
	if result != OK:
		last_error = "存储空间不足或写入失败"
		return false
	var absolute := ProjectSettings.globalize_path(SAVE_PATH)
	var backup := absolute + ".bak"
	var rotated := false
	# Never replace a good backup with a corrupt primary recovered from that backup.
	if FileAccess.file_exists(SAVE_PATH) and valid_snapshot(_read_candidate(SAVE_PATH)):
		if FileAccess.file_exists(SAVE_PATH + ".bak"):
			if DirAccess.remove_absolute(backup) != OK:
				last_error = "无法轮换备份，已保留原存档"
				return false
		var old := DirAccess.rename_absolute(absolute, backup)
		if old != OK:
			last_error = "无法保留旧存档，已取消保存"
			return false
		rotated = true
	result = DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), absolute)
	if result != OK:
		if rotated and FileAccess.file_exists(SAVE_PATH + ".bak"):
			DirAccess.rename_absolute(backup, absolute)
		last_error = "存档替换失败，已保留旧文件"
		return false
	last_error = ""
	return true

func _read_candidate(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_BYTES:
		return {}
	var text := file.get_as_text()
	file.close()
	var parser := JSON.new()
	if parser.parse(text) != OK or not parser.data is Dictionary:
		return {}
	return parser.data

func _has_protected_save() -> bool:
	for path in [SAVE_PATH, SAVE_PATH + ".bak"]:
		if FileAccess.file_exists(path):
			var file := FileAccess.open(path, FileAccess.READ)
			if file == null:
				return true
			var oversized := file.get_length() > MAX_BYTES
			file.close()
			if oversized:
				return true
		var version = _read_candidate(path).get("version", 0)
		if (version is int or version is float) and is_finite(float(version)) and version > VERSION:
			return true
	return false

func read_snapshot() -> Dictionary:
	if _has_protected_save():
		last_error = "存档版本较新或文件无法安全读取，已保护原文件"
		return {}
	for path in [SAVE_PATH, SAVE_PATH + ".bak"]:
		var data := _read_candidate(path)
		if not data.is_empty() and valid_snapshot(data):
			last_error = "已从备份恢复" if path.ends_with(".bak") else ""
			return data
	last_error = "没有可读取的存档，或存档已损坏"
	return {}

func load_world(world: Node) -> bool:
	var data := read_snapshot()
	if data.is_empty():
		completed.emit(false, last_error)
		return false
	world.restore_snapshot(data)
	completed.emit(true, "已读取本机存档" if last_error.is_empty() else last_error)
	return true

func prepare_snapshot(data: Dictionary) -> Dictionary:
	if not valid_snapshot(data):
		return {}
	var prepared := data.duplicate(true)
	# Legacy files retain their version until the next real schema 3 world save.
	# Their validated original fields keep the existing legacy restore defaults.
	if data["version"] != VERSION and not data.has("phase2"):
		prepared["phase2"] = PhaseTwoSave.legacy_defaults()
	return prepared

func valid_snapshot(data: Dictionary) -> bool:
	# JSON numbers decode as floats; Array membership uses stricter Variant types.
	if not PhaseTwoSave.number(data.get("version"), 1, VERSION, true):
		return false
	if data.get("version", 0) != 1 and data.get("version", 0) != 2 and data.get("version", 0) != VERSION:
		return false
	if data["version"] == VERSION and not _complete_current(data):
		return false
	if (data.get("version") == VERSION or data.has("phase2")) and not PhaseTwoSave.validate(data.get("phase2")):
		return false
	var pos = data.get("position")
	if not pos is Array or pos.size() != 3:
		return false
	for component in pos:
		if not (component is int or component is float) or not is_finite(float(component)):
			return false
	if absf(float(pos[0])) > 99.0 or absf(float(pos[2])) > 99.0 or float(pos[1]) < -5.0 or float(pos[1]) > 90.0:
		return false
	if not data.get("inventory") is Dictionary or not data.get("settings") is Dictionary:
		return false
	for id in data["inventory"]:
		var count = data["inventory"][id]
		if not InventorySystem.ITEMS.has(id) or not _finite_number(count, 0, InventorySystem.MAX_PER_ITEM) or float(count) != int(count):
			return false
	var graphics: Dictionary = data["settings"]
	if graphics.has("quality") and (not _finite_number(graphics["quality"], 0, 4) or float(graphics["quality"]) != int(graphics["quality"])):
		return false
	if graphics.has("target_fps") and (not _finite_number(graphics["target_fps"], 30, 120) or int(graphics["target_fps"]) not in GraphicsManager.FRAME_RATES or float(graphics["target_fps"]) != int(graphics["target_fps"])):
		return false
	if graphics.has("sensitivity") and not _finite_number(graphics["sensitivity"], 0.001, 0.009):
		return false
	var picked = data.get("picked", [])
	if not picked is Array or picked.size() > 512:
		return false
	for id in picked:
		if not id is String or id.length() > 64:
			return false
	for stat in ["stamina", "camera_yaw", "camera_pitch", "camera_distance"]:
		var value = data.get(stat, 0.0)
		if not (value is int or value is float) or not is_finite(float(value)):
			return false
	# Legacy files have no new fields; defaults pass. If extra fields exist, validate them too.
	var state_id = data.get("state_id", "state_01")
	return state_id is String and state_id == "state_01" and _valid_batch_one(data)

func _complete_current(data: Dictionary) -> bool:
	# Presence is distinct from validity. A default value must not hide a truncated file.
	if not data.has_all(["version", "state_id", "position", "inventory", "settings", "picked", "stamina", "camera_yaw", "camera_pitch", "camera_distance", "talked_to_npc", "phase2", "survival", "resources", "infected"]):
		return false
	if not data["state_id"] is String or not data["talked_to_npc"] is bool:
		return false
	if not PhaseTwoSave.fields(data["inventory"], InventorySystem.ITEMS.keys()):
		return false
	if not PhaseTwoSave.fields(data["settings"], ["quality", "target_fps", "sensitivity"]):
		return false
	if not PhaseTwoSave.fields(data["survival"], ["health", "hunger", "thirst", "stamina", "settings"]):
		return false
	if not PhaseTwoSave.fields(data["survival"]["settings"], SurvivalSystem.DEFAULTS.keys()):
		return false
	if not PhaseTwoSave.fields(data["resources"], ["remaining", "cooldown"]):
		return false
	if not data["infected"] is Array or data["infected"].size() != 3:
		return false
	for entry in data["infected"]:
		if not PhaseTwoSave.fields(entry, ["id", "position", "last_seen", "state", "patrol_index", "investigate_time", "attack_cooldown"]):
			return false
	return true

func _finite_number(value: Variant, minimum: float, maximum: float) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum and float(value) <= maximum

func _valid_position(value: Variant) -> bool:
	return value is Array and value.size() == 3 and _finite_number(value[0], -99, 99) and _finite_number(value[1], -5, 90) and _finite_number(value[2], -99, 99)

func _valid_batch_one(data: Dictionary) -> bool:
	var survival = data.get("survival", {})
	if not survival is Dictionary or not survival.get("settings", {}) is Dictionary:
		return false
	for key in ["health", "hunger", "thirst", "stamina"]:
		if not _finite_number(survival.get(key, 100), 0, 100):
			return false
	for key in survival.get("settings", {}):
		if not SurvivalSystem.DEFAULTS.has(key):
			return false
		var limits: Vector2 = SurvivalSystem.LIMITS[key]
		if not _finite_number(survival["settings"][key], limits.x, limits.y):
			return false
	var resources = data.get("resources", {})
	if not resources is Dictionary or not resources.get("remaining", {}) is Dictionary or resources.get("remaining", {}).size() > 350:
		return false
	if not _finite_number(resources.get("cooldown", 0), 0, 0.8):
		return false
	for id in resources.get("remaining", {}):
		if not id is String or not (id.begins_with("s01_tree_") or id.begins_with("s01_ore_")):
			return false
		var maximum := 4 if id.begins_with("s01_tree_") else 5
		var suffix: String = id.trim_prefix("s01_tree_" if maximum == 4 else "s01_ore_")
		if not suffix.is_valid_int() or int(suffix) < 0 or int(suffix) >= (340 if maximum == 4 else 6):
			return false
		var remaining = resources["remaining"][id]
		if not _finite_number(remaining, 0, maximum) or float(remaining) != int(remaining):
			return false
	var infected = data.get("infected", [])
	if not infected is Array or infected.size() > 3:
		return false
	var seen := {}
	for entry in infected:
		if not entry is Dictionary or entry.get("id", "") not in ["s01_infected_00", "s01_infected_01", "s01_infected_02"] or seen.has(entry.get("id", "")):
			return false
		seen[entry["id"]] = true
		if not _valid_position(entry.get("position")) or not _valid_position(entry.get("last_seen")):
			return false
		for key in ["state", "patrol_index"]:
			var maximum := 5 if key == "state" else 3
			if not _finite_number(entry.get(key, 0), 0, maximum) or float(entry.get(key, 0)) != int(entry.get(key, 0)):
				return false
		if not _finite_number(entry.get("investigate_time", 0), 0, 7) or not _finite_number(entry.get("attack_cooldown", 0), 0, 4):
			return false
	return true
