class_name StaticBatcher
extends Node3D
## Chunk-local MultiMeshes preserve frustum/distance culling. Ordinary props share unit meshes.
const CHUNK := 24.0
var buckets: Dictionary = {}
var instances: Array[MultiMeshInstance3D] = []

func add_prop(mesh: Mesh, mat: Material, at: Vector3, size: Vector3, yaw: float = 0.0) -> void:
	var chunk := Vector2i(floori(at.x / CHUNK), floori(at.z / CHUNK))
	var key := "%s:%s:%s" % [chunk, mesh.get_instance_id(), mat.get_instance_id()]
	if not buckets.has(key):
		buckets[key] = {"mesh": mesh, "mat": mat, "origin": Vector3(chunk.x * CHUNK, 0, chunk.y * CHUNK), "transforms": []}
	var bucket: Dictionary = buckets[key]
	var instance_basis := Basis(Vector3.UP, yaw).scaled(size)
	bucket["transforms"].append(Transform3D(instance_basis, at - bucket["origin"]))

func box(mat: Material, at: Vector3, size: Vector3, yaw: float = 0.0) -> void:
	add_prop(GeometryFactory.box_mesh(), mat, at, size, yaw)

func build() -> void:
	for bucket in buckets.values():
		var multi := MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_3D
		multi.mesh = bucket["mesh"]
		multi.instance_count = bucket["transforms"].size()
		for i in range(multi.instance_count):
			multi.set_instance_transform(i, bucket["transforms"][i])
		var node := MultiMeshInstance3D.new()
		node.multimesh = multi
		node.material_override = bucket["mat"]
		node.position = bucket["origin"]
		node.visibility_range_end = 120.0
		add_child(node)
		instances.append(node)
	buckets.clear()

func apply_distance(distance: float) -> void:
	for node in instances:
		node.visibility_range_end = distance
