class_name SurvivalSystem
extends Node
## Per-player physiology. Rates use real play time; paused/background time is never replayed.
signal damaged(amount: float)
signal incapacitated
const CONFIG_PATH := "user://survival_settings.cfg"
const DEFAULTS := {
	"hunger_per_minute": 1.5, "thirst_per_minute": 2.7,
	"sprint_drain": 19.0, "stamina_regen": 13.0,
	"starvation_damage": 0.25, "dehydration_damage": 0.5,
	"safe_heal": 0.8, "zombie_damage": 8.0,
	"attack_interval": 1.6, "gather_cost": 7.0
}
const LIMITS := {
	"hunger_per_minute": Vector2(0, 12), "thirst_per_minute": Vector2(0, 18),
	"sprint_drain": Vector2(5, 35), "stamina_regen": Vector2(1, 30),
	"starvation_damage": Vector2(0, 2), "dehydration_damage": Vector2(0, 3),
	"safe_heal": Vector2(0, 3), "zombie_damage": Vector2(1, 25),
	"attack_interval": Vector2(1, 4), "gather_cost": Vector2(0, 20)
}
var health := 100.0
var hunger := 100.0 # Fullness: higher is better.
var thirst := 100.0 # Hydration: higher is better.
var stamina := 100.0
var settings: Dictionary = DEFAULTS.duplicate()

func _ready() -> void:
	var config := ConfigFile.new()
	if config.load(CONFIG_PATH) == OK:
		var saved := {}
		for key in DEFAULTS:
			saved[key] = config.get_value("survival", key, DEFAULTS[key])
		apply_settings(saved, false)

func alive() -> bool:
	return health > 0.0

func step(delta: float, running: bool, safe_zone: bool) -> void:
	if not alive() or not is_finite(delta) or delta <= 0:
		return
	var elapsed := minf(delta, 0.25)
	var exertion := 1.5 if running else 1.0
	hunger = maxf(0.0, hunger - float(settings["hunger_per_minute"]) / 60.0 * elapsed * exertion)
	thirst = maxf(0.0, thirst - float(settings["thirst_per_minute"]) / 60.0 * elapsed * exertion)
	var recovery := float(settings["stamina_regen"]) * (0.35 if hunger < 20 or thirst < 20 else 1.0)
	stamina = clampf(stamina + (-float(settings["sprint_drain"]) if running else recovery) * elapsed, 0, 100)
	var deprivation := (float(settings["starvation_damage"]) if hunger <= 0 else 0.0) + (float(settings["dehydration_damage"]) if thirst <= 0 else 0.0)
	if deprivation > 0:
		take_damage(deprivation * elapsed)
	elif safe_zone and hunger >= 35 and thirst >= 35:
		health = minf(100.0, health + float(settings["safe_heal"]) * elapsed)

func take_damage(amount: float) -> bool:
	if not alive() or not is_finite(amount) or amount <= 0:
		return false
	var applied := minf(amount, health)
	health -= applied
	damaged.emit(applied)
	if not alive():
		incapacitated.emit()
	return true

func spend_stamina(amount: float) -> bool:
	if not alive() or not is_finite(amount) or amount < 0 or stamina < amount:
		return false
	stamina -= amount
	return true

func can_consume(id: String) -> bool:
	return alive() and ((id == "food" and (hunger < 100 or stamina < 100)) or (id == "water" and (thirst < 100 or stamina < 100)))

func consume(id: String) -> bool:
	if not can_consume(id):
		return false
	if id == "food":
		hunger = minf(100, hunger + 32)
		stamina = minf(100, stamina + 8)
	else:
		thirst = minf(100, thirst + 45)
		stamina = minf(100, stamina + 5)
	return true

func recover() -> void:
	health = 65
	hunger = maxf(35, hunger)
	thirst = maxf(35, thirst)
	stamina = 65

func snapshot() -> Dictionary:
	return {"health": health, "hunger": hunger, "thirst": thirst, "stamina": stamina, "settings": settings.duplicate()}

func restore(data: Dictionary) -> void:
	for key in ["health", "hunger", "thirst", "stamina"]:
		var value = data.get(key, 100.0)
		set(key, clampf(float(value), 0, 100) if (value is float or value is int) and is_finite(float(value)) else 100.0)
	apply_settings(data.get("settings", {}), true)

func apply_settings(data: Dictionary, persist: bool = true) -> void:
	for key in DEFAULTS:
		var value = data.get(key, DEFAULTS[key])
		var bounds: Vector2 = LIMITS[key]
		settings[key] = clampf(float(value), bounds.x, bounds.y) if (value is float or value is int) and is_finite(float(value)) else DEFAULTS[key]
	if persist:
		var config := ConfigFile.new()
		for key in settings:
			config.set_value("survival", key, settings[key])
		config.save(CONFIG_PATH)
