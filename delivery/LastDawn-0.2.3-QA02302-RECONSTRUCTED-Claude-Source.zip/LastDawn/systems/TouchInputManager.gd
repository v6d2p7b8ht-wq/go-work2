class_name TouchInputManager
extends Node
## The only owner of ScreenTouch/ScreenDrag. All positions/deltas are Godot viewport units.
signal look_delta(relative: Vector2)
signal action_pressed(action: String)
signal reset_occurred(reason: String)
var controls: Control
var contacts: Dictionary = {}
var joystick_touch := -1
var look_touch := -1
var stick := Vector2.ZERO
var generation := 0
var last_relative := Vector2.ZERO
var last_accepted_relative := Vector2.ZERO
var last_source := "none"
var last_reset := "startup"
var accepted_drags := 0
var rejected_drags := 0
var ignored_mouse_events := 0
var last_touch_ms := -10000
var web_callback: JavaScriptObject
var web_window: JavaScriptObject

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.has_feature("web"):
		web_window = JavaScriptBridge.get_interface("window")
		web_callback = JavaScriptBridge.create_callback(_web_reset)
		web_window.addEventListener("lastdawn-input-reset", web_callback)

func _exit_tree() -> void:
	if OS.has_feature("web") and web_window != null and web_callback != null:
		web_window.removeEventListener("lastdawn-input-reset", web_callback)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		reset("engine-focus-loss")

func _web_reset(_args: Array) -> void:
	reset("web:" + String(web_window.lastDawnInputResetReason))

func reset(reason: String = "requested") -> void:
	generation += 1
	contacts.clear()
	joystick_touch = -1
	look_touch = -1
	stick = Vector2.ZERO
	last_relative = Vector2.ZERO
	last_accepted_relative = Vector2.ZERO
	last_reset = reason
	last_source = "reset:" + reason
	# Mouse compatibility events can arrive after touchcancel / focus loss.
	last_touch_ms = Time.get_ticks_msec()
	reset_occurred.emit(reason)
	if is_instance_valid(controls):
		controls.queue_redraw()

func permits_mouse_look(event: InputEventMouseMotion) -> bool:
	if event.device == InputEvent.DEVICE_ID_EMULATION or not contacts.is_empty() or Time.get_ticks_msec() - last_touch_ms < 650:
		ignored_mouse_events += 1
		return false
	return true

func _input(event: InputEvent) -> void:
	if not is_instance_valid(controls):
		return
	if event is InputEventScreenTouch:
		_handle_touch(event)
	elif event is InputEventScreenDrag:
		_handle_drag(event)

func _handle_touch(event: InputEventScreenTouch) -> void:
	last_touch_ms = Time.get_ticks_msec()
	last_source = "ScreenTouch"
	if event.canceled:
		reset("ScreenTouch.canceled")
		return
	if not event.pressed:
		_release(event.index)
		return
	# An index is allocated only on a new press. Drags never acquire ownership.
	_release(event.index)
	var at := event.position
	if not at.is_finite() or not controls.get_global_rect().has_point(at):
		return
	var role: String = controls.touch_role_at(at)
	if role == "joystick" and joystick_touch != -1:
		role = "ignored"
	elif role == "look" and look_touch != -1:
		role = "ignored"
	contacts[event.index] = {"role": role, "position": at, "relative": Vector2.ZERO, "generation": generation}
	if role == "joystick":
		joystick_touch = event.index
		_update_stick(at)
	elif role == "look":
		look_touch = event.index
	if role == "joystick" or role == "look" or role.begins_with("action:"):
		get_viewport().set_input_as_handled()
	if role.begins_with("action:"):
		# Store ownership before emitting: an interaction may open a modal and reset it.
		action_pressed.emit(role.trim_prefix("action:"))
	controls.queue_redraw()

func _release(index: int) -> void:
	if index == joystick_touch:
		joystick_touch = -1
		stick = Vector2.ZERO
	if index == look_touch:
		look_touch = -1
	contacts.erase(index)
	controls.queue_redraw()

func _handle_drag(event: InputEventScreenDrag) -> void:
	last_touch_ms = Time.get_ticks_msec()
	if not contacts.has(event.index):
		rejected_drags += 1
		last_source = "ScreenDrag:orphan-ignored"
		return
	var contact: Dictionary = contacts[event.index]
	var role: String = contact["role"]
	if role == "ui" or role == "edge" or role == "ignored":
		return
	get_viewport().set_input_as_handled()
	var previous: Vector2 = contact["position"]
	contact["position"] = event.position
	contact["relative"] = event.relative
	if not controls.enabled or int(contact["generation"]) != generation:
		_release(event.index)
		return
	if not event.position.is_finite() or not controls.get_global_rect().has_point(event.position):
		_release(event.index)
		rejected_drags += 1
		last_source = "ScreenDrag:outside-canvas"
		return
	if role == "joystick":
		_update_stick(event.position)
		return
	if role != "look":
		return # An action/UI finger never becomes a camera finger after moving.
	last_source = "ScreenDrag.relative"
	last_relative = event.relative
	var displacement := event.position - previous
	var tolerance := maxf(3.0, displacement.length() * 0.25)
	var max_step := minf(controls.size.x, controls.size.y) * 0.65
	if not event.relative.is_finite() or event.relative.length() > max_step or displacement.distance_to(event.relative) > tolerance:
		# Rebase only the continuity check. Do NOT integrate an absolute position as rotation.
		rejected_drags += 1
		last_source = "ScreenDrag:discontinuous-ignored"
		return
	last_accepted_relative = event.relative
	accepted_drags += 1
	look_delta.emit(event.relative) # No delta time, CSS scale, DPR or internal render scale.

func _update_stick(at: Vector2) -> void:
	stick = ((at - controls.joystick_center) / controls.radius).limit_length(1.0)
	if stick.length() < 0.12:
		stick = Vector2.ZERO
	controls.queue_redraw()

func debug_snapshot() -> Dictionary:
	var pointers: Array[Dictionary] = []
	for index in contacts:
		var contact: Dictionary = contacts[index]
		var relative: Vector2 = contact["relative"]
		pointers.append({"index": index, "purpose": contact["role"], "relative": [relative.x, relative.y]})
	return {"count": contacts.size(), "pointers": pointers, "relative": [last_relative.x, last_relative.y], "accepted_relative": [last_accepted_relative.x, last_accepted_relative.y], "source": last_source, "last_reset": last_reset, "generation": generation, "accepted_drags": accepted_drags, "rejected_drags": rejected_drags, "ignored_mouse": ignored_mouse_events, "viewport": [controls.size.x, controls.size.y]}
