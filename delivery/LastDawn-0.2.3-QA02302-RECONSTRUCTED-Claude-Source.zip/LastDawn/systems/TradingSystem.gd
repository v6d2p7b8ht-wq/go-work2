class_name TradingSystem
extends Node3D
signal changed
const RESTOCK_SECONDS := 300.0
const INITIAL := {"food":8,"water":8,"wood":24,"stone":24,"ore":12,"electronics":3,"blueprint":1}
const OFFERS := {
	"food": {"name":"换取食品","cost":{"wood":3},"reward":{"food":1}},
	"water": {"name":"换取饮水","cost":{"stone":3},"reward":{"water":1}},
	"wood": {"name":"换取木材","cost":{"food":1},"reward":{"wood":2}},
	"ore": {"name":"换取矿物","cost":{"food":2},"reward":{"ore":1}},
	"electronics": {"name":"换取电子元件","cost":{"ore":2},"reward":{"electronics":1}},
	"blueprint": {"name":"换取虚构装备蓝图","cost":{"electronics":2,"ore":2},"reward":{"blueprint":1}}
}
var world: Node3D
var at := Vector3(20,0,23)
var stock: Dictionary = INITIAL.duplicate()
var restock_left := RESTOCK_SECONDS
var trades := 0
var last_message := ""
var visual: CharacterVisual
var range_clock := 0.0

func _ready() -> void:
	at.y = TerrainBuilder.height_at(at.x,at.z)
	position = at
	visual = CharacterVisual.new()
	add_child(visual)
	visual.build(false,true)
	visual.rotation.y = PI/2
	var label := GeometryFactory.label(self,"周 · 流浪商人",Vector3(0,2.4,0),27,Color("b7cca2"))
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.visibility_range_end = 30
	GeometryFactory.box_collider(self,Vector3(0,0.9,0),Vector3(0.65,1.8,0.65))

func _process(delta: float) -> void:
	advance(minf(delta,0.25))
	range_clock -= delta
	if range_clock <= 0 and is_instance_valid(world.player):
		range_clock = 0.5
		visible = world.player.position.distance_squared_to(at) < pow(float(GraphicsManager.preset()["distance"]),2)

func advance(seconds: float) -> void:
	if not is_finite(seconds) or seconds <= 0: return
	restock_left -= seconds
	if restock_left <= 0:
		restock_left = RESTOCK_SECONDS + fmod(restock_left,RESTOCK_SECONDS)
		for id in INITIAL:
			stock[id] = maxi(int(stock.get(id,0)),int(INITIAL[id]))
		changed.emit()

func in_range() -> bool:
	return world.player.position.distance_squared_to(at) < 3.3*3.3

func trade(offer_id: String) -> bool:
	if not OFFERS.has(offer_id) or not in_range() or not world.player.survival.alive():
		last_message = "靠近商人后再交易"
		return false
	var offer: Dictionary = OFFERS[offer_id]
	for id in offer["reward"]:
		if int(stock.get(id,0)) < int(offer["reward"][id]):
			last_message = "商人库存不足，等待补货"
			return false
	if offer_id=="blueprint" and int(InventorySystem.items.get("blueprint",0))>0:
		last_message = "已持有这份蓝图"
		return false
	for id in offer["cost"]:
		if int(stock.get(id,0)) > 9999-int(offer["cost"][id]):
			last_message = "商人已装不下这类材料，未扣除物资"
			return false
	if not InventorySystem.transact(offer["cost"],offer["reward"]):
		last_message = "材料不足或背包已满，未扣除物资"
		return false
	for id in offer["reward"]: stock[id] = int(stock[id])-int(offer["reward"][id])
	for id in offer["cost"]: stock[id] = mini(9999,int(stock.get(id,0))+int(offer["cost"][id]))
	trades += 1
	last_message = "交易完成 · "+offer["name"]
	changed.emit()
	return true

func snapshot() -> Dictionary:
	return {"stock":stock.duplicate(),"restock_left":restock_left,"trades":trades}

func restore(data: Dictionary) -> void:
	stock = INITIAL.duplicate()
	for id in data.get("stock",{}): stock[id] = int(data["stock"][id])
	restock_left = float(data.get("restock_left",RESTOCK_SECONDS))
	trades = int(data.get("trades",0))
	changed.emit()
