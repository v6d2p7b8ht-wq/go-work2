class_name VegetationSystem
extends Node3D
## Trees/grass are chunked MultiMeshes; density, collision and silhouette LOD move together.
var tree_chunks: Array[Dictionary] = []
var grass_chunks: Array[MultiMeshInstance3D] = []
var total_trees := 0
var harvest_entries: Array[Dictionary] = []
var harvest_lookup: Dictionary = {}
var depleted: Dictionary = {}

func build(obstacles: Array[Rect2]) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 38147
	var chunks: Dictionary = {}
	for i in range(340):
		var x := rng.randf_range(40.0, 95.0) * (-1 if i % 3 == 0 else 1)
		var z := rng.randf_range(-91, 94)
		var point := Vector2(x, z)
		var blocked := false
		for rect in obstacles:
			if rect.grow(2.0).has_point(point):
				blocked = true
				break
		if blocked:
			continue
		var cell := Vector2i(floori(x / 24), floori(z / 24))
		if not chunks.has(cell):
			chunks[cell] = []
		chunks[cell].append({"id": "s01_tree_%03d" % i, "at": Vector3(x, TerrainBuilder.height_at(x, z), z), "height": rng.randf_range(6.0, 12.5), "yaw": rng.randf() * TAU})
	var bark := GeometryFactory.material("bark", Color("524b37"), "wood")
	var foliage := GeometryFactory.material("pine", Color("414f3b"), "cloth")
	for cell in chunks:
		var trees: Array = chunks[cell]
		var origin := Vector3(cell.x * 24, 0, cell.y * 24)
		var trunks := _multi(GeometryFactory.cylinder_mesh(), bark, trees.size(), origin)
		var crowns := _multi(GeometryFactory.cone_mesh(), foliage, trees.size() * 2, origin)
		var distant := _multi(GeometryFactory.cone_mesh(), foliage, trees.size(), origin)
		distant.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var collisions: Array[CollisionShape3D] = []
		var ids: Array[String] = []
		for i in range(trees.size()):
			var tree: Dictionary = trees[i]
			var at: Vector3 = tree["at"] - origin
			var h: float = tree["height"]
			var yaw: float = tree["yaw"]
			trunks.multimesh.set_instance_transform(i, Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(0.4, h * 0.65, 0.4)), at + Vector3.UP * h * 0.325))
			crowns.multimesh.set_instance_transform(i * 2, Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(h * 0.48, h * 0.66, h * 0.48)), at + Vector3.UP * h * 0.57))
			crowns.multimesh.set_instance_transform(i * 2 + 1, Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(h * 0.35, h * 0.53, h * 0.35)), at + Vector3.UP * h * 0.77))
			distant.multimesh.set_instance_transform(i, Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(h * 0.46, h * 0.85, h * 0.46)), at + Vector3.UP * h * 0.62))
			var body := StaticBody3D.new()
			body.position = tree["at"] + Vector3.UP * 1.5
			var shape := CollisionShape3D.new()
			var cylinder := CylinderShape3D.new()
			cylinder.radius = 0.23
			cylinder.height = 3
			shape.shape = cylinder
			body.add_child(shape)
			add_child(body)
			collisions.append(shape)
			ids.append(tree["id"])
			var entry := {"id": tree["id"], "at": tree["at"], "index": i, "trunks": trunks, "crowns": crowns, "distant": distant, "shape": shape, "body": body,
				"transforms": [trunks.multimesh.get_instance_transform(i), crowns.multimesh.get_instance_transform(i * 2), crowns.multimesh.get_instance_transform(i * 2 + 1), distant.multimesh.get_instance_transform(i)]}
			harvest_entries.append(entry)
			harvest_lookup[tree["id"]] = entry
		tree_chunks.append({"trunks": trunks, "crowns": crowns, "distant": distant, "collisions": collisions, "ids": ids, "count": trees.size()})
		total_trees += trees.size()
	_build_grass(rng, obstacles)
	GraphicsManager.settings_changed.connect(apply_quality)
	apply_quality()

func _multi(mesh: Mesh, mat: Material, count: int, origin: Vector3) -> MultiMeshInstance3D:
	var resource := MultiMesh.new()
	resource.transform_format = MultiMesh.TRANSFORM_3D
	resource.mesh = mesh
	resource.instance_count = count
	var node := MultiMeshInstance3D.new()
	node.multimesh = resource
	node.material_override = mat
	node.position = origin
	add_child(node)
	return node

func _build_grass(rng: RandomNumberGenerator, obstacles: Array[Rect2]) -> void:
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for angle in [0.0, PI / 2]:
		for v in [Vector3(-0.22, 0, 0), Vector3(0, 0.65, 0), Vector3(0.22, 0, 0)]:
			surface.set_normal(Vector3.UP)
			surface.add_vertex(v.rotated(Vector3.UP, angle))
	var mesh := surface.commit()
	var mat := GeometryFactory.material("grass", Color("777953"))
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var chunks: Dictionary = {}
	for i in range(1800):
		var x := rng.randf_range(-96, 96)
		var z := rng.randf_range(-96, 96)
		if absf(x) < 8.8 or Rect2(12, 25, 19, 24).has_point(Vector2(x, z)):
			continue
		var blocked := false
		for rect in obstacles:
			if rect.has_point(Vector2(x, z)):
				blocked = true
				break
		if blocked:
			continue
		var cell := Vector2i(floori(x / 24), floori(z / 24))
		if not chunks.has(cell):
			chunks[cell] = []
		chunks[cell].append(Vector3(x, TerrainBuilder.height_at(x, z), z))
	for cell in chunks:
		var points: Array = chunks[cell]
		var origin := Vector3(cell.x * 24, 0, cell.y * 24)
		var node := _multi(mesh, mat, points.size(), origin)
		node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		for i in range(points.size()):
			var grass_scale := rng.randf_range(0.4, 1.2)
			node.multimesh.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * grass_scale), points[i] - origin))
		grass_chunks.append(node)

func apply_quality() -> void:
	var preset := GraphicsManager.preset()
	var density: float = preset["foliage"]
	var distance: float = preset["distance"]
	var split := distance * 0.52
	for chunk in tree_chunks:
		var count := maxi(1, int(chunk["count"] * density))
		chunk["trunks"].multimesh.visible_instance_count = count
		chunk["crowns"].multimesh.visible_instance_count = count * 2
		chunk["distant"].multimesh.visible_instance_count = count
		chunk["trunks"].visibility_range_end = split
		chunk["crowns"].visibility_range_end = split
		chunk["distant"].visibility_range_begin = split
		chunk["distant"].visibility_range_end = distance
		for i in range(chunk["collisions"].size()):
			chunk["collisions"][i].set_deferred("disabled", i >= count or depleted.has(chunk["ids"][i]))
	for node in grass_chunks:
		node.multimesh.visible_instance_count = int(node.multimesh.instance_count * density)
		node.visibility_range_end = distance * 0.45

func set_tree_depleted(id: String, value: bool) -> void:
	if not harvest_lookup.has(id):
		return
	var entry: Dictionary = harvest_lookup[id]
	if value:
		depleted[id] = true
	else:
		depleted.erase(id)
	var index: int = entry["index"]
	var original: Array = entry["transforms"]
	var changed: Array[Transform3D] = []
	for original_transform: Transform3D in original:
		changed.append(Transform3D(original_transform.basis.scaled(Vector3.ONE * 0.0001), original_transform.origin) if value else original_transform)
	entry["trunks"].multimesh.set_instance_transform(index, changed[0])
	entry["crowns"].multimesh.set_instance_transform(index * 2, changed[1])
	entry["crowns"].multimesh.set_instance_transform(index * 2 + 1, changed[2])
	entry["distant"].multimesh.set_instance_transform(index, changed[3])
	entry["shape"].set_deferred("disabled", value or index >= entry["trunks"].multimesh.visible_instance_count)
