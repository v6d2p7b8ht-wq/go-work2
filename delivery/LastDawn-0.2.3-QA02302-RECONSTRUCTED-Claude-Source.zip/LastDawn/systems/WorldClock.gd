class_name WorldClock
extends Node
const WEATHER := ["晴朗","多云","小雨","多云"]
const WEATHER_INTERVAL := 240.0
var world: Node3D
var hour := 16.5
var day := 1
var day_seconds := 1200.0
var weather_index := 0
var weather_left := WEATHER_INTERVAL
var visual_clock := 0.0
var rain: CPUParticles3D
var headlamp: OmniLight3D
var updates := 0

func _ready() -> void:
	rain = CPUParticles3D.new()
	rain.name = "LocalRainPool"
	rain.amount = 24
	rain.lifetime = 0.8
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(6,1,6)
	rain.direction = Vector3.DOWN
	rain.gravity = Vector3(0,-8,0)
	rain.initial_velocity_min = 6
	rain.initial_velocity_max = 8
	var drop := BoxMesh.new()
	drop.size = Vector3(0.025,0.65,0.025)
	rain.mesh = drop
	rain.scale_amount_min = 0.65
	rain.scale_amount_max = 1.0
	rain.material_override = GeometryFactory.material("rain_streak",Color("9eafb0"),"",0.2)
	rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	world.add_child(rain)
	headlamp = OmniLight3D.new()
	headlamp.position.y = 1.8
	headlamp.light_color = Color("cad5ba")
	headlamp.omni_range = 8
	headlamp.light_energy = 0.65
	headlamp.shadow_enabled = false
	world.player.add_child(headlamp)
	GraphicsManager.settings_changed.connect(apply_visuals)
	apply_visuals()

func _process(delta: float) -> void:
	advance(minf(delta,0.25))
	visual_clock -= delta
	if visual_clock <= 0:
		visual_clock = 0.5
		apply_visuals()

func advance(seconds: float) -> void:
	if not is_finite(seconds) or seconds<=0: return
	hour += seconds*24.0/day_seconds
	while hour>=24:
		hour -= 24
		day += 1
	weather_left -= seconds
	while weather_left<=0:
		weather_left += WEATHER_INTERVAL
		weather_index = (weather_index+1)%WEATHER.size()

func is_night() -> bool:
	return hour < 6 or hour > 18.5

func display_time() -> String:
	return "第%d天 %02d:%02d · %s" % [day,int(hour),int(fmod(hour,1.0)*60),WEATHER[weather_index]]

func apply_visuals() -> void:
	if not is_instance_valid(world.atmosphere): return
	updates += 1
	var atmosphere: Atmosphere = world.atmosphere
	var daylight := clampf(sin((hour-6)/12.0*PI),0.0,1.0)
	var cloud := 0.18 if weather_index==1 or weather_index==3 else (0.32 if weather_index==2 else 0.0)
	atmosphere.sun.rotation_degrees = Vector3(-maxf(4,daylight*65),-33+(hour-12)*7,0)
	atmosphere.sun.light_energy = lerpf(0.08,1.5,daylight)*(1-cloud)
	atmosphere.sun.light_color = Color("b3c3d1") if daylight<0.1 else Color("ffe0a2")
	atmosphere.environment.ambient_light_energy = lerpf(0.27,0.68,daylight)*(1-cloud*0.3)
	atmosphere.environment.ambient_light_color = Color("879fba").lerp(Color("a6b6b1"),daylight)
	atmosphere.sky_material.sky_top_color = Color("182c40").lerp(Color("647e83"),daylight)
	atmosphere.sky_material.sky_horizon_color = Color("3b4f5e").lerp(Color("c6bea1"),daylight)
	atmosphere.environment.fog_density = 0.0045 + (0.004 if weather_index==2 else 0.0015*cloud)
	headlamp.visible = daylight < 0.2
	rain.position = world.player.position+Vector3.UP*6
	var particles: int = GraphicsManager.preset()["particles"]
	rain.emitting = weather_index==2 and particles>0
	rain.visible = rain.emitting
	if particles>0: rain.amount = mini(24,particles)
	atmosphere.wind.volume_db = -19 if weather_index==2 else -22

func snapshot() -> Dictionary:
	return {"hour":hour,"day":day,"day_seconds":day_seconds,"weather_index":weather_index,"weather_left":weather_left}

func restore(data: Dictionary) -> void:
	hour = float(data.get("hour",16.5))
	day = int(data.get("day",1))
	day_seconds = float(data.get("day_seconds",1200))
	weather_index = int(data.get("weather_index",0))
	weather_left = float(data.get("weather_left",WEATHER_INTERVAL))
	apply_visuals()
