class_name WorldRegistry
extends RefCounted
## Data and typed extension boundaries only. Reserved features are not presented as playable.
signal extension_event(topic: StringName, payload: Dictionary)
var data: Dictionary = {}

func _init() -> void:
	var file := FileAccess.open("res://data/world_states.json", FileAccess.READ)
	if file:
		var parsed = JSON.parse_string(file.get_as_text())
		if parsed is Dictionary:
			data = parsed

func state_info(id: String) -> Dictionary:
	for state in data.get("states", []):
		if state.get("id") == id:
			return state.duplicate(true)
	return {}

func can_enter(id: String) -> bool:
	return bool(state_info(id).get("available", false))

func publish(topic: StringName, payload: Dictionary = {}) -> bool:
	if String(topic) not in data.get("reserved_hooks", []):
		return false
	extension_event.emit(topic, payload.duplicate(true))
	return true
