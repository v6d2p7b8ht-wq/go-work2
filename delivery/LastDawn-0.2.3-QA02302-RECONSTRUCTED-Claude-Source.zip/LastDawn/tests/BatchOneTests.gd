extends Node
var checks := 0
var failures := 0
func expect(value: bool, message: String) -> void:
	checks += 1
	if value:
		print("PASS | ", message)
	else:
		failures += 1
		push_error("FAIL | " + message)
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("run")
func run() -> void:
	var world: WorldManager = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.ready_for_saves = false
	world.player.set_physics_process(false)
	for npc in world.zombies:
		npc.set_physics_process(false)
	var resources := world.resources
	var player := world.player
	player.survival.apply_settings(SurvivalSystem.DEFAULTS, false)
	GraphicsManager.set_quality(4)
	await get_tree().physics_frame
	InventorySystem.restore({})
	expect(resources.records.size() == world.vegetation.total_trees + 6, "Every original forest tree has a stable harvest record; six ore nodes are added")
	var tree: Dictionary = world.vegetation.harvest_entries[0]
	var record: Dictionary = resources.records[tree["id"]]
	player.position = Vector3(record["at"]) + Vector3(1.4, 0.06, 0)
	await get_tree().physics_frame
	expect(resources.can_reach(record, player) and resources.nearest(player).get("id") == record["id"], "Actual visible forest tree is reachable through its own low-cost collider")
	player.stamina = 100
	expect(resources.harvest(record["id"], player) and InventorySystem.items["wood"] == 1 and player.stamina == 93 and record["remaining"] == 3, "Tree gathering grants wood and charges stamina once")
	expect(not resources.harvest(record["id"], player) and InventorySystem.items["wood"] == 1, "Rapid repeated gather action cannot bypass cooldown")
	resources.cooldown = 0
	player.stamina = 0
	expect(not resources.harvest(record["id"], player) and record["remaining"] == 3, "Exhaustion cannot remove resource stock")
	player.stamina = 100
	for i in range(3):
		resources.cooldown = 0
		resources.harvest(record["id"], player)
	await get_tree().process_frame
	await get_tree().process_frame # Flush deferred physics and MultiMesh changes.
	expect(record["remaining"] == 0 and InventorySystem.items["wood"] == 4 and not resources.available(record), "Finite tree yields exactly four wood and becomes unavailable")
	# Headless Dummy returns identity for MultiMesh readback. Visual transform is checked in WebGL.
	expect(tree["shape"].disabled, "Depleted tree releases its original physics collider")
	GraphicsManager.set_quality(0)
	GraphicsManager.set_quality(4)
	await get_tree().physics_frame
	expect(tree["shape"].disabled, "Quality changes never resurrect a harvested tree collider")
	var depleted := resources.snapshot()
	resources.restore({})
	await get_tree().physics_frame
	expect(record["remaining"] == 4 and not tree["shape"].disabled, "Loading an earlier forest state restores tree mesh and collider")
	resources.restore(depleted)
	await get_tree().physics_frame
	expect(record["remaining"] == 0 and tree["shape"].disabled, "Depleted tree state round-trips without resource duplication")
	var ore: Dictionary = resources.records["s01_ore_00"]
	player.position = Vector3(ore["at"]) + Vector3(-1.8, 0.06, 0)
	player.stamina = 100
	resources.cooldown = 0
	await get_tree().physics_frame
	world.interact()
	expect(InventorySystem.items["stone"] == 1 and InventorySystem.items["ore"] == 1 and ore["remaining"] == 4, "Existing touch interaction path mines real ore into stone and minerals")
	expect(world.noises.serial >= 5, "Gathering publishes audible events into the reused noise pool")
	for i in range(4):
		resources.cooldown = 0
		resources.harvest(ore["id"], player)
	await get_tree().physics_frame
	expect(not ore["node"].visible and ore["remaining"] == 0 and InventorySystem.items["ore"] == 5, "Ore depletes without spawning or freeing per-hit nodes")
	var examined := resources.candidates_checked
	resources.nearest(player)
	expect(resources.candidates_checked - examined < resources.records.size() / 2.0, "Nearby resource query uses spatial buckets rather than scanning the whole forest")
	player.position = Vector3(40, 0.05, 0)
	expect(not resources.harvest(ore["id"], player), "Remote interaction cannot gather across the map")
	var glyphs := "饱食饮水采集矿物饥饿缺水攻击间隔失能恢复"
	var font_ok := true
	for i in range(glyphs.length()):
		font_ok = font_ok and world.hud.theme.default_font.has_char(glyphs.unicode_at(i))
	expect(font_ok, "Embedded legal font contains the new survival UI glyphs")
	player.position = Vector3(6, 0.05, 31)
	player.survival.health = 72
	player.survival.hunger = 40
	player.survival.thirst = 30
	player.stamina = 42
	var settings := player.survival.settings.duplicate()
	settings["hunger_per_minute"] = 4.2
	player.survival.apply_settings(settings)
	InventorySystem.restore({"wood": 7, "stone": 5, "food": 2, "water": 3, "ore": 5})
	world.zombies[0].state = ZombieAI.State.INVESTIGATE
	world.zombies[0].last_seen = Vector3(2, 0.05, -15)
	world.zombies[0].investigate_time = 3
	var saved := world.create_snapshot()
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(saved))), "Serialized version-two numbers remain valid after JSON decoding")
	expect(SaveManager.valid_snapshot(saved) and SaveManager.save_world(world), "Version two snapshot atomically saves all batch-one systems")
	player.survival.restore({})
	InventorySystem.restore({})
	resources.restore({})
	world.zombies[0].position = Vector3.ZERO
	expect(SaveManager.load_world(world), "Actual local disk save reloads the integrated world")
	expect(player.survival.health == 72 and player.survival.hunger == 40 and player.survival.thirst == 30 and player.stamina == 42, "Health, fullness, hydration and stamina restore together")
	expect(is_equal_approx(player.survival.settings["hunger_per_minute"], 4.2) and InventorySystem.items["water"] == 3 and InventorySystem.items["ore"] == 5, "Survival rates and new item IDs survive save reload")
	expect(resources.records[record["id"]]["remaining"] == 0 and resources.records[ore["id"]]["remaining"] == 0, "Tree and ore depletion persist across world save reload")
	expect(world.zombies[0].state == ZombieAI.State.INVESTIGATE and world.zombies[0].investigate_time == 3 and world.zombies[0].position.distance_to(world.zombies[0].home) < 0.3, "Infected state, memory and position restore without resetting all AI")
	world.hud.show_inventory()
	expect(world.use_item("food") and InventorySystem.items["food"] == 1 and player.survival.hunger == 72, "Inventory food use consumes exactly one item and restores fullness")
	expect(world.use_item("water") and InventorySystem.items["water"] == 2 and player.survival.thirst == 75, "Inventory drinking restores hydration independently")
	await get_tree().process_frame
	expect(get_tree().paused and world.hud.current_modal == "inventory" and world.hud.controls.look_touch == -1, "Deferred consumable UI refresh preserves pause and clears camera ownership")
	world.hud.close_modal()
	player.survival.hunger = 100
	player.stamina = 100
	expect(not world.use_item("food") and InventorySystem.items["food"] == 1, "Full survivor does not waste food")
	var invalid := saved.duplicate(true)
	invalid["survival"]["health"] = INF
	expect(not SaveManager.valid_snapshot(invalid), "Nonfinite survival saves are rejected")
	invalid = saved.duplicate(true)
	invalid["resources"]["remaining"][record["id"]] = 0.5
	expect(not SaveManager.valid_snapshot(invalid), "Fractional resource stock cannot enter a save")
	invalid = saved.duplicate(true)
	invalid["infected"][0]["position"] = [1000, 0, 0]
	expect(not SaveManager.valid_snapshot(invalid), "Out-of-map AI save positions are rejected")
	invalid = saved.duplicate(true)
	invalid["infected"].append(invalid["infected"][0])
	expect(not SaveManager.valid_snapshot(invalid), "Duplicate or excessive saved infected cannot inflate NPC count")
	var legacy := saved.duplicate(true)
	legacy["version"] = 1
	legacy.erase("survival")
	legacy.erase("resources")
	legacy.erase("infected")
	legacy["inventory"] = {"wood": 9, "stone": 4, "food": 2}
	legacy["stamina"] = 37
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(legacy))), "JSON-decoded legacy version number remains compatible")
	expect(SaveManager.valid_snapshot(legacy), "Original phase-one version one saves remain accepted")
	var poisoned_legacy := legacy.duplicate(true)
	poisoned_legacy["survival"] = "invalid extra field"
	expect(not SaveManager.valid_snapshot(poisoned_legacy), "Legacy version cannot bypass validation of unexpected new fields")
	world.restore_snapshot(legacy)
	expect(player.survival.health == 100 and player.survival.hunger == 100 and player.survival.thirst == 100 and player.stamina == 37 and InventorySystem.items["wood"] == 9 and InventorySystem.items["water"] == 0, "Legacy migration preserves inventory and stamina while supplying new defaults")
	expect(resources.records[ore["id"]]["remaining"] == 5 and world.zombies[0].state == ZombieAI.State.PATROL, "Legacy migration initializes new resource and AI data safely")
	expect(world.create_snapshot()["version"] == SaveManager.VERSION and SaveManager.save_world(world), "Next save upgrades legacy data to the current validated schema")
	player.survival.take_damage(1000)
	await get_tree().process_frame
	await get_tree().process_frame
	expect(world.hud.current_modal == "incapacitated" and get_tree().paused and world.hud.controls.look_touch == -1, "Incapacitation opens a paused touch-safe recovery dialog")
	world.hud.close_modal()
	expect(get_tree().paused, "Closing the recovery dialog cannot resume an incapacitated player")
	player.rescue()
	world.hud.close_modal()
	expect(not get_tree().paused and world.is_safe(player.position) and player.survival.health == 65, "Recovery returns to actual safe area with inventory retained")
	world.queue_free()
	await get_tree().process_frame
	print("RESULT | %d batch-one integration checks, %d failures" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)
