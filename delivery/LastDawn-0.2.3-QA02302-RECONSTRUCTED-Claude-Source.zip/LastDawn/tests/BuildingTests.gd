extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.player.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var player := world.player
	var builds := world.buildings
	InventorySystem.restore({"wood":20,"stone":12})
	player.position = Vector3(9,0.05,40)
	await get_tree().physics_frame
	var site := Vector3(8.5,TerrainBuilder.height_at(8.5,36),36)
	print("SITE | ",builds.check_place("campfire",site,0))
	expect(builds.place("campfire",site,0),"Campfire can be constructed at a clear reachable site")
	expect(InventorySystem.items["wood"]==18 and InventorySystem.items["stone"]==10 and builds.records.size()==1,"Construction charges its complete recipe once")
	var record: Dictionary = builds.records[0] if not builds.records.is_empty() else {}
	if not record.is_empty():
		expect(builds.nodes[record["id"]].get_node("Flame").visible,"Campfire produces a real visible emissive flame")
		builds.toggle_fire(record["id"])
		expect(not record["lit"] and not builds.nodes[record["id"]].get_node("Flame").visible,"Campfire interaction switches its saved and rendered state")
	var count := InventorySystem.snapshot()
	expect(not builds.place("wall",site,0) and InventorySystem.snapshot()==count,"Overlapping construction never charges materials")
	expect(not builds.check_place("wall",Vector3(0,0,36),0).is_empty(),"Road placement is rejected")
	expect(not builds.check_place("wall",Vector3(18,0,32),0).is_empty(),"Public safe-zone placement is rejected")
	player.position = Vector3(8.5,0.05,43)
	var wall_at := Vector3(8.5,TerrainBuilder.height_at(8.5,47),47)
	expect(builds.place("wall",wall_at,0),"Solid wall is constructible")
	await get_tree().physics_frame
	var ray := PhysicsRayQueryParameters3D.create(wall_at+Vector3(0,1,-2),wall_at+Vector3(0,1,2),1)
	expect(not world.get_world_3d().direct_space_state.intersect_ray(ray).is_empty(),"Placed wall participates in actual physics")
	player.position = Vector3(8.5,0.05,61)
	expect(not builds.check_place("shelter",Vector3(8.5,0,57),0).is_empty(),"Existing street-light collision rejects an obstructed shelter site")
	player.position = Vector3(8.5,0.05,68)
	var shelter_at := Vector3(8.5,TerrainBuilder.height_at(8.5,64),64)
	expect(builds.place("shelter",shelter_at,0),"Third recipe creates an actual enterable shelter")
	expect(world.is_safe(shelter_at) and not world.is_safe(shelter_at+Vector3(0,0,-3)),"Shelter protects its interior without making the surrounding map safe")
	await get_tree().physics_frame
	var entry_ray := PhysicsRayQueryParameters3D.create(shelter_at+Vector3(0,1,-3),shelter_at+Vector3(0,1,0),1)
	expect(world.get_world_3d().direct_space_state.intersect_ray(entry_ray).is_empty(),"Shelter doorway remains physically open")
	InventorySystem.restore({})
	var before := builds.records.size()
	expect(not builds.place("campfire",Vector3(8.5,0,40),0) and builds.records.size()==before,"Insufficient materials produce no structure")
	var snapshot := world.create_snapshot()
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(snapshot))),"Schema 3 building snapshot survives JSON number conversion")
	builds.restore({})
	expect(builds.records.is_empty(),"Restore replaces rather than appends structures")
	world.restore_snapshot(snapshot)
	expect(builds.records.size()==before and not builds.records[0]["lit"],"Building IDs and campfire state restore without duplication")
	world.restore_snapshot(snapshot)
	expect(builds.records.size()==before,"Repeated load does not duplicate structures")
	var malformed := snapshot.duplicate(true)
	malformed["phase2"]["buildings"]["records"][0]["position"] = [NAN,0,0]
	expect(not SaveManager.valid_snapshot(malformed),"Invalid structure transforms are rejected before world mutation")
	var legacy := snapshot.duplicate(true)
	legacy["version"] = 2
	legacy.erase("phase2")
	expect(SaveManager.valid_snapshot(legacy),"Unmodified v0.2.2 schema 2 remains readable")
	world.restore_snapshot(legacy)
	expect(builds.records.is_empty(),"Legacy migration initializes an empty construction state")
	InventorySystem.restore({"wood":1199})
	expect(InventorySystem.slots_used()==24 and not InventorySystem.add_item("stone",1),"Stack capacity rejects additions without losing existing materials")
	var full := InventorySystem.snapshot()
	expect(not InventorySystem.transact({"wood":1},{"stone":1}) and InventorySystem.snapshot()==full,"Net slot overflow rolls back both sides of a transaction")
	InventorySystem.restore({"wood":50})
	expect(InventorySystem.transact({"wood":50},{"stone":1}) and InventorySystem.items["wood"]==0 and InventorySystem.items["stone"]==1,"A material transaction reuses released capacity atomically")
	InventorySystem.restore({"food":9999})
	expect(InventorySystem.items["food"]==9999 and InventorySystem.slots_used()>24,"Over-capacity legacy data is retained without truncation")
	expect(InventorySystem.transact({"food":1},{}) and InventorySystem.items["food"]==9998,"Legacy over-capacity stacks can still spend materials without needing a whole free slot")
	var ore: Dictionary = world.resources.records["s01_ore_00"]
	player.position = ore["at"]+Vector3(-1.8,0.05,0)
	player.stamina = 100
	InventorySystem.restore({})
	world.resources.cooldown = 0
	await get_tree().physics_frame
	var accepted := world.harvest_feedback.accepted
	expect(world.resources.harvest(ore["id"],player) and world.harvest_feedback.accepted==accepted+1 and player.visual.harvest_kind=="ore","Successful mining triggers the pickaxe pose and pooled feedback")
	player.visual.animate(0.2,0)
	expect(player.visual.right_arm.rotation.x>0.7 and player.visual.tool.visible,"Mining swing raises its visible tool toward the character's forward side")
	expect(not world.resources.harvest(ore["id"],player) and world.harvest_feedback.accepted==accepted+1,"Rejected cooldown harvest produces no duplicate feedback")
	expect(world.harvest_feedback.wood_sound.get_length()>0 and world.harvest_feedback.ore_sound.get_length()>0,"Original harvest audio resources actually import")
	expect(OS.get_user_data_dir().contains("LastDawnPhase2Test"),"Preview profile isolates all stable save and camera files")
	print("RESULT | ",checks," building/harvest checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
