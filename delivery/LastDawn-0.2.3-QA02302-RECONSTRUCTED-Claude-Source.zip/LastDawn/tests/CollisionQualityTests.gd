extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ", label)
	if not ok: failures += 1
func ticks(count: int) -> void:
	for i in range(count): await get_tree().physics_frame
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await ticks(4)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var player := world.player
	player.set_physics_process(false)
	for quality in range(5):
		GraphicsManager.set_quality(quality)
		var preset := GraphicsManager.preset()
		expect(is_equal_approx(get_viewport().scaling_3d_scale, preset["scale"]), "Quality %d applies internal 3D scale" % quality)
		expect(world.atmosphere.sun.shadow_enabled == (preset["shadow"] > 0), "Quality %d applies sun shadow policy" % quality)
		expect(world.atmosphere.dust.emitting == (preset["particles"] > 0), "Quality %d applies particle budget" % quality)
		expect(is_equal_approx(player.rig.camera.far, preset["distance"] + 25), "Quality %d applies view distance" % quality)
		var chunk: Dictionary = world.vegetation.tree_chunks[0]
		expect(chunk["trunks"].multimesh.visible_instance_count == maxi(1, int(chunk["count"] * preset["foliage"])) and chunk["distant"].visibility_range_begin < chunk["distant"].visibility_range_end, "Quality %d applies vegetation density and distance LOD" % quality)
	player.position = Vector3(-7, 0.05, -12)
	player.rig.yaw = -PI / 2
	player.rig.pitch = 0
	await ticks(10)
	expect(player.rig.arm.get_hit_length() < 2.0 and player.rig.camera.global_position.x > -8.7, "Camera sphere spring arm stays in front of supermarket wall")
	player.rig.yaw = 0
	player.position = Vector3(-7, 0.05, -12)
	player.velocity = Vector3.ZERO
	player.set_physics_process(true)
	Input.action_press("move_left")
	await ticks(120)
	Input.action_release("move_left")
	expect(player.position.x > -8.6 and player.position.x < -7.4, "Player capsule cannot walk through the solid supermarket facade")
	player.position = Vector3(-6, 0.05, -7)
	player.velocity = Vector3.ZERO
	Input.action_press("move_left")
	await ticks(120)
	Input.action_release("move_left")
	expect(player.position.x < -10.5, "Actual supermarket entrance remains passable")
	player.set_physics_process(false)
	var terrain := world.get_node("TerrainSurface") as MeshInstance3D
	var arrays := terrain.mesh.surface_get_arrays(0)
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
	var exclude: Array[RID] = []
	for body in world.find_children("*", "StaticBody3D", true, false):
		if body.name != "HeightMapTerrain200m": exclude.append(body.get_rid())
	var maximum_error := 0.0
	var hits := 0
	for triangle in range(300, indices.size() - 3, 1797):
		var center := (vertices[indices[triangle]] + vertices[indices[triangle+1]] + vertices[indices[triangle+2]]) / 3.0
		var ray := PhysicsRayQueryParameters3D.create(center + Vector3.UP * 30, center - Vector3.UP * 30, 1, exclude)
		var hit := world.get_world_3d().direct_space_state.intersect_ray(ray)
		if not hit.is_empty():
			hits += 1
			maximum_error = maxf(maximum_error, absf(hit["position"].y - center.y))
	print("TERRAIN | samples=", hits, " max mesh/collider error=", maximum_error)
	expect(hits >= 15 and maximum_error < 0.15, "Sampled hillside rendered triangles agree with terrain collision height")
	print("RESULT | ", checks, " collision/quality checks | ", failures, " failures")
	get_tree().quit(1 if failures else 0)
