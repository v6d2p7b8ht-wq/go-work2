extends Node
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	var world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.player.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var content := {"resources":[],"pickups":[]}
	var ids: Array = world.resources.records.keys()
	ids.sort()
	for id in ids:
		var record: Dictionary = world.resources.records[id]
		var at: Vector3 = record["at"]
		content["resources"].append({"id":id,"kind":record["kind"],"at":[snappedf(at.x,0.0001),snappedf(at.y,0.0001),snappedf(at.z,0.0001)]})
	for record in world.pickup_specs:
		var at: Vector3 = record["at"]
		content["pickups"].append({"id":record["id"],"item":record["item"],"amount":record["amount"],"at":[snappedf(at.x,0.0001),snappedf(at.y,0.0001),snappedf(at.z,0.0001)]})
	var args := OS.get_cmdline_user_args()
	var output := args[args.find("--output")+1]
	var file := FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify(content))
	file.close()
	if "--legacy-save" in args:
		var id: String = ids.filter(func(value: String) -> bool: return value.begins_with("s01_tree_"))[0]
		world.resources.records[id]["remaining"] = 0
		world.resources._set_depleted(world.resources.records[id],true)
		InventorySystem.restore({"wood":7,"stone":4,"food":2,"water":3,"ore":5})
		world.player.position = Vector3(6,0.5,32)
		world.player.stamina = 83
		var snapshot: Dictionary = world.create_snapshot()
		file = FileAccess.open(args[args.find("--legacy-save")+1],FileAccess.WRITE)
		file.store_string(JSON.stringify(snapshot))
		file.close()
	print("CONTENT | ",content["resources"].size()," stable resource IDs; ",content["pickups"].size()," pickups")
	get_tree().quit()
