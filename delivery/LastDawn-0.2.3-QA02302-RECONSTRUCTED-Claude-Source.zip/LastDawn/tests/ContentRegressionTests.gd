extends Node
var checks := 0
var failures := 0
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	var world: WorldManager = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.player.set_physics_process(false)
	world.family.member.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var baseline: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/v022-content.json"))
	var resources_match: bool = baseline["resources"].size()==world.resources.records.size()
	for record in baseline["resources"]:
		if not world.resources.records.has(record["id"]):
			resources_match = false
			continue
		var current: Dictionary = world.resources.records[record["id"]]
		var at: Vector3 = current["at"]
		resources_match = resources_match and current["kind"]==record["kind"] and at.distance_to(Vector3(record["at"][0],record["at"][1],record["at"][2]))<0.0002
	expect(resources_match,"Every resource ID and position matches the actual independently loaded v0.2.2 world")
	var pickups_match: bool = baseline["pickups"].size()==world.pickup_specs.size()
	for i in range(baseline["pickups"].size()):
		var old: Dictionary = baseline["pickups"][i]
		var current: Dictionary = world.pickup_specs[i]
		pickups_match = pickups_match and current["id"]==old["id"] and current["item"]==old["item"] and current["amount"]==old["amount"] and Vector3(current["at"]).distance_to(Vector3(old["at"][0],old["at"][1],old["at"][2]))<0.0002
	expect(pickups_match,"All original pickup IDs, amounts and locations remain intact")
	var original := FileAccess.get_file_as_string("res://tests/fixtures/v022-real-save.json")
	var legacy: Dictionary = JSON.parse_string(original)
	expect(legacy["version"]==2 and SaveManager.valid_snapshot(legacy),"Real v0.2.2 save fixture passes the new schema boundary")
	world.restore_snapshot(legacy)
	await get_tree().physics_frame
	var inventory_ok := true
	for id in legacy["inventory"]: inventory_ok = inventory_ok and InventorySystem.items[id]==legacy["inventory"][id]
	expect(inventory_ok and world.player.stamina==83 and world.family.stage=="not_started","Migration preserves old item/stamina values and initializes new tasks")
	var tree_id: String = legacy["resources"]["remaining"].keys()[0]
	expect(world.resources.records[tree_id]["remaining"]==0 and world.resources.records[tree_id]["tree"]["shape"].disabled,"Previously depleted tree remains the same removed tree after migration")
	expect(SaveManager.save_world(world) and SaveManager.read_snapshot()["version"]==3,"Next preview save writes schema 3 with the migrated content")
	expect(FileAccess.get_file_as_string("res://tests/fixtures/v022-real-save.json")==original,"Migration leaves the read-only original stable save bytes untouched")
	print("RESULT | ",checks," stable-content/migration checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
