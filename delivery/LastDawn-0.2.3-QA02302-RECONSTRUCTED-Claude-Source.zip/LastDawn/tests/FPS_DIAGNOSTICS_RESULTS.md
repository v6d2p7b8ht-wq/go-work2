# 0.2.1 FPS 专项实际测试

环境：Godot 4.6.3 stable；Linux 无界面引擎测试；Chromium / SwiftShader 软件 WebGL2 + 合成触屏。没有 iPhone、Safari 或 Android 真机，不能用云端 FPS 评价手机性能。

| 测试 | 实际结果 |
| --- | --- |
| 新增 PerformanceTests | 34 通过 / 0 失败 |
| 原五组引擎回归 | 生存 17 / AI 20 / 采集存档 40 / 原玩法 53 / 触控 33，163 通过 / 0 失败 |
| 合计引擎 | 197 通过 / 0 失败 |
| 稳定脚本 / 输入隔离静态检查 | 14 通过 / 0 失败 |
| 新增真实 Web 导出诊断流程 | 23 通过 / 0 失败 |
| 原 Safari 输入专项（Chromium 模拟） | 21 通过 / 0 失败 |

新增流程实际触屏选择 120，确认 target 与 Engine.max_fps 都为 120；切换画质不覆盖；实际重载页面后仍为 120；60 按钮设置引擎上限；浏览器 / 渲染窗口独立、菜单标注 / 最近游戏窗口、失焦重置、低样本预热、竖屏界面与错误日志检查。原输入专项覆盖单指 / 多指、DPR 1 / 3、UI 所有权、取消 / 生命周期与上下反转。其合成 Safari 类事件不能冒充 iOS Safari 真机。

本次云端轻量页 rAF 实测平均 **60.00 回调/秒**，1% Low 59.52、平均间隔 16.666 ms。游戏目标 120 / 引擎上限 120，Engine 实测 8；提交窗口平均 **8.45 FPS**、118.38 ms、84 个间隔。低于 100 个间隔时 1% Low 显示采样中，未把 0 当作测得低帧。原始 JSON 保留实际值。**这些只描述云端软件渲染器，不证明用户 Safari 限制来源。**

首次测试因软件 GPU 低于 10 FPS、10 秒窗口不足 100 个间隔而触发过强断言，已将自动化改成校验有效平均值并接受明确的 1% Low 预热状态；字体缺字、诊断返回按钮位置及菜单即时替换的 can_process 错误在浏览器发现并修正，最终重新构建与重跑。没有提高计数器或舍弃前台卡顿来使测试通过。

## 构建与边界

Android 0.2.1 Debug / versionCode 3 / ARM64：实际 Godot 导出，签名 v2 / v3 验证，16 KiB 对齐，与旧包使用相同调试证书。Web：实际 Godot Compatibility / WebGL2 单线程导出；原 WASM 37,700,666 字节，gzip 9,382,282 字节，解压后字节相同。没有使用非原版引擎或更改主循环。日志中的 ADB daemon 未连接说明无安卓真机，不影响实际离线导出。

仍待真机：iPhone 机型 / ProMotion、iOS / Safari 版本、低电量 / 限制帧速率、主屏幕模式、页面调度上限、真实 GPU / CPU / 温升、Android 90 / 120 能力、Safari 多指回归与后台恢复。云端不能回答这些硬件问题。

## 开发者复现

```sh
bash tests/run_batch_one.sh
godot --headless --rendering-method gl_compatibility --path . res://tests/PerformanceTests.tscn -- --test
python3 tests/fps_static_checks.py
bash export/build.sh
python3 -m http.server 8770 --bind 127.0.0.1 --directory export/web-static
# 另一个终端依次运行，避免软件 GPU 争用：
python3 tests/fps_diagnostics_browser.py http://127.0.0.1:8770
python3 tests/safari_touch_browser.py http://127.0.0.1:8770
```

玩家使用交付网址或 APK，不需要运行命令。原始日志在 tests/logs/fps-diagnostics，浏览器记录和截图在 tests/fps-browser-results、tests/safari-results。
