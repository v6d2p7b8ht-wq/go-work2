extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func ticks(count: int) -> void:
	for i in range(count): await get_tree().physics_frame
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await ticks(3)
	var player := world.player
	var quest := world.family
	var npc := quest.member
	player.set_physics_process(false)
	quest.set_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	InventorySystem.restore({})
	var spawn_query := PhysicsShapeQueryParameters3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.29
	capsule.height = 1.6
	spawn_query.shape = capsule
	spawn_query.transform.origin = npc.position+Vector3.UP*0.84
	spawn_query.collision_mask = 1
	expect(world.get_world_3d().direct_space_state.intersect_shape(spawn_query,4).is_empty(),"Family spawns clear of the existing street-light collider")
	player.position = Vector3.ZERO
	expect(not quest.start_following() and quest.stage=="not_started","Family cannot be recruited remotely")
	player.position = FamilyCompanion.HOME+Vector3(0,0,1)
	expect(quest.start_following(),"Nearby family interaction starts the real escort")
	player.position = Vector3(9,0.05,23)
	await ticks(240)
	print("FOLLOW | ",npc.position," target ",player.position)
	expect(npc.position.distance_to(player.position)<4 and npc.position.z>19,"Family physically follows along the street without teleporting")
	var during := world.create_snapshot()
	expect(quest.wait_here(),"Nearby family can be told to wait")
	var waited := npc.position
	await ticks(60)
	expect(Vector2(npc.position.x-waited.x,npc.position.z-waited.z).length()<0.05,"Waiting family remains in place")
	world.restore_snapshot(during)
	expect(quest.stage=="following" and npc.route.is_empty() and npc.velocity==Vector3.ZERO,"Loading an escort rebuilds navigation without replaying a stale route")
	player.position = Vector3(17,0.05,30)
	await ticks(300)
	player.position = Vector3(20,0.05,35)
	await ticks(360)
	print("ARRIVAL | ",npc.position," target ",player.position)
	expect(FamilyQuest.DESTINATION.has_point(Vector2(npc.position.x,npc.position.z)) and npc.position.distance_to(player.position)<5,"Family navigates the actual camp entrance and static NPC obstacles")
	quest.check_arrival(1)
	expect(quest.stage=="following" and not quest.reward_claimed,"Arrival requires a dwell period rather than a single boundary touch")
	quest.check_arrival(1.1)
	expect(quest.stage=="evacuated" and quest.reward_claimed and InventorySystem.items["food"]==2 and InventorySystem.items["water"]==2,"Both actors reaching camp completes the task and grants one reward")
	var reward := InventorySystem.snapshot()
	expect(not quest.claim_reward() and InventorySystem.snapshot()==reward,"Evacuation reward is not repeatable")
	var finished := world.create_snapshot()
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(finished))),"Completed family task validates through JSON serialization")
	world.restore_snapshot(finished)
	world.restore_snapshot(finished)
	expect(quest.stage=="evacuated" and quest.reward_claimed and InventorySystem.snapshot()==reward,"Repeated reload preserves completed task and item counts")
	var invalid := finished.duplicate(true)
	invalid["phase2"]["family"]["stage"] = "following"
	expect(not SaveManager.valid_snapshot(invalid),"Claimed rewards cannot be paired with an unfinished task in a save")
	invalid = finished.duplicate(true)
	invalid["phase2"]["family"]["position"] = [0,NAN,0]
	expect(not SaveManager.valid_snapshot(invalid),"Malformed family position is rejected")
	npc.set_physics_process(false)
	quest.stage = "following"
	quest.reward_claimed = false
	quest.arrival_time = 0
	player.position = Vector3(20,0.05,35)
	npc.position = Vector3(18,0.05,28)
	quest.check_arrival(3)
	expect(quest.stage=="following","Player alone reaching camp cannot evacuate family left outside")
	npc.position = Vector3(20,0.05,34)
	InventorySystem.restore({"food":9999,"water":9999})
	quest.check_arrival(3)
	expect(quest.stage=="evacuated" and not quest.reward_claimed and InventorySystem.items["food"]==9999,"Full inventory leaves a persisted pending reward instead of deleting items")
	var pending := world.create_snapshot()
	world.restore_snapshot(pending)
	expect(quest.stage=="evacuated" and not quest.reward_claimed,"Pending reward state survives loading")
	InventorySystem.restore({})
	expect(quest.claim_reward() and InventorySystem.items["food"]==2,"Pending reward can be claimed once after making capacity")
	InventorySystem.restore({"wood":8,"stone":3})
	player.position = Vector3(8.5,0.05,68)
	var shelter := Vector3(8.5,0,64)
	expect(world.buildings.place("shelter",shelter,0),"Escort fixture can build an actual alternative shelter")
	player.position = shelter+Vector3.UP*0.05
	npc.position = shelter+Vector3(0.3,0.05,0)
	quest.stage = "following"
	quest.reward_claimed = false
	quest.arrival_time = 0
	quest.check_arrival(3)
	expect(world.is_safe(shelter) and quest.stage=="following","Player-made shelter is not confused with the public evacuation destination")
	npc.position = FamilyCompanion.HOME
	player.position = Vector3(90,1,90)
	npc.reset_route()
	npc._think()
	var paths := npc.paths
	var decisions := npc.decisions
	npc.set_physics_process(true)
	await ticks(90)
	expect(npc.sleeping and npc.paths==paths and npc.decisions-decisions<=3,"Distant family sleeps with low-frequency decisions and no path searches")
	var legacy := finished.duplicate(true)
	npc.position = Vector3(9,0.05,35)
	player.position = Vector3(20,0.05,35)
	quest.stage = "following"
	npc.reset_route()
	await ticks(720)
	print("FENCE DETOUR | ",npc.position)
	expect(FamilyQuest.DESTINATION.has_point(Vector2(npc.position.x,npc.position.z)),"Family detours through the open entrance instead of getting stuck behind the camp fence")
	legacy["version"] = 2
	legacy.erase("phase2")
	world.restore_snapshot(legacy)
	expect(quest.stage=="not_started" and not quest.reward_claimed and npc.position.distance_to(FamilyCompanion.HOME)<0.1,"Legacy save migration initializes the family without inventing quest progress")
	print("RESULT | ",checks," family/escort checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
