extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func ticks(count: int) -> void:
	for i in range(count): await get_tree().physics_frame
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await ticks(3)
	world.player.set_physics_process(false)
	world.family.member.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	GraphicsManager.set_quality(0)
	var guard_entry: Dictionary = world.actor_lod.entries[0]
	var guard_at := world.guard_visual.global_position
	world.player.position = guard_at+Vector3(0,0,5)
	world.actor_lod.refresh()
	expect(world.guard_visual.visible and not guard_entry["proxy"].visible,"Near actor uses original articulated visual")
	world.player.position = guard_at+Vector3(0,0,32)
	world.actor_lod.refresh()
	expect(not world.guard_visual.visible and guard_entry["proxy"].visible,"Distant actor switches to one shared low-poly proxy")
	world.player.position = guard_at+Vector3(0,0,60)
	world.actor_lod.refresh()
	expect(not world.guard_visual.visible and not guard_entry["proxy"].visible,"Actor beyond quality visibility range is culled")
	world.player.position = guard_at+Vector3(0,0,18)
	world.actor_lod.refresh()
	var simplified: bool = not world.guard_visual.visible and guard_entry["proxy"].visible
	GraphicsManager.set_quality(2)
	world.actor_lod.refresh()
	expect(simplified and world.guard_visual.visible,"Low quality simplifies a mid-distance actor that medium quality keeps detailed")
	GraphicsManager.set_quality(0)
	expect(world.actor_lod.entries.size()==6 and world.actor_lod.entries.all(func(entry: Dictionary) -> bool: return entry["proxy"].mesh==world.actor_lod.capsule),"Actor proxy meshes are shared and count is bounded")
	var node_count := get_tree().get_node_count()
	for i in range(20): world.harvest_feedback.harvest("ore",Vector3(8,0,20),{"stone":1})
	expect(get_tree().get_node_count()==node_count and world.harvest_feedback.marks.size()==4 and world.harvest_feedback.sounds.size()==2,"Repeated effects reuse fixed pools without allocating nodes")
	expect(world.buildings.placement_shapes.size()==3,"Preview collision shapes are cached rather than recreated every update")
	InventorySystem.restore({"wood":100,"stone":100})
	world.player.position = Vector3(8.5,0.05,43)
	expect(world.buildings.place("wall",Vector3(8.5,0,47),0),"Camera fixture constructs a real wall")
	world.player.position = Vector3(8.5,0.05,45.5)
	world.player.rig.yaw = 0
	world.player.rig.pitch = 0
	await ticks(12)
	expect(world.player.rig.arm.get_hit_length()<1.5 and world.player.rig.camera.global_position.z<46.9,"Existing camera spring arm also prevents passing through player-built walls")
	world.buildings.restore({})
	var made := 0
	for z in range(56,74,3):
		for x in range(10,28,3):
			if made>=24: break
			world.player.position = Vector3(x,0.05,z-2.5)
			await ticks(1)
			if world.buildings.place("campfire",Vector3(x,TerrainBuilder.height_at(x,z),z),0): made += 1
		if made>=24: break
	expect(made==24,"Stress fixture constructs the actual maximum of 24 valid campfires")
	var inventory := InventorySystem.snapshot()
	expect(not world.buildings.place("campfire",Vector3(29,0,70),0) and InventorySystem.snapshot()==inventory,"Structure limit prevents extra allocation and material loss")
	GraphicsManager.set_quality(4)
	world.player.position = Vector3(18,0.05,62)
	world.buildings._update_visibility()
	var lights := 0
	for root in world.buildings.nodes.values():
		if root.get_node("FireLight").visible: lights += 1
	expect(lights<=2,"Maximum world still enables at most two campfire point lights")
	GraphicsManager.set_quality(0)
	world.buildings._update_visibility()
	lights = 0
	for root in world.buildings.nodes.values():
		if root.get_node("FireLight").visible: lights += 1
	expect(lights==0,"Low quality retains emissive fires without dynamic fire lights")
	world.player.position = Vector3(18,0.05,95)
	world.buildings._update_visibility()
	var first: Node3D = world.buildings.nodes[world.buildings.records[0]["id"]]
	expect(not first.get_node("Detail").visible and first.get_node("FarProxy").visible,"Distant structure uses a simple visual while preserving collision")
	world.player.position = Vector3(-90,0.05,-90)
	world.buildings._update_visibility()
	expect(not first.visible,"Out-of-range built structures stop submitting geometry")
	world.clock.restore({"hour":23.0,"weather_index":2,"weather_left":240.0})
	GraphicsManager.set_quality(4)
	expect(world.clock.rain.amount<=24 and not world.clock.headlamp.shadow_enabled,"Weather and night-light budgets stay capped in highest quality")
	GraphicsManager.set_quality(0)
	expect(not world.clock.rain.emitting,"Weather particle effects remain disabled on the lowest tier")
	var depth_ok := true
	for label in world.find_children("*","Label3D",true,false): depth_ok = depth_ok and not label.no_depth_test
	expect(depth_ok,"World labels obey depth testing rather than showing through buildings")
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(world.create_snapshot()))),"Maximum construction stress state remains saveable")
	print("RESULT | ",checks," mobile-budget/physics checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
