# 第二阶段第一批 · 实际测试结果

2026-10-15 / Godot 4.6.3.stable.official.7d41c59c4。无 Android / iPhone 真机；未声称手机安装、Safari 真机或 30 / 60 FPS 通过。

| 套件 | 通过 | 失败 | 原始记录 |
|---|---:|---:|---|
| 生存状态 | 17 | 0 | logs/phase2-batch1/SurvivalStateTests.log |
| 丧尸 AI（含真实物理追逐） | 20 | 0 | logs/phase2-batch1/ZombieCombatTests.log |
| 采集 / 保存 / 使用 / 旧档迁移 | 40 | 0 | logs/phase2-batch1/BatchOneTests.log |
| 原玩法回归 | 53 | 0 | logs/phase2-batch1/TestRunner.log |
| 原触控 / 相机回归 | 33 | 0 | logs/phase2-batch1/TouchInputTests.log |
| 原浏览器流程 | 14 | 0 | browser-results/results.json |
| Safari 输入专项（Chromium 模拟） | 21 | 0 | safari-results/results.json |
| 新增真实浏览器生存 / 采集 / 攻击 / 读档 | 18 | 0 | batch-one-browser-results/results.json |

最终引擎五套件合计 **163 项通过**；浏览器共 **53 项通过**。14 + 21 项在本批初版 Web 上执行，之后追加了 AI 网格终点修复和旧档附加字段校验，触控代码不变；修复后完整重跑了上述 163 项引擎检查与 18 项新浏览器流程。未把先前浏览器输入记录冒称为真实 Safari 或真机测试。

## 实际执行的构建

- Android Debug APK：versionCode=2 / versionName=0.2.0，包名 org.lastdawn.tenstates，arm64-v8a，minSdk 24 / targetSdk 36。已执行 Godot 导出、模板图标修补、apksigner v2 / v3 与 zipalign 16 KiB 校验；新旧签名证书一致。日志位于 logs/phase2-batch1/android-*.log。实际安装与覆盖升级待真机。
- Web：Godot 原生 Compatibility / WebGL2 单线程导出，随后 export/prepare_web.py 打包。原 WASM 37,700,666 字节，gzip 9,382,282 字节；没有替换引擎。日志位于 logs/phase2-batch1/web-*.log。
- 云端真实 WebGL 使用 Linux Chromium / SwiftShader，合成 CDP 多指及真实 Canvas UI 点击，没有键盘完成新流程，也没有向游戏暴露写入型调试命令。新流程使用 640×360 CSS 视口以控制软件渲染开销；原浏览器与 Safari 专项还覆盖宽屏、竖屏与 DPR 1 / 3。

## 修复前后证据

实际浏览器发现感染者只追近、不扣血。随后物理复现：玩家 (-2.02,0.05,-17.31)，感染者停在 (-2.0,0.000822,-18.99998)，生命仍为 100；约 1.69 米间隙超过攻击范围。近身接近修复后同一物理测试生命降为 76，攻击按前摇和冷却生效。记录见 ai-endpoint-before.log 和 ZombieCombatTests.log。新增浏览器最终也观察到实际伤害。

脚本 / 存档检查验证了 JSON 数字版本兼容、非法 / 非有限数据拒绝、schema 1 迁移、资源余量和碰撞恢复、消耗品精确扣除、失能恢复、攻击不穿墙、安全区免受感染者攻击、声音池有界 / 过期、远距休眠和相机触摸保护。

Dummy 无界面渲染器的 MultiMesh 读回恒为单位变换，不能用于证明模型隐藏。最终浏览器在实际 WebGL 中读回采尽树木的缩小变换，并验证碰撞关闭；矿石隐藏和保存恢复也通过实际点击流程确认。

## 可重跑命令

```sh
bash tests/run_batch_one.sh
bash export/build.sh
python3 -m http.server 8770 --bind 127.0.0.1 --directory export/web-static
# 在另一终端，按顺序执行，避免多个软件 GPU 浏览器争用 CPU：
python3 tests/browser_smoke.py http://127.0.0.1:8770
python3 tests/safari_touch_browser.py http://127.0.0.1:8770
python3 tests/batch_one_browser.py http://127.0.0.1:8770
```

玩家直接用手机打开交付网址或安装 APK，无须运行开发命令。详细修改、默认数值、剩余问题、真机步骤见 [第一批报告](../docs/PHASE2_BATCH1.md)。
