extends Node
var checks := 0
var failures := 0
func expect(value: bool, message: String) -> void:
	checks += 1
	if value:
		print("PASS | ", message)
	else:
		failures += 1
		push_error("FAIL | " + message)

func _ready() -> void:
	call_deferred("run")

func run() -> void:
	await get_tree().process_frame
	var original := GraphicsManager.snapshot()
	for cap in GraphicsManager.FRAME_RATES:
		GraphicsManager.set_frame_rate(cap)
		expect(Engine.max_fps == cap and GraphicsManager.target_fps == cap, "Selected %d applies to Engine.max_fps" % cap)
	GraphicsManager.set_frame_rate(120)
	for quality in range(5):
		GraphicsManager.set_quality(quality)
		expect(Engine.max_fps == 120, "Quality %d preserves the 120 cap" % quality)
	GraphicsManager.target_fps = 30
	expect(GraphicsManager.load_settings() and GraphicsManager.target_fps == 120, "Persisted 120 survives settings reload")
	GraphicsManager.apply()
	expect(Engine.max_fps == 120, "Startup apply retains loaded 120")
	var saved := GraphicsManager.snapshot()
	GraphicsManager.set_frame_rate(60)
	GraphicsManager.restore(saved)
	expect(Engine.max_fps == 120, "World graphics restore accepts JSON-compatible 120")
	GraphicsManager.restore({"target_fps":120.0})
	expect(Engine.max_fps == 120, "JSON float 120 restores without a 60 fallback")
	GraphicsManager.set_frame_rate(77)
	expect(Engine.max_fps == 120, "Invalid frame cap is ignored")
	expect(Engine.physics_ticks_per_second == 60, "Physics remains independent at 60 Hz")
	var frames := FrameTimeWindow.new()
	expect(frames.snapshot()["samples"] == 0, "No frames means unavailable, never the selected target")
	frames.push_ms(0); frames.push_ms(-2); frames.push_ms(NAN); frames.push_ms(INF)
	expect(frames.snapshot()["samples"] == 0, "Invalid intervals are rejected")
	for i in range(240):
		frames.push_ms(1000.0 / 60)
	var stats := frames.snapshot()
	expect(is_equal_approx(stats["average_fps"], 60), "Measured interval mean reports actual 60 even when target is 120")
	expect(is_equal_approx(stats["mean_ms"], 1000.0 / 60), "Mean frame time uses milliseconds")
	expect(stats["ready"] and is_equal_approx(stats["low_1_percent"], 60), "Constant-frame 1% Low is correct")
	frames.clear()
	for i in range(198): frames.push_ms(20)
	frames.push_ms(100); frames.push_ms(200)
	stats = frames.snapshot()
	expect(is_equal_approx(stats["low_1_percent"], 1000.0 / 150), "1% Low inverts the mean of the slowest ceil(1%) intervals")
	expect(is_equal_approx(stats["average_fps"], 200000.0 / 4260), "Average FPS is interval-weighted, not an average of instantaneous FPS")
	frames.clear(); frames.push_ms(16)
	expect(not frames.snapshot()["ready"], "Warm-up never presents a bogus 1% Low")
	for i in range(4000): frames.push_ms(1)
	expect(frames.intervals.size() <= 2400, "High-refresh sample storage is bounded")
	frames.clear()
	for i in range(1000): frames.push_ms(20)
	expect(frames.total_ms <= 10000.01 and frames.snapshot()["samples"] == 500, "Window retains about ten seconds")
	PerformanceDiagnostics.frames.push_ms(20)
	PerformanceDiagnostics.previous_us = 123
	PerformanceDiagnostics._notification(NOTIFICATION_APPLICATION_FOCUS_OUT)
	expect(PerformanceDiagnostics.suspended and PerformanceDiagnostics.previous_us == 0 and PerformanceDiagnostics.frames.intervals.is_empty(), "Focus loss clears frame baselines and suspends capture")
	PerformanceDiagnostics._notification(NOTIFICATION_APPLICATION_FOCUS_IN)
	expect(not PerformanceDiagnostics.suspended and PerformanceDiagnostics.previous_us == 0, "Focus return starts a fresh baseline")
	PerformanceDiagnostics.last_gameplay = {"samples":999}
	GraphicsManager.set_frame_rate(60)
	expect(PerformanceDiagnostics.last_gameplay.is_empty(), "Changing settings invalidates stale gameplay comparison")
	PerformanceDiagnostics._refresh()
	expect(PerformanceDiagnostics.report["display_refresh_hz"] < 0, "Headless display does not invent physical refresh information")
	expect(PerformanceDiagnostics.report["engine_actual_fps"] == Engine.get_frames_per_second(), "Engine readout uses actual Engine FPS")
	expect(not PerformanceDiagnostics.report["gpu_time_available"], "No GPU-only timing claim without a reliable timer")
	expect("平均" in PerformanceDiagnostics.summary_text() or "等待渲染采样" in PerformanceDiagnostics.summary_text(), "Performance summary can render before the first GPU frame")
	var font = load("res://assets/fonts/LastDawnSans.ttf")
	var missing := ""
	for script_path in ["res://systems/PerformanceDiagnostics.gd", "res://ui/SurvivalHUD.gd", "res://export/performance_probe.js"]:
		for character in FileAccess.get_file_as_string(script_path):
			var codepoint: int = character.unicode_at(0)
			if codepoint >= 0x3400 and codepoint <= 0x9fff and not font.has_char(codepoint):
				missing += character
	expect(missing.is_empty(), "All diagnostic and settings Chinese glyphs exist in the embedded font: " + missing)
	GraphicsManager.restore(original)
	print("RESULT | ", checks, " checks | ", failures, " failures")
	get_tree().quit(1 if failures else 0)
