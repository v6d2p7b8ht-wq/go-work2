extends Node
var world: WorldManager
var rows: Array[Dictionary] = []
func _ready() -> void:
	call_deferred("run")
func raw(path: String, text: String) -> void:
	var f := FileAccess.open(path,FileAccess.WRITE)
	f.store_string(text)
	f.close()
func record(label: String, data: Dictionary) -> void:
	rows.append({"case":label,"accepted":SaveManager.valid_snapshot(data)})
	print("PROBE | ",label," accepted=",rows[-1]["accepted"])
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	for node in [world.player,world.family.member]: node.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	world.set_process(false)
	world.clock.set_process(false)
	world.trader.set_process(false)
	world.family.set_process(false)
	InventorySystem.restore({"wood":40,"stone":30,"ore":10,"food":3,"water":4})
	world.player.position = Vector3(9,0.05,40)
	await get_tree().physics_frame
	assert(world.buildings.place("campfire",Vector3(8.5,TerrainBuilder.height_at(8.5,36),36),0))
	world.player.position = Vector3(20,0.05,25)
	assert(world.trader.trade("electronics"))
	world.family.stage = "evacuated"
	world.family.reward_claimed = true
	world.family.member.position = Vector3(20,0.05,35)
	var complete := world.create_snapshot()
	record("complete-schema3",complete)
	var minimal := complete.duplicate(true)
	minimal["phase2"] = {"content_revision":1}
	record("phase2-content-revision-only",minimal)
	for module in complete["phase2"]:
		var data := complete.duplicate(true)
		data["phase2"].erase(module)
		record("missing.phase2."+module,data)
	for module in ["buildings","trader","environment","family"]:
		for field in complete["phase2"][module]:
			var data := complete.duplicate(true)
			data["phase2"][module].erase(field)
			record("missing.phase2."+module+"."+field,data)
	for field in complete["phase2"]["buildings"]["records"][0]:
		var data := complete.duplicate(true)
		data["phase2"]["buildings"]["records"][0].erase(field)
		record("missing.building-record."+field,data)
	for id in complete["phase2"]["trader"]["stock"]:
		var data := complete.duplicate(true)
		data["phase2"]["trader"]["stock"].erase(id)
		record("missing.trader-stock."+id,data)
	for field in complete:
		var data := complete.duplicate(true)
		data.erase(field)
		record("missing.root."+field,data)
	for module in ["settings","survival","resources"]:
		for field in complete[module]:
			var data := complete.duplicate(true)
			data[module].erase(field)
			record("missing."+module+"."+field,data)
	for field in complete["survival"]["settings"]:
		var data := complete.duplicate(true)
		data["survival"]["settings"].erase(field)
		record("missing.survival.settings."+field,data)
	for field in complete["infected"][0]:
		var data := complete.duplicate(true)
		data["infected"][0].erase(field)
		record("missing.infected-record."+field,data)
	raw(SaveManager.SAVE_PATH,JSON.stringify(minimal))
	var before := {"structures":world.buildings.records.size(),"family_stage":world.family.stage,"claimed":world.family.reward_claimed,"trades":world.trader.trades}
	var loaded := SaveManager.load_world(world)
	var after := {"structures":world.buildings.records.size(),"family_stage":world.family.stage,"claimed":world.family.reward_claimed,"trades":world.trader.trades}
	var observation := {"engine":Engine.get_version_info()["string"],"user_dir":OS.get_user_data_dir(),"checks":rows,"complete_fixture":complete,"minimal_load_succeeded":loaded,"before":before,"after":after,"error":SaveManager.last_error}
	raw("user://probe.json",JSON.stringify(observation,"  "))
	print("LOSS | loaded=",loaded," before=",before," after=",after)
	print("PROBE_REPORT | ",ProjectSettings.globalize_path("user://probe.json"))
	get_tree().quit(0)
