# 0.2.2 / v0.2-stable 实际测试

日期：2026-10-15。Godot 4.6.3 stable；Linux 无界面逻辑 / 物理；Chromium 154 / SwiftShader 软件 WebGL2、合成多点触摸。**没有 Android / iPhone 真机或 Safari 运行环境**。

| 套件 | 实际结果 |
| --- | --- |
| SurvivalStateTests | 17 通过 / 0 失败 |
| ZombieCombatTests | 20 通过 / 0 失败 |
| BatchOneTests | 40 通过 / 0 失败 |
| TestRunner | 53 通过 / 0 失败 |
| TouchInputTests | 33 通过 / 0 失败 |
| PerformanceTests | 34 通过 / 0 失败 |
| QualityRegressionTests | 24 通过 / 0 失败 |
| CollisionQualityTests | 29 通过 / 0 失败 |
| 合计引擎 | 250 通过 / 0 失败 |
| 输入 / 相机保护静态检查 | 9 通过 / 0 失败 |
| GDScript 编辑器 LSP | 35 文件，0 错误 / 0 警告（原 8 警告已修） |
| 新 Web 画质 / 性能 / 存储故障注入 | 22 通过 / 0 失败 |
| 原 Web 基础操作 / IndexedDB | 14 通过 / 0 失败 |
| Safari 类输入专项，Chromium 模拟 | 21 通过 / 0 失败 |
| 帧率诊断专项 | 23 通过 / 0 失败 |
| 第二阶段第一批真实 Web 玩法 | 18 通过 / 0 失败 |
| 合计浏览器 | 98 通过 / 0 失败 |

同一套新增 24 项质量测试在原 0.2.1 ZIP 上为 22 失败 / 2 通过；修复后 24 通过。对照使用最终相同夹具，包含未来存档 / 备份保护、大小 / 非法数据、物品上限、矿石双产出、墙边导航与失能菜单。没有把这些边界案例声称为手机实际发生过的所有故障。

## 实际浏览器覆盖

从实际新导出启动，以真实 GUI / 触摸操作验证五档视口比例与帧率上限、120 切画质不被覆盖、60 模式、刷新后 IndexedDB 保存的目标与游戏状态、生存滑块 / 食品 / 饮水、树矿采尽与 WebGL MultiMesh / 碰撞读回、感染者追逐攻击和安全区恢复。

输入专项复验 DPR 1 / 3、左右 / 上下滑、快速连续滑、摇杆与镜头同时使用、交替抬指、UI 阻断、取消、合成 viewport / orientation / focus / visibility 生命周期、上下反转。它只证明 Chromium 的导出事件通路，**不证明 Safari 地址栏、系统返回或 App 切换已在 iPhone 通过**。

对 IndexedDB.open 注入 SecurityError，Godot 正常启动但 userfs 持久性标为 false；点击保存明确返回存储不可用，刷新不出现虚假的继续存档。正常 IndexedDB 路径另经完整保存 / 重载验证。故障注入不代表具体 iOS 私密浏览版本行为；异步写盘被系统强杀仍不可保证。

## 性能、内存和资源加载

当前极低 / 目标 120、640×360 CSS 视口下连续约 20 秒的 8 个低频样本：真实提交窗口均值 **8.19–8.48 FPS**，平均间隔 **117.90–122.14 ms**，Engine 实测约 8 FPS；每窗不足 100 个间隔时 1% Low 正确显示采样中，没有当成测得 0。

实际 draw call 146–146，Godot 节点 1642–1642，纹理显存估算约 10.08 MiB；5 次菜单开关后节点数未持续增长。JS 堆读数 11.41–12.27 MiB，**不包含完整 WASM / GPU / 浏览器进程内存**，不能据短样本断言无泄漏。Release 的原生分配器计数不可用，显示 -1 / 不可用。

独立不加载 Godot 的轻量页 rAF 平均 60.00 回调/秒。游戏与轻量页差异只描述此软件渲染环境，不足以证明用户 iPhone GPU 不足，也未确认其 Safari 只调度 60。当前代码上限确实为 120，屏幕真实刷新率在 Web 报未知，保留 60 稳定选项。

ResourceTiming 记录原版引擎 gzip 9,382,282 字节、PCK 513,972 字节和 JS；本地服务毫秒级加载时间不能当作手机外网首次加载时间。原 WASM 37,700,666 字节，gzip 解压逐字节一致，未更换引擎 / 重复渲染 / 伪造计数。原始样本和资源时间见 quality-results/browser/results.json、resource-loads.json。

## 构建与包检查

Android 实际导出：org.lastdawn.tenstates，versionCode 4 / versionName 0.2.2，ARM64，minSdk 24，Mobile 渲染器；apksigner v2 / v3 验证通过、zipalign 16 KiB 校验通过，与 0.2.1 公共调试证书一致。没有连接 ADB 设备，不能声称安装或 Vulkan 实机运行通过。

Web 实际导出：Compatibility / WebGL2，单线程，不依赖 SharedArrayBuffer；静态包在本地真实启动。Android 与 Web 保留平台渲染覆盖。源码高置信密钥模式扫描未命中，未打包 .git / .godot 缓存 / 私钥 / 环境文件；标准 Godot debug 密码 android 是公开构建约定，不是发布私钥。

## 未执行与复现

待手机：Safari 真正多点触控 / 地址栏 / 系统手势 / App 返回，ProMotion / 低电量 / 限制帧速率，真实 Android Vulkan / 90 / 120，30–60 FPS、温升、长时间内存 / 异步存储强杀、全图视觉巡检及弱网首载。质量门槛详见 docs/QUALITY_AUDIT.md；不满足完整第二阶段结束条件。

开发环境可运行 bash tests/run_quality_audit.sh；实际导出用 bash export/build.sh。本地静态服务启动后依次运行 tests/quality_browser.py、browser_smoke.py、safari_touch_browser.py、fps_diagnostics_browser.py、batch_one_browser.py，参数为同一服务 URL，避免软件 GPU 并发争抢。手机玩家无需执行终端命令。

交付工程 ZIP 独立解压后，250 项引擎与 9 项静态保护全部再次通过。全新缓存初次编辑器导入输出字体缓存尚不存在的 4 条加载消息，但自行完成字体导入；第二次导入无错误，运行中的字体覆盖测试通过。首次与二次导入日志均保留为 source-first-import.log / source-second-import.log，这项 P3 未隐去。

所有测试结果指本次最终运行；历史报告与旧版本日志保留，不把旧通过数当作新测试。单独 --script 缺少 autoload 的运行方式不作为当前项目语法检测结论。
