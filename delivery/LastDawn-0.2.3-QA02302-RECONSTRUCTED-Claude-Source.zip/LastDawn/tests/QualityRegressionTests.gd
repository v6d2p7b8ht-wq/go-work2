extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ", label)
	if not ok: failures += 1
func write_raw(path: String, data: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(data)
	f.close()
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.player.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var saved := world.create_snapshot()
	var future := saved.duplicate(true)
	future["version"] = SaveManager.VERSION + 1
	var future_text := JSON.stringify(future)
	write_raw(SaveManager.SAVE_PATH, future_text)
	write_raw(SaveManager.SAVE_PATH + ".bak", JSON.stringify(saved))
	var wrote := SaveManager.write_snapshot(saved)
	expect(not wrote and FileAccess.get_file_as_string(SaveManager.SAVE_PATH) == future_text, "SAVE-01: older client cannot overwrite a newer-schema primary")
	expect(SaveManager.read_snapshot().is_empty(), "SAVE-01: newer primary is not silently replaced by an older backup on read")
	write_raw(SaveManager.SAVE_PATH, JSON.stringify(saved))
	write_raw(SaveManager.SAVE_PATH + ".bak", future_text)
	expect(not SaveManager.write_snapshot(saved) and FileAccess.get_file_as_string(SaveManager.SAVE_PATH + ".bak") == future_text, "SAVE-01: newer backup is protected too")
	var oversized := "x".repeat(1024 * 1024 + 1)
	write_raw(SaveManager.SAVE_PATH, oversized)
	write_raw(SaveManager.SAVE_PATH + ".bak", JSON.stringify(saved))
	expect(not SaveManager.write_snapshot(saved) and FileAccess.get_file_as_string(SaveManager.SAVE_PATH).length() == oversized.length(), "SAVE-03: oversized unknown existing file cannot be overwritten")
	write_raw(SaveManager.SAVE_PATH, JSON.stringify(saved))
	var giant := saved.duplicate(true)
	giant["extra"] = oversized
	expect(not SaveManager.write_snapshot(giant) and SaveManager.read_snapshot() == JSON.parse_string(JSON.stringify(saved)), "SAVE-03: oversized outgoing snapshot cannot create an unreadable save")
	# The following fixture belongs to this isolated test profile, never a player's save.
	write_raw(SaveManager.SAVE_PATH, "{broken")
	write_raw(SaveManager.SAVE_PATH + ".bak", JSON.stringify(saved))
	expect(SaveManager.write_snapshot(saved), "Recovered session can write a valid replacement primary")
	var backup_data = JSON.parse_string(FileAccess.get_file_as_string(SaveManager.SAVE_PATH + ".bak"))
	expect(backup_data is Dictionary and SaveManager.valid_snapshot(backup_data), "SAVE-02: successful recovery preserves a valid rollback backup")
	for field in ["inventory", "settings"]:
		var invalid := saved.duplicate(true)
		if field == "inventory": invalid[field]["wood"] = -1
		else: invalid[field]["target_fps"] = "bad"
		expect(not SaveManager.valid_snapshot(invalid), "Malformed persisted " + field + " rejected before mutating the world")
	for value in [0.5, INF, "bad", {"nested":1}]:
		var invalid := saved.duplicate(true)
		invalid["inventory"]["wood"] = value
		expect(not SaveManager.valid_snapshot(invalid), "Invalid inventory amount rejected: " + str(value))
	var unknown_item := saved.duplicate(true)
	unknown_item["inventory"]["future_weapon"] = 2
	expect(not SaveManager.valid_snapshot(unknown_item), "Unknown item IDs are not silently lost while accepting the same schema")
	for value in [NAN, 77, 120.5]:
		var invalid := saved.duplicate(true)
		invalid["settings"]["target_fps"] = value
		expect(not SaveManager.valid_snapshot(invalid), "Invalid persisted FPS rejected: " + str(value))
	InventorySystem.restore({"food":9999})
	expect(not InventorySystem.add_item("food", 1) and InventorySystem.items["food"] == 9999, "INV-01: saturated item insertion reports failure")
	world.player.position = Vector3(5, 0.05, 29)
	world.interact()
	expect(not world.picked.has("s01_loot_00") and InventorySystem.items["food"] == 9999, "INV-01: full inventory leaves loot in the world")
	InventorySystem.restore({"stone":9999})
	var node: Dictionary = world.resources.records["s01_ore_00"]
	world.player.position = node["at"] + Vector3(-1.8, 0.05, 0)
	world.player.stamina = 100
	world.resources.cooldown = 0
	await get_tree().physics_frame
	var harvested := world.resources.harvest(node["id"], world.player)
	expect(not harvested and node["remaining"] == 5 and world.player.stamina == 100 and InventorySystem.items["ore"] == 0, "INV-01: saturated multi-item harvest consumes neither resource nor stamina")
	var zombie := world.zombies[0]
	zombie.position = Vector3(-7.0, 0.05, -18)
	world.player.position = Vector3(-7.3, 0.05, -12)
	var route := world.navigation.path(zombie.position, world.player.position)
	expect(not route.is_empty(), "NAV-01: coarse blocked target beside supermarket still finds an approach route")
	zombie.repath_clock = 0
	zombie._think()
	zombie.set_physics_process(true)
	var before := zombie.position.distance_to(world.player.position)
	for i in range(360):
		await get_tree().physics_frame
	print("NAV PHYSICS | initial=", before, " final=", zombie.position.distance_to(world.player.position), " state=", zombie.state, " route=", zombie.route.size(), " at=", zombie.position)
	expect(zombie.position.distance_to(world.player.position) < before - 1, "NAV-01: infected physically advances toward the visible wall-side player")
	zombie.set_physics_process(false)
	world.player.survival.health = 0
	world.hud.show_incapacitated()
	world.hud.show_settings()
	world.hud.close_modal()
	await get_tree().process_frame
	expect(get_tree().paused and not world.hud.controls.enabled, "UI-01: menu navigation cannot resume an incapacitated player")
	world.player.rescue()
	world.hud.close_modal()
	expect(world.player.survival.alive() and not get_tree().paused, "Recovery still returns control normally")
	print("RESULT | ", checks, " quality checks | ", failures, " failures")
	get_tree().quit(1 if failures else 0)
