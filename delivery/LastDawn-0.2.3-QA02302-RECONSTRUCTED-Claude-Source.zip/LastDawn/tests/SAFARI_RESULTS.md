# Safari 输入修复实际测试 · 2026-10-15

环境：Godot 4.6.3.stable.official.7d41c59c4；Linux Chromium / SwiftShader 软件 WebGL2。未连接 Android / iPhone，未执行 Safari / iOS 真机测试。以下是真实执行结果。

| 检查 | 通过 | 失败 | 证据 |
|---|---:|---:|---|
| 原有 Godot 引擎集成回归 | 53 | 0 | logs/safari-engine-regression.log |
| 新增触摸 / 相机引擎断言 | 33 | 0 | logs/safari-touch-tests.log |
| 原有浏览器触屏 / 存档回归 | 14 | 0 | logs/safari-browser-regression.log、browser-results/ |
| 新增 Web 触摸专项 | 21 | 0 | safari-results/results.json、console.log、touch-debug-dpr3.png |
| 核心玩法与配置文件 SHA-256 | 17 未变 | 0 | ../docs/evidence/protected-files.json |

Web 实际重新导出成功，日志见 logs/safari-web-export.log。随后用 export/prepare_web.py 打包 gzip 静态版本；软件浏览器运行的就是此类导出包。导出日志末尾 ADB daemon 连接失败只表示没有连接安卓设备，本次未导出新 APK。

## 受控修复前后证据

旧版在 resize 后仍保留 look_touch=3；注入 relative=(900,-700) 后 Yaw 一次改变 -165.011845°，见 logs/safari-before-probe.log。新版本断言确认 resize 后 look_touch=-1，孤立拖动不能重新获得镜头；大幅 / 不连续 relative 被拒绝且随后正常手势可恢复。这是引擎事件注入，绝不代表从 iPhone 录屏提取到了此 delta。

专项浏览器以 844×390 CSS 像素、DPR=3 与 DPR=1 运行。相同 50 CSS 像素向右滑动，在两种 DPR 下得到相同约 -0.29538 rad（-16.92°）转角。DPR=3 时 Canvas backing 为 1266×585、Godot 逻辑视口为 1558×720；没有把 3 或 1.5 再乘到相机上。精确 expected / observed 位于 JSON。

其他专项涵盖：左右 / 上下方向、摇杆与镜头独立拥有、交替释放、五次连续滑动、实际更改浏览器视口后旧手指无效、VisualViewport offset 改变、orientationchange / blur / pagehide / pageshow、touchCancel、Canvas 外触摸、菜单点击、触屏切换 Invert Y，以及无 JS / GDScript 运行错误。

visualViewport 偏移与页面生命周期部分是脚本合成事件，不是 iOS 地址栏或系统 App 切换。真实 DOM touchCancel 与 CDP 多指注入也不能替代 iPhone 手感和 WebKit 行为。软件渲染观察到约 2–6 FPS，不用它推断手机帧率。

## 可重复执行（云端开发者）

```sh
bash tests/run_tests.sh
XDG_DATA_HOME=/tmp/last-dawn-safari-input-test godot --headless --rendering-method gl_compatibility --path . res://tests/TouchInputTests.tscn
godot --headless --rendering-method gl_compatibility --path . --export-release "iPhone Safari Web"
python3 export/prepare_web.py
python3 -m http.server 8770 --bind 127.0.0.1 --directory export/web-static
# 另一终端：需要 Playwright 与 /usr/bin/chromium
python3 tests/browser_smoke.py http://127.0.0.1:8770
python3 tests/safari_touch_browser.py http://127.0.0.1:8770
```

手机用户直接打开交付网址，不需要执行上述命令。十项 Safari 真机验收和已知限制见 [修复报告](../docs/SAFARI_CAMERA_FIX.md)。
