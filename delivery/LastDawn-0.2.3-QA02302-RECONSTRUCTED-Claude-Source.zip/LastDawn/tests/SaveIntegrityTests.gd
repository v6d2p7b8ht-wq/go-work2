extends Node
## QA-023-01: exercise validation AND real on-disk restore/rotation in an isolated profile.
var checks := 0
var failures := 0
var world: WorldManager
var cases: Array[Dictionary] = []
func expect(ok: bool, label: String) -> void:
	checks += 1
	cases.append({"passed":ok,"name":label})
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func raw(path: String, text: String) -> void:
	var f := FileAccess.open(path,FileAccess.WRITE)
	assert(f!=null)
	f.store_string(text)
	f.close()
func json_copy(data: Dictionary) -> Dictionary:
	return JSON.parse_string(JSON.stringify(data))
func at(data: Dictionary, path: Array) -> Variant:
	var value: Variant = data
	for key in path: value = value[key]
	return value
func changed(data: Dictionary, path: Array, value: Variant, remove: bool = false) -> Dictionary:
	var copy := data.duplicate(true)
	var parent: Variant = copy
	for index in range(path.size()-1): parent = parent[path[index]]
	if remove: parent.erase(path[-1])
	else: parent[path[-1]] = value
	return copy
func paths(value: Dictionary, prefix: Array = []) -> Array[Array]:
	var result: Array[Array] = []
	for key in value:
		var path := prefix.duplicate()
		path.append(key)
		result.append(path)
		if value[key] is Dictionary and key!="remaining": result.append_array(paths(value[key],path))
		if key=="records" or key=="infected":
			for i in range(value[key].size()):
				var entry_path := path.duplicate()
				entry_path.append(i)
				result.append_array(paths(value[key][i],entry_path))
	return result
func progress() -> Dictionary:
	var data := world.create_snapshot()
	return {"phase2":data["phase2"],"inventory":data["inventory"],"resources":data["resources"],"survival":data["survival"],"picked":data["picked"]}
func files() -> Dictionary:
	return {"primary":FileAccess.get_file_as_bytes(SaveManager.SAVE_PATH),"backup":FileAccess.get_file_as_bytes(SaveManager.SAVE_PATH+".bak")}
func freeze() -> void:
	world.set_process(false)
	world.player.set_physics_process(false)
	world.family.member.set_physics_process(false)
	world.family.set_process(false)
	world.clock.set_process(false)
	world.trader.set_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	freeze()
	InventorySystem.restore({"wood":40,"stone":30,"ore":10,"food":3,"water":4})
	for spec in [["campfire",36.0],["wall",47.0],["shelter",64.0]]:
		world.player.position = Vector3(8.5,0.05,float(spec[1])+4)
		await get_tree().physics_frame
		expect(world.buildings.place(spec[0],Vector3(8.5,TerrainBuilder.height_at(8.5,spec[1]),spec[1]),0),"Fixture actually constructs "+spec[0])
	var fire_id: String = world.buildings.records[0]["id"]
	world.buildings.toggle_fire(fire_id)
	world.player.position = Vector3(20,0.05,25)
	expect(world.trader.trade("electronics"),"Fixture actually exchanges ore for an electronic component")
	world.clock.restore({"hour":23.5,"day":4,"day_seconds":1800.0,"weather_index":2,"weather_left":100.0})
	world.family.stage = "evacuated"
	world.family.reward_claimed = true
	world.family.member.position = Vector3(20,0.05,35)
	world.resources.records["s01_tree_000"]["remaining"] = 0
	world.resources.restore(world.resources.snapshot())
	var complete := world.create_snapshot()
	expect(SaveManager.valid_snapshot(complete) and SaveManager.valid_snapshot(json_copy(complete)),"Complete live schema 3 validates in memory and after JSON number decoding")
	var required := paths(complete)
	for path in required:
		var label := str(path)
		var missing := changed(complete,path,null,true)
		expect(not SaveManager.valid_snapshot(missing),"Missing persistent field rejected: "+label)
		var wrong: Variant = "wrong-type"
		if at(complete,path) is String: wrong = 17
		expect(not SaveManager.valid_snapshot(changed(complete,path,wrong)),"Wrong field type rejected: "+label)
		if at(complete,path) is int or at(complete,path) is float:
			for nonfinite in [NAN,INF,-INF]:
				expect(not SaveManager.valid_snapshot(changed(complete,path,nonfinite)),"Nonfinite field rejected: "+label+" = "+str(nonfinite))
	for path in [["position"],["phase2","family","position"],["phase2","buildings","records",0,"position"],["infected",0,"position"],["infected",0,"last_seen"]]:
		for component in range(3):
			var vector: Array = at(complete,path).duplicate()
			vector[component] = NAN
			expect(not SaveManager.valid_snapshot(changed(complete,path,vector)),"Nonfinite transform component rejected: "+str(path)+"/"+str(component))
	var minimal := complete.duplicate(true)
	minimal["phase2"] = {"content_revision":1}
	expect(not SaveManager.valid_snapshot(minimal),"Original content_revision-only counterexample is invalid")
	var baseline := progress()
	world.restore_snapshot(minimal)
	expect(progress()==baseline,"Direct invalid restore cannot mutate any game progress")
	expect(SaveManager.write_snapshot(complete),"Complete schema 3 writes through the real file API")
	var disk := SaveManager.read_snapshot()
	expect(disk==json_copy(complete),"Complete schema 3 file reads back without synthesizing fields")
	world.restore_snapshot(disk)
	world.restore_snapshot(SaveManager.read_snapshot())
	expect(progress()==baseline and world.buildings.nodes.size()==3,"Repeated real reads retain structures, stock, items, resources and claimed quest without duplication")
	var inventory := InventorySystem.snapshot()
	expect(not world.family.claim_reward() and InventorySystem.snapshot()==inventory,"Reloaded claimed evacuation cannot grant its reward again")
	# Malformed primary must be skipped; valid backup must remain byte-for-byte on next save.
	var backup_text := JSON.stringify(complete)
	raw(SaveManager.SAVE_PATH,JSON.stringify(minimal))
	raw(SaveManager.SAVE_PATH+".bak",backup_text)
	expect(SaveManager.load_world(world) and SaveManager.last_error=="已从备份恢复" and progress()==baseline,"Incomplete schema 3 primary restores all progress from a valid backup")
	expect(SaveManager.save_world(world),"Recovered session can save a new valid primary")
	expect(FileAccess.get_file_as_string(SaveManager.SAVE_PATH+".bak")==backup_text and SaveManager.valid_snapshot(SaveManager.read_snapshot()),"Save after schema corruption does not rotate bad primary over the valid backup")
	var before := files()
	expect(not SaveManager.write_snapshot(minimal) and files()==before,"Rejected schema 3 write preserves primary and good backup bytes")
	var oversized := complete.duplicate(true)
	oversized["extra"] = "x".repeat(SaveManager.MAX_BYTES+1)
	expect(not SaveManager.write_snapshot(oversized) and files()==before,"Oversized failed write preserves both original files")
	var temporary := ProjectSettings.globalize_path(SaveManager.SAVE_PATH+".tmp")
	expect(DirAccess.make_dir_absolute(temporary)==OK,"Fixture can block only its own temporary file path")
	expect(not SaveManager.write_snapshot(complete) and files()==before,"Actual temporary-file open failure preserves primary and backup")
	DirAccess.remove_absolute(temporary)
	# A malformed primary and malformed backup must leave the live session untouched.
	raw(SaveManager.SAVE_PATH,JSON.stringify(minimal))
	raw(SaveManager.SAVE_PATH+".bak","{broken")
	expect(not SaveManager.load_world(world) and progress()==baseline,"Two unusable files reject load without changing the running session")
	# Future files in either slot are never downgraded, even when the other slot is valid.
	for slot in [SaveManager.SAVE_PATH,SaveManager.SAVE_PATH+".bak"]:
		raw(SaveManager.SAVE_PATH,backup_text)
		raw(SaveManager.SAVE_PATH+".bak",backup_text)
		var future := complete.duplicate(true)
		future["version"] = SaveManager.VERSION+1
		raw(slot,JSON.stringify(future))
		before = files()
		expect(SaveManager.read_snapshot().is_empty() and not SaveManager.write_snapshot(complete) and files()==before,"Future schema preserves both files: "+slot)
	# An earned but unclaimed full-bag reward must survive reload, then grant once when room exists.
	world.family.reward_claimed = false
	InventorySystem.restore({"wood":1200})
	expect(not world.family.claim_reward(),"Full bag leaves the earned evacuation reward pending")
	var pending := world.create_snapshot()
	raw(SaveManager.SAVE_PATH,JSON.stringify(pending))
	raw(SaveManager.SAVE_PATH+".bak",JSON.stringify(pending))
	expect(SaveManager.load_world(world) and world.family.stage=="evacuated" and not world.family.reward_claimed and InventorySystem.items["wood"]==1200,"Real pending-reward load retains task and full inventory")
	InventorySystem.remove_item("wood",100)
	expect(world.family.claim_reward() and InventorySystem.items["food"]==2 and InventorySystem.items["water"]==2,"Claiming after freeing capacity grants exactly the earned two items")
	expect(SaveManager.save_world(world) and SaveManager.load_world(world) and SaveManager.load_world(world),"Post-claim progress saves and loads twice")
	inventory = InventorySystem.snapshot()
	expect(not world.family.claim_reward() and InventorySystem.snapshot()==inventory,"Repeated post-claim loads cannot duplicate supplies")
	# Files generated by the real original schema 1/2 engines, not a version-flipped current snapshot.
	for fixture in ["v1-real-save.json","v022-real-save.json"]:
		var text := FileAccess.get_file_as_string("res://tests/fixtures/"+fixture)
		var legacy: Dictionary = JSON.parse_string(text)
		expect(SaveManager.valid_snapshot(legacy),"Real legacy fixture validates: "+fixture)
		var normalized := SaveManager.prepare_snapshot(legacy)
		expect(normalized["phase2"]==PhaseTwoSave.legacy_defaults() and not legacy.has("phase2"),"Explicit migration fills new modules without changing legacy source: "+fixture)
		raw(SaveManager.SAVE_PATH,text)
		raw(SaveManager.SAVE_PATH+".bak",text)
		expect(SaveManager.load_world(world),"Real old file loads via disk validation/migration: "+fixture)
		var counts_match := true
		for id in legacy["inventory"]: counts_match = counts_match and InventorySystem.items[id]==legacy["inventory"][id]
		expect(counts_match and world.buildings.records.is_empty() and world.family.stage=="not_started","Migration preserves actual old item counts and initializes only absent new systems: "+fixture)
		expect(SaveManager.save_world(world) and SaveManager.read_snapshot()["version"]==3 and SaveManager.valid_snapshot(SaveManager.read_snapshot()),"Next real save upgrades legacy session to complete schema 3: "+fixture)
		expect(FileAccess.get_file_as_string("res://tests/fixtures/"+fixture)==text,"Read-only legacy source fixture remains unchanged: "+fixture)
	raw("user://integrity-results.json",JSON.stringify({"checks":cases,"count":checks,"failures":failures,"user_dir":OS.get_user_data_dir(),"engine":Engine.get_version_info()["string"]},"  "))
	print("RESULT | ",checks," QA-023-01 save-integrity checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
