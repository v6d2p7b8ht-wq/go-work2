extends Node
var checks := 0
var failures := 0
func expect(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error("FAIL | " + message)
	else:
		print("PASS | ", message)
func _ready() -> void:
	var s := SurvivalSystem.new()
	add_child(s)
	s.apply_settings(SurvivalSystem.DEFAULTS, false)
	for i in range(240):
		s.step(0.25, false, false)
	expect(absf(s.hunger - 98.5) < 0.001 and absf(s.thirst - 97.3) < 0.001, "Default needs decrease by measured per-minute rates")
	s.stamina = 90
	s.step(0.25, true, false)
	expect(is_equal_approx(s.stamina, 85.25), "Sprint uses configured stamina drain")
	s.step(0.25, false, false)
	expect(is_equal_approx(s.stamina, 88.5), "Rest regenerates stamina")
	s.hunger = 0
	s.thirst = 0
	s.step(0.25, false, false)
	expect(is_equal_approx(s.health, 99.8125), "Starvation and dehydration damage combine over play time")
	expect(s.consume("food") and s.hunger == 32 and s.consume("water") and s.thirst == 45, "Food and water restore distinct needs")
	expect(not s.consume("ore"), "Nonconsumable resources cannot restore needs")
	s.hunger = 90
	s.thirst = 90
	s.health = 75
	s.step(0.25, false, true)
	expect(is_equal_approx(s.health, 75.2), "Well-fed survivor heals only in safe area")
	s.step(0.25, false, false)
	expect(is_equal_approx(s.health, 75.2), "Outside safe area health does not regenerate")
	var before := s.hunger
	s.step(3600, false, false)
	expect(before - s.hunger < 0.01, "Background-sized delta cannot replay an hour of starvation")
	s.stamina = 7
	expect(s.spend_stamina(7) and not s.spend_stamina(1) and s.stamina == 0, "Gather cost is charged once and cannot overdraft")
	var saved := s.snapshot()
	s.health = 1
	s.restore(saved)
	expect(is_equal_approx(s.health, 75.2) and s.stamina == 0, "All survival state round-trips")
	s.apply_settings({"hunger_per_minute": -4, "zombie_damage": 900, "thirst_per_minute": NAN}, true)
	expect(s.settings["hunger_per_minute"] == 0 and s.settings["zombie_damage"] == 25 and s.settings["thirst_per_minute"] == 2.7, "Settings sanitize out-of-range and nonfinite data")
	var reloaded := SurvivalSystem.new()
	add_child(reloaded)
	expect(reloaded.settings == s.settings, "Changed survival rates persist to local config")
	s.take_damage(1000)
	expect(s.health == 0 and not s.take_damage(1) and not s.spend_stamina(0) and not s.consume("food"), "Incapacitated survivor cannot act or take repeated damage")
	s.step(0.25, false, true)
	expect(s.health == 0, "Safe healing never silently revives an incapacitated survivor")
	s.recover()
	expect(s.alive() and s.health == 65 and s.hunger >= 35 and s.thirst >= 35, "Recovery supplies a playable safe return")
	s.restore({"health": "bad", "hunger": -1, "thirst": INF})
	expect(s.health == 100 and s.hunger == 0 and s.thirst == 100, "Malformed stats are finite and bounded")
	print("RESULT | %d survival checks, %d failures" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)
