extends Node
## Real engine integration tests, isolated with XDG_DATA_HOME by tests/run_tests.sh.
var failures := 0
var checks := 0
var world: WorldManager

func _ready() -> void:
	call_deferred("run")

func expect(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS | ", message)
	else:
		failures += 1
		push_error("FAIL | " + message)

func ticks(count: int) -> void:
	for i in range(count):
		await get_tree().physics_frame

func touch(index: int, at: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = at
	event.pressed = pressed
	get_viewport().push_input(event, true)

func drag(index: int, at: Vector2, relative: Vector2) -> void:
	var event := InputEventScreenDrag.new()
	event.index = index
	event.position = at
	event.relative = relative
	get_viewport().push_input(event, true)

func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().process_frame
	Engine.max_fps = 120
	expect(ProjectSettings.get_setting("rendering/renderer/rendering_method") == "mobile" and ProjectSettings.get_setting("rendering/renderer/rendering_method.web") == "gl_compatibility", "Android Mobile and Web Compatibility are separately configured")
	expect(world.builder.building_count == 8, "8 distinct buildings were generated")
	expect(world.builder.vehicle_count == 5, "5 abandoned vehicles were generated")
	expect(world.zombies.size() == 3, "3 infected agents, within the requested 2–5 budget")
	expect(world.pickups.size() == 21 and world.pickup_specs[18]["item"] == "water", "All original 18 supplies plus 3 drinking-water locations remain collectible")
	expect(world.vegetation.total_trees > 280, "Forest uses chunked MultiMesh trees")
	expect(world.batcher.instances.size() > 0, "Static objects are batched")
	var normals: PackedVector3Array = world.get_node("TerrainSurface").mesh.surface_get_arrays(0)[Mesh.ARRAY_NORMAL]
	expect(normals[0].y > 0.5, "Terrain triangle winding produces upward-facing visible surfaces")
	expect(world.hud.theme.default_font.has_char("末".unicode_at(0)), "Embedded UI font contains actual Chinese glyphs")
	expect(world.registry.data.get("states", []).size() == 10, "10-state extension data")
	expect(world.registry.data.get("infection_levels", []).size() == 5, "5 infection levels")
	expect(world.request_state("state_01") and not world.request_state("state_02"), "Only implemented state can be entered")
	expect(world.registry.publish("government_decision", {}) and not world.registry.publish("missing"), "Reserved extension boundary accepts known events")
	await ticks(100)
	expect(world.player.is_on_floor() and absf(world.player.position.y) < 0.3, "Gravity and real terrain collision settle the player")
	var start := world.player.position
	Input.action_press("move_forward")
	await ticks(60)
	Input.action_release("move_forward")
	var walk_distance := start.distance_to(world.player.position)
	expect(walk_distance > 2.6 and walk_distance < 4.5, "Third-person walking moves at world scale")
	world.player.position = start
	world.player.velocity = Vector3.ZERO
	Input.action_press("move_forward")
	Input.action_press("sprint")
	await ticks(60)
	Input.action_release("move_forward")
	Input.action_release("sprint")
	expect(start.distance_to(world.player.position) > walk_distance * 1.4 and world.player.stamina < 95, "Sprinting is faster and consumes stamina")
	world.player.position = start
	world.player.velocity = Vector3.ZERO
	await ticks(12)
	world.hud.controls.jump_pending = true
	await ticks(20)
	expect(world.player.position.y > 0.5, "Jump produces airborne movement")
	await ticks(80)
	expect(world.player.is_on_floor(), "Jump lands on the terrain")
	world.player.position = Vector3(-6, 0.08, -7)
	world.player.velocity = Vector3.ZERO
	Input.action_press("move_left")
	await ticks(100)
	Input.action_release("move_left")
	expect(world.player.position.x < -10.0, "Player can physically enter the supermarket through its doorway")
	world.player.position = Vector3(-6, 0.08, -12)
	world.player.velocity = Vector3.ZERO
	Input.action_press("move_left")
	await ticks(100)
	Input.action_release("move_left")
	expect(world.player.position.x > -8.65, "Supermarket side panels have solid collision")
	world.player.rescue()
	var controls := world.hud.controls
	touch(2, controls.joystick_center, true)
	await get_tree().process_frame
	drag(2, controls.joystick_center + Vector2(0, -65), Vector2(0, -65))
	await get_tree().process_frame
	touch(7, Vector2(800, 330), true)
	await get_tree().process_frame
	var yaw := world.player.rig.yaw
	drag(7, Vector2(850, 350), Vector2(50, 20))
	touch(11, controls.jump_center, true)
	await get_tree().process_frame
	expect(controls.joystick_touch == 2 and controls.look_touch == 7 and controls.stick.y < -0.8, "Indexed joystick/view/action multi-touch ownership")
	expect(not is_equal_approx(world.player.rig.yaw, yaw), "Right-side drag rotates the camera")
	touch(11, controls.jump_center, false)
	touch(7, Vector2(850, 350), false)
	await get_tree().process_frame
	expect(controls.joystick_touch == 2 and controls.stick.y < -0.8, "Releasing action and view does not release the joystick")
	controls.reset_touches()
	expect(controls.joystick_touch == -1 and controls.look_touch == -1 and controls.stick == Vector2.ZERO, "Focus-loss reset clears active fingers")
	world.player.rig.orbit(Vector2(100000, -100000))
	world.player.rig.zoom(999)
	expect(world.player.rig.pitch <= 0.34 and world.player.rig.distance == 10, "Camera pitch and distance are bounded")
	world.player.rig.yaw = 0
	world.player.rig.pitch = -0.27
	world.player.position = Vector3(62, TerrainBuilder.height_at(62, 35) + 2, 35)
	world.player.velocity = Vector3.ZERO
	await ticks(110)
	expect(world.player.is_on_floor() and absf(world.player.position.y - TerrainBuilder.height_at(62, 35)) < 0.5, "Forest hillside matches height-map collision")
	InventorySystem.restore({})
	expect(not InventorySystem.add_item("unknown") and not InventorySystem.add_item("food", -1), "Inventory rejects unknown and negative items")
	world.player.position = Vector3(5, 0.1, 29)
	world.player.velocity = Vector3.ZERO
	world.interact()
	expect(InventorySystem.items["food"] == 1 and world.picked.size() == 1 and world.pickups.size() == 20, "Nearby food is picked up once and removed")
	world.interact()
	expect(InventorySystem.items["food"] == 1, "The same pickup cannot be duplicated")
	world.hud.show_inventory()
	expect(get_tree().paused and not controls.enabled and world.hud.current_modal == "inventory", "Inventory modal pauses the simulation and movement")
	world.hud.close_modal()
	world.player.position = Vector3(17, 0.1, 32)
	world.interact()
	expect(world.talked_to_npc and world.hud.current_modal == "npc", "Safe-zone NPC dialogue works")
	world.hud.close_modal()
	GraphicsManager.set_quality(0)
	await get_tree().process_frame
	expect(not world.atmosphere.sun.shadow_enabled and not world.atmosphere.dust.emitting, "Very-low preset disables shadows and particles")
	var chunk: Dictionary = world.vegetation.tree_chunks[0]
	expect(chunk["crowns"].multimesh.visible_instance_count < chunk["crowns"].multimesh.instance_count, "Vegetation density actually changes")
	GraphicsManager.set_quality(4)
	GraphicsManager.set_frame_rate(90)
	expect(world.atmosphere.sun.shadow_enabled and world.atmosphere.dust.amount == 40 and is_equal_approx(get_viewport().scaling_3d_scale, 1.1), "Extreme preset applies scale, shadow and particle settings")
	GraphicsManager.quality = 0
	GraphicsManager.target_fps = 30
	GraphicsManager.load_settings()
	expect(GraphicsManager.quality == 4 and GraphicsManager.target_fps == 90, "Graphics configuration survives a disk reload")
	world.player.position = Vector3(6, 0.1, 28)
	world.player.rig.distance = 7.2
	expect(SaveManager.save_world(world), "Real save file is written")
	var saved := SaveManager.read_snapshot()
	expect(SaveManager.valid_snapshot(saved), "Written save passes schema validation")
	InventorySystem.restore({"food": 0})
	world.player.position = Vector3(1, 1, 1)
	world.picked.clear()
	expect(SaveManager.load_world(world), "Real save file loads")
	expect(InventorySystem.items["food"] == 1 and world.picked.size() == 1 and world.pickups.size() == 20, "Inventory and collected IDs round-trip without respawning loot")
	expect(world.player.position.distance_to(Vector3(6, 0.1, 28)) < 0.01 and is_equal_approx(world.player.rig.distance, 7.2) and world.talked_to_npc, "Position, camera and NPC progress round-trip")
	var invalid := saved.duplicate(true)
	invalid["version"] = 99
	expect(not SaveManager.valid_snapshot(invalid), "Future save schemas are rejected")
	invalid = saved.duplicate(true)
	invalid["position"] = ["nan", 0, 0]
	expect(not SaveManager.valid_snapshot(invalid), "Non-numeric position is rejected")
	invalid["position"] = [99999, 0, 0]
	expect(not SaveManager.valid_snapshot(invalid), "Out-of-map position is rejected")
	expect(SaveManager.write_snapshot(saved), "A second atomic save retains the previous backup")
	var broken := FileAccess.open(SaveManager.SAVE_PATH, FileAccess.WRITE)
	broken.store_string("{broken-json")
	broken.close()
	expect(not SaveManager.read_snapshot().is_empty() and SaveManager.last_error.contains("备份"), "Corrupt primary save recovers from backup")
	InventorySystem.restore({"wood": "bad", "stone": -8, "food": 100000})
	expect(InventorySystem.items["wood"] == 0 and InventorySystem.items["stone"] == 0 and InventorySystem.items["food"] == 9999, "Inventory data is bounded and sanitized")
	var path := world.navigation.path(Vector3(-5, 0, -20), Vector3(-34, 0, -8))
	var clear := path.size() > 4
	for point in path:
		if world.navigation.grid.is_point_solid(Vector2i(roundi(point.x / 2), roundi(point.z / 2))):
			clear = false
	expect(clear, "A* route avoids actual building obstacles")
	expect(world.navigation.path(Vector3(-6, 0, -7), Vector3(-15, 0, -7)).size() > 0, "Shared navigation grid retains the supermarket entrance")
	var zombie := world.zombies[0]
	zombie.position = Vector3(-3, 0, -25)
	zombie.state = ZombieAI.State.PATROL
	world.player.position = Vector3(-2, 0, -20)
	zombie._think()
	expect(zombie.state == ZombieAI.State.CHASE, "Infected detects an unobstructed nearby player")
	world.player.position = Vector3(12, 0, 26)
	zombie._think()
	expect(zombie.state == ZombieAI.State.INVESTIGATE, "Infected stops chasing a player inside the safe zone")
	world.player.position = Vector3(80, 20, 80)
	zombie._think()
	expect(zombie.state == ZombieAI.State.SLEEP and zombie.velocity == Vector3.ZERO, "Far infected sleeps instead of pathfinding")
	zombie.position = Vector3(-7, 0, -12)
	zombie.state = ZombieAI.State.PATROL
	world.player.position = Vector3(-14, 0, -12)
	zombie._think()
	expect(zombie.state != ZombieAI.State.CHASE, "Opaque supermarket wall blocks infected sight")
	world.player.rescue()
	zombie.position = zombie.home
	var count := zombie.decision_count
	await ticks(60)
	expect(zombie.decision_count - count <= 6, "AI decisions run at 4 Hz, below the physics frequency")
	print("RESULT | %d checks, %d failures" % [checks, failures])
	get_tree().paused = false
	world.ready_for_saves = false
	world.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	get_tree().quit(0 if failures == 0 else 1)
