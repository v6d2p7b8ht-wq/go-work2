extends Node
## Deterministic input/camera regressions; these are not physical iPhone tests.
var controls: MobileControls
var rig: CameraController
var checks := 0
var failures := 0

func _ready() -> void:
	call_deferred("run")

func expect(value: bool, label: String) -> void:
	checks += 1
	if value:
		print("PASS | ", label)
	else:
		failures += 1
		push_error("FAIL | " + label)

func press(index: int, at: Vector2, down: bool = true, canceled: bool = false) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = at
	event.pressed = down
	event.canceled = canceled
	get_viewport().push_input(event, true)

func drag(index: int, at: Vector2, relative: Vector2) -> void:
	var event := InputEventScreenDrag.new()
	event.index = index
	event.position = at
	event.relative = relative
	get_viewport().push_input(event, true)

func fresh() -> void:
	controls.reset_touches()
	rig.yaw = 0
	rig.pitch = -0.27
	rig.invert_y = false

func run() -> void:
	controls = MobileControls.new()
	add_child(controls)
	rig = CameraController.new()
	add_child(rig)
	controls.look_changed.connect(rig.orbit)
	await get_tree().process_frame
	GraphicsManager.sensitivity = 0.0032
	var manager := controls.touch_manager
	fresh()
	press(3, Vector2(800, 330))
	drag(3, Vector2(900, 330), Vector2(100, 0))
	expect(is_equal_approx(rig.yaw, -0.32), "Right swipe integrates exactly once in radians per viewport pixel")
	drag(3, Vector2(800, 330), Vector2(-100, 0))
	expect(is_zero_approx(rig.yaw), "Equal left swipe reverses the right swipe")
	drag(3, Vector2(800, 350), Vector2(0, 20))
	expect(is_equal_approx(rig.pitch, -0.334), "Down swipe looks down by the expected angle")
	drag(3, Vector2(800, 330), Vector2(0, -20))
	expect(is_equal_approx(rig.pitch, -0.27), "Up swipe reverses the down swipe")
	press(3, Vector2(800, 330), false)
	expect(manager.contacts.is_empty() and controls.look_touch == -1, "Finger release removes ownership")
	fresh()
	press(2, controls.joystick_center)
	drag(2, controls.joystick_center + Vector2(0, -60), Vector2(0, -60))
	press(8, Vector2(800, 330))
	drag(8, Vector2(850, 330), Vector2(50, 0))
	expect(controls.stick.y < -0.8 and controls.joystick_touch == 2 and controls.look_touch == 8, "Joystick and look fingers stay independent")
	press(2, controls.joystick_center, false)
	expect(controls.look_touch == 8 and controls.stick == Vector2.ZERO, "Releasing joystick leaves the camera finger intact")
	press(2, controls.jump_center)
	var yaw := rig.yaw
	drag(2, Vector2(1000, 450), Vector2(-197, -180))
	expect(is_equal_approx(rig.yaw, yaw) and controls.consume_jump(), "Jump-button finger never changes to camera ownership")
	press(8, Vector2(850, 330), false)
	drag(2, Vector2(900, 450), Vector2(-100, 0))
	expect(controls.look_touch == -1 and is_equal_approx(rig.yaw, yaw), "Action finger does not inherit a released look index")
	press(2, Vector2(900, 450), false)
	press(8, Vector2(800, 330))
	drag(8, Vector2(850, 330), Vector2(50, 0))
	expect(is_equal_approx(angle_difference(yaw, rig.yaw), -0.16), "A reused index starts from its new press baseline")
	fresh()
	for i in range(12):
		press(4, Vector2(730, 330))
		drag(4, Vector2(850, 330), Vector2(120, 0))
		press(4, Vector2(850, 330), false)
	expect(absf(angle_difference(wrapf(-12 * 120 * 0.0032, -PI, PI), rig.yaw)) < 0.0001, "Rapid repeated swipes retain all ordinary relative motion")
	fresh()
	controls.ui_hit_test = func(at: Vector2) -> bool: return Rect2(850, 190, 200, 120).has_point(at)
	press(5, Vector2(900, 220))
	drag(5, Vector2(940, 350), Vector2(40, 130))
	expect(controls.look_touch == -1 and is_zero_approx(rig.yaw), "A UI touch stays UI after leaving its button")
	controls.ui_hit_test = Callable()
	press(5, Vector2(940, 350), false)
	press(5, Vector2(450, 350))
	drag(5, Vector2(550, 350), Vector2(100, 0))
	expect(is_zero_approx(rig.yaw) and controls.look_touch == -1, "Left-side blank area never controls the camera")
	press(5, Vector2(550, 350), false)
	press(5, Vector2(1265, 350))
	drag(5, Vector2(1240, 350), Vector2(-25, 0))
	expect(is_zero_approx(rig.yaw) and controls.look_touch == -1, "Reserved browser edge cannot initiate camera look")
	press(5, Vector2(1240, 350), false)
	press(5, Vector2(-10, 350))
	drag(5, Vector2(800, 350), Vector2(810, 0))
	expect(manager.contacts.is_empty() and is_zero_approx(rig.yaw), "A press outside the canvas cannot become an inside drag")
	fresh()
	press(3, Vector2(850, 340))
	controls.size = Vector2(720, 1280)
	await get_tree().process_frame
	expect(controls.look_touch == -1 and manager.contacts.is_empty(), "Viewport resize invalidates the active touch generation")
	drag(3, Vector2(700, 341), Vector2(900, -700))
	expect(is_zero_approx(rig.yaw) and is_equal_approx(rig.pitch, -0.27), "Old-index/outlier drag after resize cannot rotate the camera (old code jumped 165 degrees)")
	controls.size = Vector2(1280, 720)
	await get_tree().process_frame
	press(3, Vector2(800, 330))
	drag(3, Vector2(810, 330), Vector2(900, -700))
	expect(is_zero_approx(rig.yaw), "A discontinuous relative value is rejected even without a resize event")
	drag(3, Vector2(820, 330), Vector2(10, 0))
	expect(is_equal_approx(rig.yaw, -0.032), "Continuous drag recovers from the rebased validation point")
	drag(3, Vector2(1300, 330), Vector2(480, 0))
	expect(controls.look_touch == -1 and is_equal_approx(rig.yaw, -0.032), "Leaving the viewport releases camera ownership")
	fresh()
	press(3, Vector2(800, 330))
	press(3, Vector2(800, 330), false, true)
	drag(3, Vector2(900, 330), Vector2(100, 0))
	expect(manager.contacts.is_empty() and is_zero_approx(rig.yaw), "Touch cancel clears ownership and ignores late drag")
	press(3, Vector2(800, 330))
	manager.notification(NOTIFICATION_APPLICATION_FOCUS_OUT)
	drag(3, Vector2(900, 330), Vector2(100, 0))
	expect(is_zero_approx(rig.yaw) and manager.contacts.is_empty(), "Focus loss requires a new press after returning")
	press(3, Vector2(800, 330))
	controls.set_enabled(false)
	drag(3, Vector2(900, 330), Vector2(100, 0))
	expect(is_zero_approx(rig.yaw), "Opening a modal disables all camera gestures")
	controls.set_enabled(true)
	var mouse := InputEventMouseMotion.new()
	mouse.device = InputEvent.DEVICE_ID_EMULATION
	expect(not manager.permits_mouse_look(mouse), "Emulated mouse input cannot duplicate touch rotation")
	press(3, Vector2(800, 330))
	mouse.device = 0
	expect(not manager.permits_mouse_look(mouse), "Compatibility mouse motion is suppressed during active touch")
	press(3, Vector2(800, 330), false)
	expect(not manager.permits_mouse_look(mouse), "Trailing compatibility mouse motion is suppressed after release")
	fresh()
	rig.set_invert_y(true)
	press(6, Vector2(800, 330))
	drag(6, Vector2(800, 350), Vector2(0, 20))
	expect(is_equal_approx(rig.pitch, -0.206), "Invert Y changes only vertical look direction")
	rig.invert_y = false
	rig._load_input_preferences()
	expect(rig.invert_y, "Invert Y survives an actual local preferences reload")
	rig.set_invert_y(false)
	for i in range(20):
		rig.orbit(Vector2(200, -200))
	expect(rig.pitch <= CameraController.MAX_PITCH and rig.yaw >= -PI and rig.yaw <= PI, "Yaw wraps and pitch stays below the flip limit")
	rig.orbit(Vector2(NAN, INF))
	expect(is_finite(rig.yaw) and is_finite(rig.pitch), "Non-finite input cannot corrupt camera axes")
	var responses: Array[float] = []
	for pair in [[0, 30], [4, 120]]:
		GraphicsManager.set_quality(pair[0])
		GraphicsManager.set_frame_rate(pair[1])
		fresh()
		press(3, Vector2(800, 330))
		drag(3, Vector2(900, 330), Vector2(100, 0))
		responses.append(rig.yaw)
	expect(is_equal_approx(responses[0], responses[1]), "Internal 3D resolution and frame cap do not rescale camera deltas")
	rig.set_touch_debug(true)
	var panel := TouchDebugPanel.new()
	panel.manager = manager
	panel.rig = rig
	controls.add_child(panel)
	await get_tree().process_frame
	expect(panel.visible and panel.text_label.text.contains("index 3") and panel.text_label.text.contains("ScreenDrag.relative"), "Toggleable panel shows finger index, role, relative and camera data")
	rig.set_touch_debug(false)
	await get_tree().process_frame
	expect(not panel.visible, "Debug panel can be disabled")
	print("RESULT | %d touch/camera checks, %d failures" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)
