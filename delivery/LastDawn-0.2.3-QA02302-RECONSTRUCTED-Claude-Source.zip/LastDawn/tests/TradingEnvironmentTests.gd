extends Node
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.player.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	var trader := world.trader
	world.player.position = trader.at+Vector3(0,0.05,-2)
	InventorySystem.restore({"wood":12,"stone":6,"ore":8})
	expect(trader.trade("food") and InventorySystem.items["wood"]==9 and InventorySystem.items["food"]==1,"Merchant exchange transfers complete costs and rewards")
	expect(trader.stock["food"]==7 and trader.stock["wood"]==27,"Merchant stock accounts for both sides of a trade")
	expect(trader.trade("electronics") and trader.trade("electronics") and InventorySystem.items["electronics"]==2,"Ore can purchase real electronic item stacks")
	expect(trader.trade("blueprint") and InventorySystem.items["blueprint"]==1,"Fictional equipment blueprint is a saved inventory item")
	var before := InventorySystem.snapshot()
	expect(not trader.trade("blueprint") and InventorySystem.snapshot()==before,"Repeated blueprint purchase cannot charge materials")
	trader.stock["water"] = 0
	expect(not trader.trade("water") and InventorySystem.snapshot()==before,"Out-of-stock trade is rejected atomically")
	trader.stock["wood"] = 9999
	InventorySystem.restore({"wood":3})
	expect(not trader.trade("food") and InventorySystem.items["wood"]==3,"Merchant storage overflow cannot silently destroy the payment")
	trader.stock["wood"] = 27
	InventorySystem.restore({"wood":3,"food":9999})
	var stock_before := trader.snapshot()
	expect(not trader.trade("food") and trader.snapshot()==stock_before and InventorySystem.items["wood"]==3,"Inventory overflow leaves merchant and player unchanged")
	trader.advance(301)
	expect(trader.stock["water"]==8 and trader.restock_left>0 and trader.restock_left<=300,"Dynamic stock restocks with bounded saved countdown")
	InventorySystem.restore({"wood":3})
	world.player.position = Vector3.ZERO
	expect(not trader.trade("food") and InventorySystem.items["wood"]==3,"Trading cannot be invoked remotely")
	world.player.position = trader.at+Vector3(0,0.05,-2)
	var old_hour := world.clock.hour
	var old_stock_time := trader.restock_left
	get_tree().paused = true
	await get_tree().create_timer(0.15,true).timeout
	expect(world.clock.hour==old_hour and trader.restock_left==old_stock_time,"Menus pause weather clock and merchant restocking")
	get_tree().paused = false
	expect(world.infection.model["levels"].size()==5,"Five infection levels have concrete data definitions")
	expect(world.infection.level_at(Vector3(18,0,35))==1 and world.infection.level_at(Vector3(40,0,30))==2 and world.infection.level_at(Vector3(0,0,-40))==3,"Current map resolves distinct camp, outskirts and industrial danger levels")
	expect(world.infection.noise_factor(Vector3(0,0,-40))>world.infection.noise_factor(Vector3(40,0,30)),"Higher infection zone makes gameplay noise propagate farther")
	world.noises.clear()
	world._player_noise(Vector3(0,0,-40),12)
	expect(not world.noises.heard(Vector3(14,0,-40),world.noises.serial-1).is_empty(),"Actual high-danger player noise can be heard beyond its ordinary radius")
	world.noises.clear()
	world._player_noise(Vector3(42,0,30),12)
	expect(world.noises.heard(Vector3(56,0,30),world.noises.serial-1).is_empty(),"The same ordinary-zone sound does not gain the industrial noise bonus")
	var clock := world.clock
	clock.restore({"hour":12.0,"day":1,"weather_index":0,"weather_left":240.0})
	var day_energy := world.atmosphere.sun.light_energy
	clock.restore({"hour":23.0,"day":1,"weather_index":0,"weather_left":240.0})
	expect(clock.is_night() and world.atmosphere.sun.light_energy<day_energy and clock.headlamp.visible,"Night changes actual light energy and enables local illumination")
	clock.advance(100)
	expect(clock.day==2 and clock.hour<2,"Day/night clock crosses midnight without losing the day index")
	GraphicsManager.set_quality(2)
	clock.restore({"hour":13.0,"weather_index":2,"weather_left":240.0})
	expect(clock.rain.emitting and world.atmosphere.environment.fog_density>0.0045,"Rain weather enables the local particle pool and fog")
	GraphicsManager.set_quality(0)
	expect(not clock.rain.emitting and not clock.rain.visible,"Lowest quality disables rain particles without removing weather state")
	clock.advance(241)
	expect(clock.weather_index==3 and clock.weather_left>0,"Weather advances deterministically during play")
	var snapshot := world.create_snapshot()
	expect(SaveManager.valid_snapshot(JSON.parse_string(JSON.stringify(snapshot))),"Trading and weather state validate after actual JSON serialization")
	world.restore_snapshot(snapshot)
	expect(trader.trades==snapshot["phase2"]["trader"]["trades"] and clock.hour==snapshot["phase2"]["environment"]["hour"],"Merchant counts and environment time restore exactly")
	for field in ["trader","environment"]:
		var invalid := snapshot.duplicate(true)
		if field=="trader": invalid["phase2"][field]["stock"]["food"] = -1
		else: invalid["phase2"][field]["hour"] = INF
		expect(not SaveManager.valid_snapshot(invalid),"Malformed "+field+" rejected before restoring the world")
	var legacy := snapshot.duplicate(true)
	legacy["version"] = 2
	legacy.erase("phase2")
	world.restore_snapshot(legacy)
	expect(trader.stock==TradingSystem.INITIAL and clock.hour==16.5 and clock.day==1,"Schema 2 migration initializes new modules without changing original items")
	print("RESULT | ",checks," trading/environment checks | ",failures," failures")
	get_tree().quit(1 if failures else 0)
