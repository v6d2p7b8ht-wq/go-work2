extends Node
var checks := 0
var failures := 0
func expect(value: bool, message: String) -> void:
	checks += 1
	if value:
		print("PASS | ", message)
	else:
		failures += 1
		push_error("FAIL | " + message)
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	var world: WorldManager = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await get_tree().physics_frame
	world.ready_for_saves = false
	world.player.set_physics_process(false)
	world.player.survival.apply_settings(SurvivalSystem.DEFAULTS, false)
	for npc in world.zombies:
		npc.set_physics_process(false)
	var z: ZombieAI = world.zombies[0]
	z.position = Vector3(-3, 0.05, -25)
	world.player.position = Vector3(-2, 0.05, -20)
	await get_tree().physics_frame
	z._think()
	expect(z.state == ZombieAI.State.CHASE, "Visible survivor triggers chase")
	world.player.position = Vector3(-2, 0.05, -25)
	z._think()
	expect(z.state == ZombieAI.State.ATTACK, "Close visible survivor triggers attack state")
	var health := world.player.survival.health
	z._combat_step(0.01)
	expect(z.windup > 0 and world.player.survival.health == health, "Attack has a visible windup before damage")
	z._combat_step(0.3)
	z._combat_step(0.3)
	expect(world.player.survival.health == health - 8 and z.attacks_landed == 1, "Windup resolves one configured damage event")
	z._combat_step(0.6)
	expect(z.attacks_landed == 1, "Attack cooldown prevents per-frame hits")
	z.attack_cooldown = 0
	z._combat_step(0.01)
	world.player.position.x += 5
	z._combat_step(0.6)
	expect(z.windup == 0 and z.attacks_landed == 1, "Moving out of reach cancels a pending hit")
	z.position = Vector3(10.9, 0.05, 32)
	world.player.position = Vector3(11.5, 0.05, 32)
	z.state = ZombieAI.State.ATTACK
	z.windup = 0.1
	z._combat_step(0.2)
	expect(z.attacks_landed == 1 and z.windup == 0, "Safe-zone boundary cancels attack even at melee range")
	z.position = Vector3(-7.8, 0.05, -12)
	world.player.position = Vector3(-9, 0.05, -12)
	await get_tree().physics_frame
	z.state = ZombieAI.State.ATTACK
	z.attack_cooldown = 0
	z._combat_step(0.01)
	expect(z.windup == 0, "Supermarket wall blocks melee initiation")
	z._think()
	expect(z.state != ZombieAI.State.CHASE and z.state != ZombieAI.State.ATTACK, "Occluded player is not tracked through walls")
	world.noises.emit_noise(world.player.position, 12)
	z._think()
	expect(z.state == ZombieAI.State.INVESTIGATE and z.last_seen.is_equal_approx(world.player.position), "Hearing investigates a noise position behind an opaque wall")
	var event := world.noises.heard(z.position, 0)
	expect(not event.is_empty() and world.noises.heard(z.position, world.noises.serial).is_empty(), "Noise serial prevents repeated consumption")
	for i in range(30):
		world.noises.emit_noise(Vector3.ZERO, 6)
	expect(world.noises.events.size() == 12, "Noise event pool stays bounded under repeated footsteps")
	world.noises.clock += 2
	expect(world.noises.heard(Vector3.ZERO, 0).is_empty(), "Old noise events expire without retaining phantom targets")
	z.position = z.home
	world.player.position = Vector3(30, 0.05, -25)
	z.state = ZombieAI.State.CHASE
	z._think()
	expect(z.state == ZombieAI.State.INVESTIGATE, "Losing sight investigates last seen rather than live player position")
	z.investigate_time = 0.01
	z._physics_process(0.02)
	expect(z.state == ZombieAI.State.RETURN, "Search timeout starts return to home")
	z._think()
	expect(z.state == ZombieAI.State.PATROL, "Reaching home resumes wandering")
	world.player.position = Vector3(90, 20, 90)
	z._think()
	expect(z.state == ZombieAI.State.SLEEP and z.velocity == Vector3.ZERO, "Far infected sleeps without physics movement")
	z.state = ZombieAI.State.ATTACK
	var saved := z.snapshot()
	z.position = Vector3.ZERO
	z.restore(saved)
	expect(z.position.distance_to(z.home) < 0.3 and z.state == ZombieAI.State.CHASE and z.windup == 0 and z.attack_cooldown >= 0.8, "Saved AI restores position and discards pending attack damage")
	world.player.survival.health = 100
	world.player.position = Vector3(-2.02, 0.05, -17.31)
	z.position = Vector3(-2, 0.05, -20.5)
	z.state = ZombieAI.State.CHASE
	z.windup = 0
	z.attack_cooldown = 0
	z.think_clock = 0
	z.repath_clock = 0
	z.route.clear()
	z.set_physics_process(true)
	for i in range(360):
		await get_tree().physics_frame
	z.set_physics_process(false)
	print("CHASE ENDPOINT | player=", world.player.position, " infected=", z.position, " health=", world.player.survival.health)
	expect(world.player.survival.health < 100, "Real physics chase reaches melee range despite a quantized navigation endpoint")
	world.player.survival.health = 0
	z._think()
	expect(z.state == ZombieAI.State.SLEEP, "Incapacitated player is not repeatedly attacked")
	world.queue_free()
	await get_tree().process_frame
	print("RESULT | %d AI checks, %d failures" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)
