#!/usr/bin/env python3
"""Batch-one real WebGL gameplay using touch only. Chromium is not iPhone Safari."""
import asyncio,json,math,sys,time,shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'tests/batch-one-browser-results';OUT.mkdir(exist_ok=True)
URL=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8770'
checks=[];logs=[]
RESUME='--resume' in sys.argv
PROFILE=Path('/tmp/last-dawn-batch1-browser-profile')
def check(ok,name,detail=None):
 checks.append({'passed':bool(ok),'name':name,'detail':detail});print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
 if not ok:raise AssertionError(str(detail))
async def state(page):return await page.evaluate('window.lastDawnTelemetry')
async def wait(page,expression):
 await page.wait_for_function('window.lastDawnTelemetry && ('+expression+')',timeout=90000,polling=250);return await state(page)
async def tap(page,x,y):
 d=await state(page);r=await page.locator('#canvas').bounding_box()
 await page.touchscreen.tap(r['x']+x*r['width']/d['viewport'][0],r['y']+y*r['height']/d['viewport'][1]);await page.wait_for_timeout(750)
async def button(page,prefix):
 d=await state(page);b=next((b for b in d['buttons'] if b['text'].startswith(prefix)),None)
 if not b:raise AssertionError('Missing '+prefix+': '+str(d['buttons']))
 x,y,w,h=b['rect'];await tap(page,x+w/2,y+h/2)
async def boot(page,continuing=False):
 await page.goto(URL,wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry.modal==="welcome"')
 await button(page,'继续本机存档' if continuing else '进入灰松郊区');return await wait(page,'window.lastDawnTelemetry.modal==="" && window.lastDawnTelemetry.on_floor')
async def dispatch(session,kind,points):await session.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':points})
async def go(page,session,target,stop=1.7):
 print('MOVE | target '+str(target),flush=True)
 d=await state(page);r=await page.locator('#canvas').bounding_box();vw,vh=d['viewport'];cx,cy=135,vh-132
 p={'id':2,'x':r['x']+cx*r['width']/vw,'y':r['y']+cy*r['height']/vh}
 await dispatch(session,'touchStart',[p]);deadline=time.monotonic()+150
 try:
  while time.monotonic()<deadline:
   d=await state(page);x,_,z=d['position'];dx,dz=target[0]-x,target[1]-z;dist=math.hypot(dx,dz)
   if dist<=stop:return
   if d['modal']:raise AssertionError('Unexpected modal while moving: '+str(d))
   yaw=d['camera_yaw'];mx=(dx*math.cos(yaw)-dz*math.sin(yaw))/dist;my=(dx*math.sin(yaw)+dz*math.cos(yaw))/dist
   strength=62 if dist>4 else 44
   await dispatch(session,'touchMove',[dict(p,x=p['x']+mx*strength*r['width']/vw,y=p['y']+my*strength*r['height']/vh)])
   await page.wait_for_timeout(300)
  raise AssertionError('Movement timed out: '+str(d['position'])+' target '+str(target))
 finally:
  await dispatch(session,'touchEnd',[]);await page.wait_for_timeout(700)
async def interact(page):
 d=await state(page);await tap(page,d['viewport'][0]-88,d['viewport'][1]-192)
async def gather(page,ident,count):
 for remaining in range(count-1,-1,-1):
  await wait(page,'window.lastDawnTelemetry.resources.cooldown<=0.01')
  await interact(page)
  await wait(page,'window.lastDawnTelemetry.resources.remaining['+json.dumps(ident)+']==='+str(remaining))
async def main():
 async with async_playwright() as p:
  if not RESUME:shutil.rmtree(PROFILE,ignore_errors=True)
  context=await p.chromium.launch_persistent_context(str(PROFILE),executable_path='/usr/bin/chromium',headless=True,viewport={'width':640,'height':360},device_scale_factor=1,has_touch=True,is_mobile=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  browser=context
  page=await context.new_page();session=await context.new_cdp_session(page)
  def record(t):logs.append(t);(OUT/'console.log').write_text('\n'.join(logs))
  page.on('console',lambda m:record(m.type+': '+m.text));page.on('pageerror',lambda e:record('PAGEERROR: '+str(e)))
  try:
   if RESUME:
    checkpoint=json.loads((OUT/'checkpoint.json').read_text());checks.extend(checkpoint['checks'])
    tree_id=checkpoint['tree_id'];before=checkpoint['before'];rate=checkpoint['rate']
    await boot(page,True)
    print('RESUME | actual browser IndexedDB checkpoint restored',flush=True)
   else:
    d=await boot(page);check(d['build']=='0.2.3-test' and d['survival']['health']==100,'New exported build starts with live survival state')
    initial=d['survival'];await page.wait_for_timeout(1600);d=await state(page)
    check(d['survival']['hunger']<initial['hunger'] and d['survival']['thirst']<initial['thirst'],'Fullness and hydration decline during actual Web gameplay')
    await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.food===1')
    await go(page,session,(6,35));await interact(page);d=await wait(page,'window.lastDawnTelemetry.inventory.water===3')
    check(d['picked_count']==2,'Original food and new water are collected by the touch interaction button')
    await button(page,'背包');await wait(page,'window.lastDawnTelemetry.modal==="inventory"')
    await button(page,'使用食品');d=await wait(page,'window.lastDawnTelemetry.inventory.food===0')
    check(d['survival']['hunger']==100,'Real inventory touch consumes food and restores fullness')
    await button(page,'使用饮水');d=await wait(page,'window.lastDawnTelemetry.inventory.water===2')
    check(d['survival']['thirst']==100,'Real inventory touch consumes water independently')
    await page.screenshot(path=str(OUT/'01-consumables.png'));await button(page,'×')
    await button(page,'设置');await button(page,'极低');await wait(page,'window.lastDawnTelemetry.quality===0')
    await button(page,'生存设置');await wait(page,'window.lastDawnTelemetry.modal==="survival_settings"')
    await page.screenshot(path=str(OUT/'02-survival-settings.png'))
    # First actual canvas HSlider: see screenshot; no internal game mutation API.
    await tap(page,740,232);d=await wait(page,'window.lastDawnTelemetry.survival.settings.hunger_per_minute>3')
    check(d['survival']['settings']['hunger_per_minute']>3,'Touch slider adjusts and saves the real survival rate',d['survival']['settings'])
    rate=d['survival']['settings']['hunger_per_minute'];await button(page,'×')
    await go(page,session,(12,18),1.8);d=await state(page)
    check(d['resource_hint']=='s01_ore_00','Physical approach shows the mine interaction prompt',d['position'])
    await gather(page,'s01_ore_00',5);d=await state(page)
    check(d['inventory']['stone']==5 and d['inventory']['ore']==5,'Five touch harvest actions yield exactly five stone and five ore')
    check(d['harvest_debug']['last_harvest'].get('visible') is False,'Depleted ore is actually hidden in the running WebGL scene',d['harvest_debug'])
    await go(page,session,(40,22),1.5)
    d=await state(page);marker=next(m for m in d['harvest_debug']['landmarks'] if m['kind']=='tree');at=marker['at']
    await go(page,session,(at[0]-1.4,at[2]),.7);d=await state(page)
    for _ in range(3):
     if d['resource_hint'].startswith('s01_tree_'):break
     await interact(page);d=await state(page)
    tree_id=d['resource_hint'];check(tree_id.startswith('s01_tree_'),'Visible original forest tree can be approached and selected',d)
    before=d['inventory']['wood'];await gather(page,tree_id,4);d=await state(page)
    check(d['inventory']['wood']==before+4,'Four touch actions gather finite wood from the forest tree')
    visual=d['harvest_debug']['last_harvest'];check(visual['scale_length']<.01 and visual['collider_disabled'],'Real WebGL MultiMesh readback and physics both confirm depleted tree removal',visual)
    await page.screenshot(path=str(OUT/'03-forest-harvest.png'))
    # Checkpoint uses the real Save button and IndexedDB; it enables resuming test navigation failures.
    await button(page,'设置');await button(page,'保存进度');await page.wait_for_timeout(7000);await button(page,'×')
    (OUT/'checkpoint.json').write_text(json.dumps({'checks':checks,'tree_id':tree_id,'before':before,'rate':rate},ensure_ascii=False,indent=2))
   # Return along the open gap below the garage, then follow the road to an infected.
   await go(page,session,(40,22),1.5);await go(page,session,(11,22),1.5);await go(page,session,(1,15),1.5);await go(page,session,(1,-17),1.8)
   d=await wait(page,'window.lastDawnTelemetry.survival.health<99')
   check(any(z['attacks']>0 for z in d['infected']),'Live infected chases and lands a timed attack in the actual browser',d['infected'])
   await page.screenshot(path=str(OUT/'04-infected-attack.png'))
   # Enter through the open south entrance; the side fence is a real collider.
   await go(page,session,(3,23),1.7);await go(page,session,(17,23),1.0);await go(page,session,(17,30),1.5);d=await state(page)
   health=d['survival']['health'];await page.wait_for_timeout(3000);d=await state(page)
   check(d['survival']['health']>=health and all(z['state']!='ATTACK' for z in d['infected']),'Safe-zone return stops attacks and allows recovery')
   await button(page,'设置');await button(page,'保存进度');saved=await state(page);await page.wait_for_timeout(7000)
   d=await boot(page,True)
   check(d['inventory']['stone']==5 and d['inventory']['ore']==5 and d['inventory']['wood']==before+4 and d['inventory']['water']==2,'Real IndexedDB reload preserves mined and consumed inventory')
   check(d['resources']['remaining'].get(tree_id)==0 and d['resources']['remaining'].get('s01_ore_00')==0,'Real page reload preserves depleted forest and ore')
   check(abs(d['survival']['settings']['hunger_per_minute']-rate)<.01 and d['survival']['health']>=saved['survival']['health']-.5,'Survival stats and custom rate survive real page reload')
   await page.screenshot(path=str(OUT/'05-restored.png'))
   errors=[x for x in logs if x.startswith(('error:','PAGEERROR:')) or 'SCRIPT ERROR' in x]
   check(not errors,'New gameplay and modal transitions produce no JS/GDScript runtime errors',errors)
   for name in ['failure.png','failure-state.json']:
    (OUT/name).unlink(missing_ok=True)
  except Exception:
   await page.screenshot(path=str(OUT/'failure.png'));(OUT/'failure-state.json').write_text(json.dumps(await state(page),ensure_ascii=False,indent=2));raise
  finally:
   (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader, CDP touch only, not physical iPhone or Android','checks':checks,'console':logs},ensure_ascii=False,indent=2));await browser.close()
asyncio.run(main())
