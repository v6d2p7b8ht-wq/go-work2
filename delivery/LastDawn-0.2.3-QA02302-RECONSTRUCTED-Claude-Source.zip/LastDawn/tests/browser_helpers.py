"""Real canvas touch helpers. Reads telemetry; never writes engine/game state."""
import asyncio,math,time
async def state(page):return await page.evaluate('window.lastDawnTelemetry')
async def wait(page,expression,timeout=90000):
 await page.wait_for_function('window.lastDawnTelemetry && ('+expression+')',timeout=timeout,polling=250);return await state(page)
async def point(page,x,y):
 d=await state(page);r=await page.locator('#canvas').bounding_box();return r['x']+x*r['width']/d['viewport'][0],r['y']+y*r['height']/d['viewport'][1]
async def tap(page,x,y):
 x,y=await point(page,x,y);await page.touchscreen.tap(x,y);await page.wait_for_timeout(650)
async def scroll_menu(page,up=True):
 d=await state(page);vw,vh=d['viewport'];width=min(850,vw-60);height=min(600,vh-48);left=(vw-width)/2;top=(vh-height)/2
 x=left+width-27;start_y=top+height-95 if up else top+150;end_y=top+150 if up else top+height-95
 session=await page.context.new_cdp_session(page)
 x,y=await point(page,x,start_y)
 await session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'id':31,'x':x,'y':y}]})
 for i in range(1,9):
  px,py=await point(page,left+width-27,start_y+(end_y-start_y)*i/8)
  await session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'id':31,'x':px,'y':py}]});await page.wait_for_timeout(65)
 await session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});await page.wait_for_timeout(650);await session.detach()
async def button(page,prefix):
 for _ in range(10):
  d=await state(page);b=next((b for b in d['buttons'] if b['text'].startswith(prefix)),None)
  if not b:raise AssertionError('Missing button '+prefix+': '+str(d['buttons']))
  x,y,w,h=b['rect'];cx,cy,cw,ch=b.get('clip',b['rect'])
  if ch>=min(35,h-1) and cw>10 and 0<=cy<d['viewport'][1]:
   await tap(page,cx+cw/2,cy+ch/2);return
  await scroll_menu(page,y>d['viewport'][1]/2)
 raise AssertionError('Cannot touch-scroll to '+prefix+': '+str(b))
async def boot(page,url,continuing=False):
 await page.goto(url,wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry.modal==="welcome"')
 await button(page,'继续本机存档' if continuing else '进入灰松郊区');return await wait(page,'window.lastDawnTelemetry.modal==="" && window.lastDawnTelemetry.on_floor')
async def dispatch(session,kind,points):await session.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':points})
async def go(page,session,target,stop=1.5):
 print('MOVE | '+str(target),flush=True);d=await state(page);r=await page.locator('#canvas').bounding_box();vw,vh=d['viewport'];cx,cy=135,vh-132
 p={'id':2,'x':r['x']+cx*r['width']/vw,'y':r['y']+cy*r['height']/vh};await dispatch(session,'touchStart',[p]);deadline=time.monotonic()+100
 try:
  while time.monotonic()<deadline:
   d=await state(page);x,_,z=d['position'];dx,dz=target[0]-x,target[1]-z;dist=math.hypot(dx,dz)
   if dist<=stop:return
   if d['modal']:raise AssertionError('Unexpected modal: '+str(d['modal']))
   yaw=d['camera_yaw'];mx=(dx*math.cos(yaw)-dz*math.sin(yaw))/dist;my=(dx*math.sin(yaw)+dz*math.cos(yaw))/dist;strength=62 if dist>3 else max(14,min(34,dist*13))
   await dispatch(session,'touchMove',[dict(p,x=p['x']+mx*strength*r['width']/vw,y=p['y']+my*strength*r['height']/vh)]);await page.wait_for_timeout(250)
  raise AssertionError('Movement blocked at '+str(d['position'])+' toward '+str(target))
 finally:await dispatch(session,'touchEnd',[]);await page.wait_for_timeout(500)
async def interact(page):
 d=await state(page);await tap(page,d['viewport'][0]-88,d['viewport'][1]-192)
async def gather(page,ident,count):
 import json
 for remaining in range(count-1,-1,-1):
  await wait(page,'window.lastDawnTelemetry.resources.cooldown<=0.01');await interact(page)
  await wait(page,'window.lastDawnTelemetry.resources.remaining['+json.dumps(ident)+']==='+str(remaining))
async def save(page):
 await button(page,'设置');await button(page,'保存进度');await page.wait_for_timeout(7000);await button(page,'×')
