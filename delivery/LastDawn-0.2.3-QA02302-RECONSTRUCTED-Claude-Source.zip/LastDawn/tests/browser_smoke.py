#!/usr/bin/env python3
"""Exercise the real Web export via Chromium touch events, including IndexedDB reload.
Run a static server for export/web, then: python tests/browser_smoke.py [URL]
This is desktop browser automation, not Android/iPhone hardware certification.
"""
import asyncio
import json
import math
from pathlib import Path
import sys
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'tests' / 'browser-results'
OUTPUT.mkdir(exist_ok=True)
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8765'
checks = []
console = []

def check(condition, text):
    checks.append({'passed': bool(condition), 'name': text})
    print(('PASS | ' if condition else 'FAIL | ') + text, flush=True)
    if not condition:
        raise AssertionError(text)

async def state(page):
    return await page.evaluate('window.lastDawnTelemetry')

async def wait_state(page, expression):
    await page.wait_for_function('window.lastDawnTelemetry && (' + expression + ')', timeout=45000, polling=250)
    return await state(page)

async def tap_logical(page, x, y):
    value = await state(page)
    bounds = await page.locator('#canvas').bounding_box()
    await page.touchscreen.tap(bounds['x'] + x / value['viewport'][0] * bounds['width'], bounds['y'] + y / value['viewport'][1] * bounds['height'])

async def tap_button(page, prefix):
    value = await state(page)
    matches = [b for b in value['buttons'] if b['text'].startswith(prefix)]
    if not matches:
        raise AssertionError('No visible button: ' + prefix + '\n' + str(value))
    x, y, w, h = matches[-1]['rect']
    await tap_logical(page, x+w/2, y+h/2)
    await page.wait_for_timeout(600)

async def boot(page):
    await page.goto(URL, wait_until='networkidle')
    await page.locator('#start').click()
    return await wait_state(page, 'window.lastDawnTelemetry.modal === "welcome"')

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
            args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        context = await browser.new_context(viewport={'width':960,'height':540}, has_touch=True, device_scale_factor=1)
        page = await context.new_page()
        def record(message):
            console.append(message)
            (OUTPUT/'console.log').write_text('\n'.join(console), encoding='utf-8')
        page.on('console', lambda msg: record(msg.type + ': ' + msg.text))
        page.on('pageerror', lambda error: record('PAGEERROR: ' + str(error)))
        try:
            value = await boot(page)
            check(value['quality'] == 1 and value['target_fps'] == 30, 'Fresh Web profile defaults to low / 30 FPS cap')
            await page.screenshot(path=str(OUTPUT/'01-welcome.png'))
            await tap_button(page, '进入灰松郊区')
            value = await wait_state(page, 'window.lastDawnTelemetry.modal === "" && window.lastDawnTelemetry.on_floor')
            check(value['on_floor'], 'Touch-only welcome button starts the playable world')
            await tap_logical(page, 1192, 528)
            value = await wait_state(page, 'window.lastDawnTelemetry.inventory.food === 1')
            check(value['picked_count'] == 1, 'Touch interaction collects the nearby food exactly once')
            await tap_button(page, '背包')
            await wait_state(page, 'window.lastDawnTelemetry.modal === "inventory"')
            await page.screenshot(path=str(OUTPUT/'02-inventory.png'))
            check(True, 'Top-bar touch opens the actual inventory GUI')
            await tap_button(page, '×')
            await wait_state(page, 'window.lastDawnTelemetry.modal === ""')
            session = await context.new_cdp_session(page)
            before = await state(page)
            # At 960x540, the 1280x720 logical coordinate conversion is 0.75.
            stick = {'id':2, 'x':135*.75, 'y':588*.75}
            look = {'id':7, 'x':880*.75, 'y':320*.75}
            jump = {'id':11, 'x':1197*.75, 'y':630*.75}
            await session.send('Input.dispatchTouchEvent', {'type':'touchStart','touchPoints':[stick]})
            stick = dict(stick, y=525*.75)
            await session.send('Input.dispatchTouchEvent', {'type':'touchMove','touchPoints':[stick]})
            await session.send('Input.dispatchTouchEvent', {'type':'touchStart','touchPoints':[stick,look]})
            look = dict(look, x=930*.75)
            await session.send('Input.dispatchTouchEvent', {'type':'touchMove','touchPoints':[stick,look]})
            await session.send('Input.dispatchTouchEvent', {'type':'touchStart','touchPoints':[stick,look,jump]})
            value = await wait_state(page, 'window.lastDawnTelemetry.touches[0] !== -1 && window.lastDawnTelemetry.touches[1] !== -1')
            check(value['touches'][0] != value['touches'][1], 'Real browser multi-touch preserves separate joystick and camera fingers')
            await page.wait_for_timeout(3000)
            during = await state(page)
            await session.send('Input.dispatchTouchEvent', {'type':'touchEnd','touchPoints':[]})
            await wait_state(page, 'window.lastDawnTelemetry.touches[0] === -1 && window.lastDawnTelemetry.touches[1] === -1')
            check(math.dist(before['position'][::2], during['position'][::2]) > 1.0, 'Holding the touch joystick moves the 3D player')
            check(abs(during['camera_yaw'] - before['camera_yaw']) > .03, 'Simultaneous right-side touch drag rotates the camera')
            await tap_logical(page, 1102, 642)
            await page.wait_for_timeout(500)
            await tap_logical(page, 1102, 642)
            await tap_logical(page, 1224, 404)
            await page.wait_for_timeout(600)
            value = await state(page)
            check(value['camera_distance'] < before['camera_distance'], 'Touch camera-distance control changes the actual camera')
            await tap_button(page, '设置')
            await wait_state(page, 'window.lastDawnTelemetry.modal === "settings"')
            await tap_button(page, '极低')
            await wait_state(page, 'window.lastDawnTelemetry.quality === 0')
            await tap_button(page, '45')
            await wait_state(page, 'window.lastDawnTelemetry.target_fps === 45')
            check(True, 'Touch settings apply quality and FPS cap')
            await page.screenshot(path=str(OUTPUT/'03-settings.png'))
            await tap_button(page, '保存进度')
            saved = await state(page)
            await page.wait_for_timeout(7000) # Allow asynchronous browser IndexedDB synchronization.
            value = await boot(page)
            check(value['quality'] == 0 and value['target_fps'] == 45, 'Graphics ConfigFile persists across a real page reload')
            await tap_button(page, '继续本机存档')
            value = await wait_state(page, 'window.lastDawnTelemetry.modal === "" && window.lastDawnTelemetry.inventory.food === 1')
            check(value['picked_count'] == 1 and math.dist(saved['position'], value['position']) < .4, 'Browser local save restores position, inventory and collected IDs after reload')
            await page.screenshot(path=str(OUTPUT/'04-gameplay.png'))
            await page.set_viewport_size({'width':844,'height':390})
            await page.wait_for_timeout(3000)
            value = await state(page)
            check(value['viewport'][0] / value['viewport'][1] > 2.0, 'Wide phone landscape resizes the canvas and HUD')
            await page.screenshot(path=str(OUTPUT/'05-phone-landscape.png'))
            await tap_button(page, '背包')
            await wait_state(page, 'window.lastDawnTelemetry.modal === "inventory"')
            await tap_button(page, '×')
            await page.set_viewport_size({'width':390,'height':844})
            await page.wait_for_timeout(3000)
            value = await state(page)
            check(value['viewport'][0] >= 700 and value['viewport'][0] < 800 and value['viewport'][1] > 1280, 'Portrait uses readable 720-wide logical UI instead of shrinking a desktop HUD')
            await tap_button(page, '背包')
            await wait_state(page, 'window.lastDawnTelemetry.modal === "inventory"')
            await page.screenshot(path=str(OUTPUT/'06-phone-portrait.png'))
            await tap_button(page, '×')
            errors = [line for line in console if line.startswith('error:') or line.startswith('PAGEERROR:') or 'SCRIPT ERROR' in line]
            check(not errors, 'Exported game has no JavaScript or GDScript runtime errors during this browser run')
            print('Observed software-renderer FPS:', (await state(page))['fps'], '(not phone performance)', flush=True)
        finally:
            (OUTPUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader software WebGL2 / synthetic touch, not physical phones','checks':checks,'console':console}, ensure_ascii=False, indent=2), encoding='utf-8')
            await browser.close()

asyncio.run(main())
