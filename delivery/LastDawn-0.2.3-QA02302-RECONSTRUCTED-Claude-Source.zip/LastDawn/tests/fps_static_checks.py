#!/usr/bin/env python3
"""Protect the previously fixed Safari input and unrelated gameplay from this scoped change."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]
checks=0
protected = {'systems/TouchInputManager.gd','scripts/MobileControls.gd','scripts/CameraController.gd','ui/TouchDebugPanel.gd','scripts/PlayerController.gd','systems/SurvivalSystem.gd'}
for name,sha in json.loads((r/'docs/FPS_PROTECTED_FILES.json').read_text()).items():
    # QA intentionally fixes save/inventory/resource/AI modules; their invariants have dedicated regression tests.
    if name not in protected: continue
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==sha,name
    checks+=1;print('PASS | Stable gameplay/input bytes unchanged:',name)
js=(r/'export/performance_probe.js').read_text()
assert all(word not in js for word in ['touchstart','touchmove','touchcancel','preventDefault','Engine.max_fps'])
checks+=1;print('PASS | Browser probe has no input path or engine FPS override')
assert 'common/physics_ticks_per_second=60' in (r/'project.godot').read_text()
checks+=1;print('PASS | Physics frequency remains 60 Hz')
block=(r/'export/web_shell.html').read_text().split('window.lastDawnInputEpoch = 0;')[1].split('async function begin()')[0]
assert hashlib.sha256(block.encode()).hexdigest()==(r/'docs/FPS_SAFARI_INPUT_BLOCK.sha256').read_text().strip()
checks+=1;print('PASS | Safari canvas geometry/input lifecycle block is byte-identical to the baseline')
print(f'RESULT | {checks} static checks | 0 failures')
