#!/usr/bin/env python3
"""Reproduce original 128 px surface textures and a subset of Noto Sans CJK SC.
Requires Pillow, numpy and fonttools; used by the developer, never needed by players.
"""
from pathlib import Path
import math
import random
import subprocess
import wave
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from fontTools import subset
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "materials"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(71131)
random.seed(71131)

for name in ["plaster", "asphalt", "ground", "rust", "cloth", "wood", "brick", "rock"]:
    noise = rng.normal(0, 1, (128, 128))
    broad = Image.fromarray(np.uint8(rng.uniform(0, 255, (16, 16)))).resize((128, 128), Image.Resampling.BICUBIC)
    values = np.clip(175 + noise * 10 + (np.asarray(broad).astype(float) - 128) * 0.28, 70, 235)
    if name == "asphalt":
        values = np.clip(180 + noise * 22, 90, 235)
    rgb = np.stack([values] * 3, axis=-1).astype(np.uint8)
    image = Image.fromarray(rgb, "RGB")
    draw = ImageDraw.Draw(image)
    if name == "brick":
        for y in range(0, 129, 16):
            draw.line((0, y, 128, y), fill=(92, 92, 86), width=2)
            for x in range(-16 if (y // 16) % 2 else 0, 129, 32):
                draw.line((x, y, x, y + 16), fill=(95, 96, 88), width=2)
    if name in ("plaster", "rock", "asphalt"):
        for _ in range(4):
            x, y = random.randint(0, 128), random.randint(0, 128)
            points = [(x, y)]
            for _ in range(8):
                x += random.randint(-5, 7)
                y += random.randint(2, 9)
                points.append((x, y))
            draw.line(points, fill=(100, 103, 97), width=1)
    if name == "wood":
        for x in range(0, 129, 8):
            draw.line([(x + math.sin(y / 11) * 1.4, y) for y in range(128)], fill=(111, 115, 102), width=1)
    if name == "cloth":
        for xy in range(0, 128, 4):
            draw.line((xy, 0, xy, 128), fill=(144, 151, 139), width=1)
            draw.line((0, xy, 128, xy), fill=(147, 150, 140), width=1)
    if name == "rust":
        for _ in range(90):
            x, y = random.randint(0, 128), random.randint(0, 128)
            r = random.randint(1, 5)
            draw.ellipse((x-r, y-r, x+r, y+r), fill=(124, 108, 88))
        image = image.filter(ImageFilter.GaussianBlur(0.4))
    image.save(OUT / (name + ".png"), optimize=True)

# Include every UI glyph in the authored project, ASCII, punctuation and compass symbols.
text = "".join(chr(c) for c in range(32, 127)) + "✓×−＋→↓°·…：，。！？「」（）一级二三四五"
for path in ROOT.rglob("*"):
    if path.suffix in (".gd", ".json", ".html", ".md") and ".godot" not in path.parts:
        text += path.read_text(encoding="utf-8", errors="ignore")
source = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
if source.exists():
    font = TTFont(str(source), fontNumber=2)
    options = subset.Options()
    options.layout_features = ["kern", "liga"]
    tool = subset.Subsetter(options=options)
    tool.populate(text=text)
    tool.subset(font)
    for entry in font['name'].names:
        if entry.nameID in (1, 4, 6, 16):
            value = 'LastDawnSans-Regular' if entry.nameID == 6 else 'Last Dawn Sans'
            entry.string = value.encode(entry.getEncoding(), errors='replace')
    font.save(ROOT / "assets/fonts/LastDawnSans.ttf")

# Original filtered wind, no recordings or third-party audio.
rate = 16000
samples = rng.normal(0, 1, rate * 12)
kernel = np.ones(200) / 200
wind = np.convolve(samples, kernel, mode="same")
time = np.arange(len(samples)) / rate
wind *= 0.6 + 0.35 * np.sin(time * math.tau / 12)
wind = np.clip(wind * 20000, -32000, 32000).astype("<i2")
temporary = ROOT / "assets/wind.wav"
with wave.open(str(temporary), "wb") as wav:
    wav.setnchannels(1)
    wav.setsampwidth(2)
    wav.setframerate(rate)
    wav.writeframes(wind.tobytes())
subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(temporary), "-c:a", "libvorbis", "-q:a", "1", str(ROOT / "assets/wind.ogg")], check=True)
temporary.unlink()
print("Original textures, wind and subset font generated.")
