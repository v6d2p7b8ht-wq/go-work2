#!/usr/bin/env python3
"""Reproduce only the original chop/mine samples; no source recordings or external assets."""
import math,random,struct,wave
from pathlib import Path
audio=Path(__file__).resolve().parents[1]/'assets/audio';audio.mkdir(exist_ok=True)
for name,duration,frequency in [('chop',.18,140),('mine',.22,1750)]:
 rng=random.Random(933 if name=='chop' else 734);rate=22050;data=[]
 for i in range(int(rate*duration)):
  t=i/rate;envelope=math.exp(-t*(28 if name=='chop' else 20));tone=math.sin(2*math.pi*frequency*t)
  data.append(struct.pack('<h',round((rng.uniform(-1,1)*.5+tone*.5)*envelope*.5*32767)))
 with wave.open(str(audio/(name+'.wav')),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate);f.writeframes(b''.join(data))
