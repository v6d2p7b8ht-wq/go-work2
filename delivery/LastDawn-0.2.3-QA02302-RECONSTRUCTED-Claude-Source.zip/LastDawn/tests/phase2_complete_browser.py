#!/usr/bin/env python3
"""Touch-only gameplay acceptance on the real export. No writable game/debug API."""
import asyncio,hashlib,json,sys,os
from pathlib import Path
from playwright.async_api import async_playwright
from browser_helpers import boot,button,go,interact,gather,wait,state,save,point
ROOT=Path(__file__).resolve().parents[1];OUT=Path(os.environ.get('QA_BROWSER_OUTPUT',str(ROOT/'tests/phase2-browser-results/gameplay')));OUT.mkdir(parents=True,exist_ok=True)
URL=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8773/test/').rstrip('/')+'/'
PROFILE=Path(os.environ.get('QA_BROWSER_PROFILE','/tmp/last-dawn-phase2-complete-browser-profile'));RESUME='--resume' in sys.argv
checks=[];logs=[];samples=[];meta={};stage='start'
PCK_SHA=hashlib.sha256((ROOT/'export/web-static/index.pck').read_bytes()).hexdigest()
ORDER=['start','mine1','resources','traded','built','evacuated']
def check(ok,name,data=None):
 checks.append({'passed':bool(ok),'name':name,'data':data});print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
 if not ok:raise AssertionError(name+': '+str(data))
async def checkpoint(page,name):
 global stage
 await save(page);stage=name
 (OUT/'checkpoint.json').write_text(json.dumps({'stage':stage,'pck_sha':PCK_SHA,'checks':checks,'meta':meta},ensure_ascii=False,indent=2))
 print('CHECKPOINT | '+stage,flush=True)
async def build(page,session,kind,at):
 # A real auto-save can include the partially completed next checkpoint stage.
 d=await state(page);existing=next((x for x in d['buildings']['records'] if x['type']==kind),None)
 if existing:
  print('RESUME | existing '+kind,flush=True)
  return existing
 if kind in ('wall','shelter'):
  current=await state(page);await go(page,session,(11.5,current['position'][2]),.7);await go(page,session,(11.5,at[1]),.7)
 await go(page,session,at,.6);await button(page,'建造');await wait(page,'window.lastDawnTelemetry.modal==="building"')
 name={'campfire':'篝火','wall':'围墙','shelter':'简易避难所'}[kind]
 await button(page,'选择'+name);await wait(page,'window.lastDawnTelemetry.building_preview.type==='+json.dumps(kind))
 d=await state(page);check(not d['building_preview']['reason'],'Clear affordable '+kind+' preview is valid',d['building_preview'])
 count=len(d['buildings']['records']);await interact(page);await wait(page,'window.lastDawnTelemetry.buildings.records.length==='+str(count+1))
 await button(page,'取消建造');return (await state(page))['buildings']['records'][-1]
async def main():
 global stage,meta
 async with async_playwright() as p:
  if not RESUME and PROFILE.exists():raise RuntimeError('Use a fresh QA_BROWSER_PROFILE or --resume; existing profiles are preserved')
  context=await p.chromium.launch_persistent_context(str(PROFILE),executable_path='/usr/bin/chromium',headless=True,viewport={'width':640,'height':360},has_touch=True,is_mobile=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  page=await context.new_page();session=await context.new_cdp_session(page)
  def record(t):logs.append(t);(OUT/'console.log').write_text('\n'.join(logs))
  page.on('console',lambda m:record(m.type+': '+m.text));page.on('pageerror',lambda e:record('PAGEERROR: '+str(e)))
  try:
   response=await context.request.get(URL+'index.pck')
   served_sha=hashlib.sha256(await response.body()).hexdigest()
   assert response.ok and served_sha==PCK_SHA,'Served PCK must match the exact final local build'
   if RESUME:
    old=json.loads((OUT/'checkpoint.json').read_text());assert old['pck_sha']==PCK_SHA,'Cannot resume across a changed game binary'
    stage=old['stage'];meta=old['meta'];checks.extend(old['checks']);await boot(page,URL,True);print('RESUME | '+stage,flush=True)
   else:
    check(served_sha==PCK_SHA,'Browser downloads the exact final QA build PCK',served_sha)
    d=await boot(page,URL);check(d['build']=='0.2.3-test' and 'LastDawnPhase2Test' in d['profile'],'Actual preview boots into its isolated save profile')
    await button(page,'设置');await button(page,'极低');await button(page,'60');await button(page,'×')
    await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.food===1')
    await go(page,session,(9.5,31),1.2);await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.wood===2')
    await go(page,session,(7.6,21),1.2);await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.stone===2')
    await go(page,session,(12,18),1.8);d=await state(page);check(d['resource_hint']=='s01_ore_00','Mining starts at the actual resource reached with the joystick')
    before=d['feedback']['count'];x,y=await point(page,d['viewport'][0]-88,d['viewport'][1]-192);await page.touchscreen.tap(x,y);await page.wait_for_timeout(180)
    await page.screenshot(path=str(OUT/'01-mining.png'));await wait(page,'window.lastDawnTelemetry.resources.remaining.s01_ore_00===4')
    for remaining in [3,2,1,0]:
     await wait(page,'window.lastDawnTelemetry.resources.cooldown<=0.01');await interact(page);await wait(page,'window.lastDawnTelemetry.resources.remaining.s01_ore_00==='+str(remaining))
    d=await state(page);check(d['inventory']['stone']==7 and d['inventory']['ore']==5 and d['feedback']['count']==before+5,'Five real mining actions update both outputs and trigger feedback once each')
    check(d['harvest_debug']['last_harvest'].get('visible') is False,'Exhausted ore is hidden in the actual WebGL scene')
    await checkpoint(page,'mine1')
   if ORDER.index(stage)<ORDER.index('resources'):
    await go(page,session,(40,22),1.5);await go(page,session,(41,22),1.8)
    await wait(page,'window.lastDawnTelemetry.resource_hint==="s01_ore_01"');await gather(page,'s01_ore_01',5)
    d=await state(page);check(d['inventory']['ore']==10 and d['inventory']['stone']==12,'Second actual ore node adds finite resources for trading and construction')
    for target,expected in [((44,22),5),((54,19),7),((48,31),9)]:
     await go(page,session,target,1.2);await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.wood==='+str(expected))
    meta['trees']=[]
    for tree_number in range(2):
     d=await state(page);marker=next(x for x in d['harvest_debug']['landmarks'] if x['kind']=='tree');at=marker['at']
     await go(page,session,(40,22),1.2);await go(page,session,(at[0]-1.4,at[2]),.8);d=await state(page)
     check(d['resource_hint'].startswith('s01_tree_'),'Visible tree '+str(tree_number+1)+' is physically reachable',{'position':d['position'],'hint':d['resource_hint']})
     ident=d['resource_hint'];meta['trees'].append(ident);await gather(page,ident,4);d=await state(page)
     visual=d['harvest_debug']['last_harvest'];check(visual.get('scale_length',1)<.01 and visual.get('collider_disabled'),'Tree '+str(tree_number+1)+' removal updates MultiMesh and collision in WebGL',visual)
    d=await state(page);check(d['inventory']['wood']==17,'Gathered wood and original pickups have consistent combined quantity')
    await page.screenshot(path=str(OUT/'02-forest.png'));await checkpoint(page,'resources')
   if ORDER.index(stage)<ORDER.index('traded'):
    await go(page,session,(40,22),1.5);await go(page,session,(20,21),1.2);await interact(page);await wait(page,'window.lastDawnTelemetry.modal==="trading"')
    await button(page,'换取食品');await wait(page,'window.lastDawnTelemetry.trader.trades===1')
    for expected in [1,2]:
     await button(page,'换取电子元件');await wait(page,'window.lastDawnTelemetry.inventory.electronics==='+str(expected))
    await button(page,'换取虚构装备蓝图');d=await wait(page,'window.lastDawnTelemetry.inventory.blueprint===1')
    check(d['trader']['trades']==4 and d['inventory']['ore']==4 and d['inventory']['electronics']==0 and d['inventory']['wood']==14,'Actual touch-scroll trades exchange exact materials and deliver the fictional blueprint')
    await page.screenshot(path=str(OUT/'03-trader.png'));await button(page,'×');await checkpoint(page,'traded')
   if ORDER.index(stage)<ORDER.index('built'):
    current=await state(page)
    await go(page,session,(11.5,current['position'][2]),.7)
    await go(page,session,(11.5,23),.7)
    await go(page,session,(11,23),1.0)
    fire=await build(page,session,'campfire',(8.5,40.5));fx,_,fz=fire['position']
    d=await state(page);dx,dz=d['position'][0]-fx,d['position'][2]-fz;length=max(.01,(dx*dx+dz*dz)**.5)
    await go(page,session,(fx+dx/length*1.6,fz+dz/length*1.6),.5)
    for _ in range(3):
     await interact(page);d=await state(page)
     if not d['buildings']['records'][0]['lit']:break
    d=await wait(page,'window.lastDawnTelemetry.buildings.records[0].lit===false')
    check(not d['building_visuals'][0]['flame'],'Campfire interaction changes both saved state and actual rendered flame')
    await build(page,session,'wall',(8.5,51.5));shelter=await build(page,session,'shelter',(8.5,68.5));sx,_,sz=shelter['position']
    await go(page,session,(sx+3.2,sz+4),.8);await go(page,session,(sx+3.2,sz-3),.8);await go(page,session,(sx,sz-3),.6);await go(page,session,(sx,sz),.6)
    d=await state(page);check(d['safe'] and len(d['buildings']['records'])==3,'Player can enter the actual shelter through its doorway and receive shelter protection')
    check(d['inventory']['wood']==1 and d['inventory']['stone']==6,'Three construction recipes consume exactly thirteen wood and six stone')
    meta['built_records']=d['buildings']['records'];await page.screenshot(path=str(OUT/'04-shelter.png'));await checkpoint(page,'built')
    await page.reload(wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry.modal==="welcome"');await button(page,'继续本机存档');d=await wait(page,'window.lastDawnTelemetry.modal===""')
    check(d['buildings']['records']==meta['built_records'] and d['inventory']['blueprint']==1,'Real IndexedDB reload restores structure IDs, fire switch and purchased blueprint without duplication')
   if ORDER.index(stage)<ORDER.index('evacuated'):
    d=await state(page);shelter=next(x for x in d['buildings']['records'] if x['type']=='shelter');sx,_,sz=shelter['position']
    await go(page,session,(sx,sz-3),.6);await go(page,session,(11.5,sz-3),.8);await go(page,session,(11.5,23),.8);await go(page,session,(9.8,15.5),.7)
    meta['reward_before']=(await state(page))['inventory']
    await interact(page);await wait(page,'window.lastDawnTelemetry.modal==="family"');await button(page,'跟我去安全区');await wait(page,'window.lastDawnTelemetry.family.stage==="following"')
    await go(page,session,(11,23),1);await go(page,session,(17,23),1);await go(page,session,(20,35),.7)
    d=await wait(page,'window.lastDawnTelemetry.family.stage==="evacuated"',120000)
    check(d['family']['reward_claimed'] and d['family']['position'][2]>=30,'Family physically follows through camp entrance and completes its dwell/reward condition',d['family'])
    check(d['inventory']['food']==meta['reward_before']['food']+2 and d['inventory']['water']==meta['reward_before']['water']+2,'Evacuation grants its single food/water reward on the real touch playthrough')
    await page.screenshot(path=str(OUT/'05-family-safe.png'));await checkpoint(page,'evacuated')
   saved=await state(page);await boot(page,URL,True);d=await state(page)
   check(d['family']['stage']=='evacuated' and d['family']['reward_claimed'] and d['inventory']==saved['inventory'],'Reloading completed escort does not replay rewards or change item counts')
   check(d['trader']['trades']==4 and d['buildings']['records']==meta['built_records'] and all(d['resources']['remaining'][x]==0 for x in meta['trees']),'Final save consistently restores trading, all constructions and harvested trees')
   check(d['zone']['level']==1 and (d['environment']['day']>1 or d['environment']['hour']>16.5),'Current-area danger and running day/night clock are real gameplay state',d['environment'])
   yaw=d['camera_yaw'];await button(page,'任务');d=await wait(page,'window.lastDawnTelemetry.modal==="family"')
   check(abs(d['camera_yaw']-yaw)<.001 and d['touches']==[-1,-1],'New mission UI button owns its touch and clears camera/joystick gestures')
   await button(page,'×');await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(2500);await button(page,'建造');d=await wait(page,'window.lastDawnTelemetry.modal==="building"')
   check(700<=d['viewport'][0]<800,'New building menu remains usable in portrait logical layout')
   await page.screenshot(path=str(OUT/'06-portrait-building.png'));await button(page,'×');await page.set_viewport_size({'width':640,'height':360});await page.wait_for_timeout(2500)
   for _ in range(6):
    samples.append(await page.evaluate('window.lastDawnPerformance'));await page.wait_for_timeout(2000)
   check(all(x['render']['mean_ms']>0 and x['engine_actual_fps']!=120 for x in samples),'Actual performance samples remain measured rather than fabricated targets')
   errors=[x for x in logs if x.startswith(('error:','PAGEERROR:')) or 'SCRIPT ERROR' in x];check(not errors,'Full exported gameplay has no JS/GDScript runtime errors',errors)
  except Exception:
   await page.screenshot(path=str(OUT/'failure.png'));(OUT/'failure-state.json').write_text(json.dumps(await state(page),ensure_ascii=False,indent=2));raise
  finally:
   (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader, actual exported game and touch actions; NOT physical Android/iPhone','pck_sha256':PCK_SHA,'served_pck_sha256':served_sha,'stage':stage,'checks':checks,'samples':samples,'console':logs},ensure_ascii=False,indent=2));await context.close()
asyncio.run(main())
