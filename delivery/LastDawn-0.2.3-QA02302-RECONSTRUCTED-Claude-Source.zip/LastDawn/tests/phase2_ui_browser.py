#!/usr/bin/env python3
"""Final HUD correction acceptance through real canvas touch, no state mutation API."""
import asyncio,json,sys,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
from browser_helpers import boot,button,go,interact,wait,state
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'tests/phase2-browser-results/ui-final';OUT.mkdir(parents=True,exist_ok=True)
URL=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8773/test/';checks=[];logs=[]
def check(ok,name,data=None):
 checks.append({'passed':bool(ok),'name':name,'data':data});print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
 if not ok:raise AssertionError(name+': '+str(data))
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  context=await browser.new_context(viewport={'width':640,'height':360},has_touch=True);page=await context.new_page();session=await context.new_cdp_session(page)
  page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
  try:
   d=await boot(page,URL);await page.wait_for_timeout(1000);await page.screenshot(path=str(OUT/'01-landscape-hud.png'))
   yaw=d['camera_yaw'];await button(page,'建造');d=await wait(page,'window.lastDawnTelemetry.modal==="building"')
   check(d['touches']==[-1,-1] and abs(d['camera_yaw']-yaw)<.001,'Repositioned Build UI uses its own touch without rotating camera')
   await button(page,'×');await go(page,session,(8.5,40.5),.7);await button(page,'建造');await button(page,'选择篝火')
   d=await wait(page,'window.lastDawnTelemetry.building_preview.type==="campfire"')
   check('材料不足' in d['building_preview']['reason'],'Unaffordable construction preview reports its real material failure')
   before=d['inventory'];await interact(page);d=await state(page)
   check(len(d['buildings']['records'])==0 and d['inventory']==before,'Unfunded touch confirmation creates nothing and consumes nothing')
   await page.screenshot(path=str(OUT/'02-unfunded-preview.png'));await button(page,'取消建造')
   await button(page,'任务');await button(page,'跟我去安全区');d=await state(page)
   check(d['family']['stage']=='not_started' and d['modal']=='family','Far-away family follow button cannot start or teleport the escort')
   await button(page,'×');await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(2500)
   await page.screenshot(path=str(OUT/'03-portrait-hud.png'));await button(page,'建造');d=await wait(page,'window.lastDawnTelemetry.modal==="building"')
   check(700<=d['viewport'][0]<800 and d['touches']==[-1,-1],'Final portrait action buttons still open the menu and clear gesture ownership')
   await page.screenshot(path=str(OUT/'04-portrait-building.png'));await button(page,'×')
   errors=[x for x in logs if x.startswith(('error:','PAGEERROR:')) or 'SCRIPT ERROR' in x]
   check(not errors,'Final HUD/previews run without JavaScript or GDScript errors',errors)
  finally:
   (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader, actual canvas touch, NOT iPhone','pck_sha256':hashlib.sha256((ROOT/'export/web-static/index.pck').read_bytes()).hexdigest(),'checks':checks,'console':logs},ensure_ascii=False,indent=2));await browser.close()
asyncio.run(main())
