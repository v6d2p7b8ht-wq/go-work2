#!/usr/bin/env python3
"""Real IndexedDB isolation: stable and preview share one origin, but not one mount."""
import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
from browser_helpers import boot,button,interact,wait,state,save
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'tests/phase2-browser-results/isolation';OUT.mkdir(parents=True,exist_ok=True)
BASE=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8773').rstrip('/');checks=[];logs=[]
def check(ok,name,data=None):
 checks.append({'passed':bool(ok),'name':name,'data':data});print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
 if not ok:raise AssertionError(name+': '+str(data))
READ_DB="""async()=>new Promise((resolve,reject)=>{const q=indexedDB.open('/userfs');q.onupgradeneeded=()=>{q.transaction.abort();reject(Error('Stable DB unexpectedly missing'));};q.onerror=()=>reject(q.error);q.onsuccess=()=>{const db=q.result,tx=db.transaction('FILE_DATA','readonly'),rows=[];const c=tx.objectStore('FILE_DATA').openCursor();c.onsuccess=()=>{const v=c.result;if(v){rows.push({key:v.key,mode:v.value.mode,contents:v.value.contents});v.continue();}else{db.close();Promise.all(rows.map(async item=>{let sha=null;if(item.contents){const bytes=item.contents instanceof Uint8Array?item.contents:new Uint8Array(item.contents);sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('');}return {key:item.key,mode:item.mode,sha};})).then(resolve,reject);}};c.onerror=()=>reject(c.error);};})"""
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  context=await browser.new_context(viewport={'width':640,'height':360},has_touch=True)
  page=await context.new_page();page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
  try:
   await boot(page,BASE+'/stable/');await interact(page);await wait(page,'window.lastDawnTelemetry.inventory.food===1')
   await button(page,'设置');await button(page,'极低');await button(page,'45');await button(page,'保存进度');await page.wait_for_timeout(7000)
   stable_before=await page.evaluate(READ_DB);check(any(x['key'].endswith('/survivor_v1.json') and x['sha'] for x in stable_before),'Stable game creates a real IndexedDB save before isolation test')
   await page.close();page=await context.new_page();page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
   d=await boot(page,BASE+'/test/')
   check(d['build']=='0.2.3-test' and 'LastDawnPhase2Test' in d['profile'],'Preview uses its actual separate OS user-data path',d.get('profile'))
   check(d['inventory']['food']==0 and d['target_fps']==30 and d['quality']==1,'Preview does not inherit stable save or graphics files')
   await button(page,'设置');await button(page,'120');await button(page,'保存进度');await page.wait_for_timeout(7000)
   check((await state(page))['target_fps']==120,'Preview can save independently with a different FPS cap')
   stable_after=await page.evaluate(READ_DB);check(stable_before==stable_after,'Preview writes leave every stable IndexedDB file and content hash unchanged')
   await page.close();page=await context.new_page();page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
   d=await boot(page,BASE+'/stable/',True)
   check(d['inventory']['food']==1 and d['target_fps']==45 and d['quality']==0,'Stable game still resumes original items/settings after preview writes')
   errors=[x for x in logs if x.startswith(('error:','PAGEERROR:')) or 'SCRIPT ERROR' in x];check(not errors,'Both actual exports run without JS/GDScript errors',errors)
  finally:
   (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader; same-origin real IndexedDB, NOT iPhone','checks':checks,'console':logs},ensure_ascii=False,indent=2));await browser.close()
asyncio.run(main())
