# 本轮环境与自动化事件（说明，不冒充遗失的原始stdout）

- 修复后Probe进程启动后，两次exec请求遇到`exec-server transport disconnected`，第二次提示`recovery timed out after 25s`。环境状态接口仍返回connected；读取原进程得到exit0，随后新的非login shell请求可用。Probe的实际JSON/日志已保存，未重装或切换Godot版本。
- 首次LSP客户端早于端口监听，得到`ConnectionRefusedError: [Errno 111] Connection refused`；之后ss确认Godot监听127.0.0.1:6023，重跑扫描55个脚本零诊断。最初lsp-scan.log被重跑覆盖，原失败工具输出在会话中；本文件是据该输出补记的事件说明。最终扫描原始JSON与stdout单独保留。
- browser-attempt1在实际路灯旁(约8.17,56.57)行走受阻。原始失败状态/截图/日志复制到browser-attempt1后才续跑。只调整Python行走路点，保持同一PCK与真实自动保存档，从traded检查点继续；未改碰撞/速度、注入资源或跳任务。
- 浏览器存储故障注入首轮的11项行为检查通过，但最终控制台检查失败：本地空白QA工具页请求/favicon.ico返回404。local-http.log中有对应请求。原始失败JSON/截图/日志保留在browser-storage-attempt1；仅给QA空白页加data: favicon，游戏文件不变，然后重跑这一专项。不得把首轮最后的失败改写为通过。
- 原包和本轮首次干净源码导入均可能有原有字体缓存bootstrap消息；保留导入日志。编辑器重导入和正式运行结果分别记录，不称首次导入零消息。
