#!/usr/bin/env python3
"""QA-023-01: final-build IndexedDB corruption injection in a COPY of the earned gameplay profile.
This is controlled browser-storage fault injection, not a user save or phone/Safari test.
"""
import asyncio,hashlib,json,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
from browser_helpers import boot,button,state,wait,save
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ['QA_BROWSER_OUTPUT']);OUT.mkdir(parents=True,exist_ok=True)
PROFILE=Path(os.environ['QA_BROWSER_PROFILE'])
URL=sys.argv[1].rstrip('/')+'/';TOOLS=sys.argv[2]
PCK_SHA=hashlib.sha256((ROOT/'export/web-static/index.pck').read_bytes()).hexdigest()
checks=[];logs=[]
READ="""()=>new Promise((resolve,reject)=>{const q=indexedDB.open('/userfs/LastDawnPhase2Test');q.onerror=()=>reject(q.error);q.onupgradeneeded=()=>{q.transaction.abort();reject(Error('Expected copied gameplay database'));};q.onsuccess=()=>{const db=q.result,tx=db.transaction('FILE_DATA','readonly'),store=tx.objectStore('FILE_DATA'),rows=[];const c=store.openCursor();c.onsuccess=()=>{const v=c.result;if(v){if(String(v.key).includes('survivor_v1.json'))rows.push({key:v.key,text:new TextDecoder().decode(v.value.contents)});v.continue();}else{db.close();resolve(rows);}};c.onerror=()=>reject(c.error);};})"""
WRITE="""({primary,backup})=>new Promise((resolve,reject)=>{const q=indexedDB.open('/userfs/LastDawnPhase2Test');q.onerror=()=>reject(q.error);q.onsuccess=()=>{const db=q.result,tx=db.transaction('FILE_DATA','readwrite'),store=tx.objectStore('FILE_DATA'),r=store.get('/userfs/LastDawnPhase2Test/survivor_v1.json');r.onsuccess=()=>{if(!r.result){tx.abort();reject(Error('No real earned primary save'));return;}for(const [suffix,text] of [['',primary],['.bak',backup]]){const row=structuredClone(r.result);row.contents=new TextEncoder().encode(text);row.timestamp=new Date();store.put(row,'/userfs/LastDawnPhase2Test/survivor_v1.json'+suffix);}};tx.oncomplete=()=>{db.close();resolve(true);};tx.onerror=()=>reject(tx.error);};})"""
def check(ok,label,data=None):
 checks.append({'passed':bool(ok),'name':label,'data':data});print(('PASS | ' if ok else 'FAIL | ')+label,flush=True)
 if not ok:raise AssertionError(label+': '+str(data))
def consistent(d,s):
 return d['inventory']==s['inventory'] and d['buildings']==s['phase2']['buildings'] and d['trader']['stock']==s['phase2']['trader']['stock'] and d['trader']['trades']==s['phase2']['trader']['trades'] and d['family']['stage']==s['phase2']['family']['stage'] and d['family']['reward_claimed']==s['phase2']['family']['reward_claimed'] and d['resources']['remaining']==s['resources']['remaining']
async def store(page,primary,backup):
 await page.goto(TOOLS,wait_until='load');await page.evaluate(WRITE,{'primary':primary,'backup':backup})
async def main():
 async with async_playwright() as p:
  context=await p.chromium.launch_persistent_context(str(PROFILE),executable_path='/usr/bin/chromium',headless=True,viewport={'width':640,'height':360},has_touch=True,is_mobile=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  for previous in list(context.pages):await previous.close()
  page=await context.new_page();page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
  try:
   r=await context.request.get(URL+'index.pck');check(r.ok and hashlib.sha256(await r.body()).hexdigest()==PCK_SHA,'Corruption test is bound to the final served PCK',PCK_SHA)
   await page.goto(TOOLS,wait_until='load');rows=await page.evaluate(READ);earned_text=next(x['text'] for x in rows if x['key'].endswith('/survivor_v1.json'));earned=json.loads(earned_text)
   check(len(earned['phase2']['buildings']['records'])==3 and earned['phase2']['trader']['trades']==4 and earned['phase2']['family']['reward_claimed'],'Copied profile contains the actually earned construction/trade/escort save')
   minimal=json.loads(earned_text);minimal['phase2']={'content_revision':1}
   await store(page,json.dumps(minimal),earned_text)
   d=await boot(page,URL,True)
   check(d['save_state']['error']=='已从备份恢复' and consistent(d,earned),'Revision-only corrupt primary falls back without losing earned items, buildings, trade or family progress',d['save_state'])
   await page.screenshot(path=str(OUT/'01-backup-recovery.png'));await save(page);await page.goto(TOOLS,wait_until='load');rows=await page.evaluate(READ)
   check(next(x['text'] for x in rows if x['key'].endswith('.bak'))==earned_text,'Saving the recovered browser session preserves the original valid backup bytes')
   primary=next(x['text'] for x in rows if x['key'].endswith('/survivor_v1.json'));latest=json.loads(primary)
   missing=json.loads(primary);del missing['phase2']['family']['reward_claimed']
   await store(page,json.dumps(missing),primary);d=await boot(page,URL,True)
   check(d['save_state']['error']=='已从备份恢复' and consistent(d,latest),'Missing reward-claimed field uses backup instead of allowing reward replay')
   for i in range(2):
    d=await boot(page,URL,True);check(consistent(d,latest),'Repeated browser reload preserves exact earned counts and claimed task #'+str(i+1))
   await store(page,json.dumps(minimal),'{broken')
   await page.goto(URL,wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry.modal==="welcome"');await button(page,'继续本机存档');d=await state(page)
   check(d['modal']=='welcome' and '已损坏' in d['save_state']['error'],'Two invalid files cannot be loaded as a new empty success',d['save_state'])
   await page.goto(TOOLS,wait_until='load');after=await page.evaluate(READ)
   check(next(x['text'] for x in after if x['key'].endswith('/survivor_v1.json'))==json.dumps(minimal) and next(x['text'] for x in after if x['key'].endswith('.bak'))=='{broken','Failed browser load leaves both corrupted files untouched for diagnosis')
   future=json.loads(primary);future['version']=4;future_text=json.dumps(future)
   await store(page,future_text,primary)
   await page.goto(URL,wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry.modal==="welcome"');await button(page,'继续本机存档');d=await state(page)
   check(d['modal']=='welcome' and '版本较新' in d['save_state']['error'],'Future-version primary is protected even with a valid older backup',d['save_state'])
   await page.goto(TOOLS,wait_until='load');after=await page.evaluate(READ);check(next(x['text'] for x in after if x['key'].endswith('/survivor_v1.json'))==future_text,'Protected browser future file remains byte-for-byte intact')
   # Restore only this copied QA profile to its earned state for later examination.
   await store(page,primary,earned_text)
   errors=[x for x in logs if x.startswith(('error:','PAGEERROR:')) or 'SCRIPT ERROR' in x]
   check(not errors,'Final Web storage-fault runs have no JavaScript/GDScript errors',errors)
  except Exception:
   await page.screenshot(path=str(OUT/'failure.png'));raise
  finally:
   (OUT/'results.json').write_text(json.dumps({'task':'QA-023-01','pck_sha256':PCK_SHA,'environment':'Linux Chromium / SwiftShader, real copied IndexedDB with controlled corruption; NOT Safari/phone','checks':checks,'console':logs},ensure_ascii=False,indent=2));await context.close()
asyncio.run(main())
