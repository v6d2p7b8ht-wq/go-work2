#!/usr/bin/env python3
"""Read-only render/storage diagnostics plus real GUI actions. No production debug commands."""
import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'tests/quality-results/browser';OUT.mkdir(parents=True,exist_ok=True)
URL=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8770').rstrip('/')
checks=[];logs=[];samples=[]
def check(ok,name,data=None):
 checks.append({'passed':bool(ok),'name':name,'data':data});print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
 if not ok:raise AssertionError(name+': '+str(data))
async def wait(page,js):await page.wait_for_function(js,timeout=60000,polling=250)
async def state(page):return await page.evaluate('window.lastDawnTelemetry')
async def perf(page):return await page.evaluate('window.lastDawnPerformance')
async def button(page,prefix):
 d=await state(page);b=next((x for x in d['buttons'] if x['text'].startswith(prefix)),None)
 if not b:raise AssertionError('No button '+prefix)
 rect=await page.locator('#canvas').bounding_box();x,y,w,h=b['rect']
 await page.touchscreen.tap(rect['x']+(x+w/2)*rect['width']/d['viewport'][0],rect['y']+(y+h/2)*rect['height']/d['viewport'][1]);await page.wait_for_timeout(1000)
async def boot(page):
 await page.goto(URL,wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry && window.lastDawnPerformance && window.lastDawnTelemetry.modal === "welcome"');await button(page,'进入灰松郊区')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
  context=await browser.new_context(viewport={'width':640,'height':360},has_touch=True)
  page=await context.new_page();page.on('console',lambda m:logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:logs.append('PAGEERROR: '+str(e)))
  try:
   await boot(page);await button(page,'设置')
   for quality,(name,scale) in enumerate(zip(['极低','低','中','高','极致'],[.55,.67,.8,1,1.1])):
    await button(page,name);await wait(page,'window.lastDawnPerformance.quality === '+str(quality));d=await perf(page)
    check(abs(d['scale_3d']-scale)<.001,'Web quality '+str(quality)+' applies actual viewport scale',d['scale_3d'])
   for cap in [30,45,60,90,120]:
    await button(page,str(cap));await wait(page,'window.lastDawnPerformance.engine_max_fps === '+str(cap));check((await state(page))['target_fps']==cap,'Web FPS GUI applies actual cap '+str(cap))
   await button(page,'极低');await button(page,'×');await page.wait_for_timeout(5000)
   d=await perf(page);check(d['storage_persistent'],'Normal browser reports persistent userfs available')
   cdp=await context.new_cdp_session(page);await cdp.send('Performance.enable')
   for i in range(8):
    await page.wait_for_timeout(2500)
    d=await perf(page);metrics=await cdp.send('Performance.getMetrics')
    js={m['name']:m['value'] for m in metrics['metrics'] if m['name'] in ['JSHeapUsedSize','JSHeapTotalSize','Nodes','Documents']}
    samples.append({'game':d,'chromium_metrics':js,'scope':'JS heap excludes full WASM/GPU/process memory; render metrics are Godot estimates'})
   check(all(x['game']['render']['mean_ms']>0 and x['game']['engine_max_fps']==120 for x in samples),'20-second gameplay sample has real frame times under target 120')
   check(all(x['game']['display_refresh_hz']<0 for x in samples),'No synthetic screen refresh rate is reported on Web')
   check(all(x['game']['static_memory_bytes']==-1 or x['game']['static_memory_bytes']>0 for x in samples),'Unavailable native allocator memory is labelled unknown')
   before=(await perf(page))['node_count']
   for i in range(5):await button(page,'设置');await button(page,'×')
   await page.wait_for_timeout(2500);after=(await perf(page))['node_count']
   if before>0 and after>0:check(after<=before+2,'Repeated settings open/close has no retained Node growth',{'before':before,'after':after})
   else:check(True,'Release export does not expose a reliable Node counter; no leak-free claim',{'before':before,'after':after})
   resources=await page.evaluate("performance.getEntriesByType('resource').filter(x=>/index\\.(pck|js)|wasm/.test(x.name)).map(x=>({name:new URL(x.name).pathname,transfer:x.transferSize,encoded:x.encodedBodySize,duration_ms:x.duration}))")
   check(any(x['name'].endswith('index.pck') for x in resources) and any('wasm' in x['name'] for x in resources),'Actual PCK and compressed WASM resource loads are recorded',resources)
   await page.screenshot(path=str(OUT/'normal-game.png'))
   errors=[x for x in logs if x.startswith('error:') or x.startswith('PAGEERROR:') or 'SCRIPT ERROR' in x]
   check(not errors,'No runtime errors during quality/performance/menu checks',errors)
   await context.close()
   # Independent failure injection; no player's storage or production source is touched.
   context=await browser.new_context(viewport={'width':640,'height':360},has_touch=True)
   await context.add_init_script("Object.defineProperty(window,'indexedDB',{configurable:true,get(){return {open(){throw new DOMException('QA injected storage denial','SecurityError')}}}})")
   page=await context.new_page();denial_logs=[];page.on('console',lambda m:denial_logs.append(m.type+': '+m.text));page.on('pageerror',lambda e:denial_logs.append('PAGEERROR: '+str(e)))
   await boot(page);await wait(page,'window.lastDawnPerformance.storage_persistent === false')
   check(not (await perf(page))['storage_persistent'],'Injected IndexedDB denial is detected without inferring private mode')
   await button(page,'设置');await button(page,'保存进度');await page.wait_for_timeout(1000)
   d=await state(page);check(not d['save_state']['exists'] and '存储不可用' in d['save_state']['error'],'Denied storage explicitly rejects save and reports the reason',d['save_state'])
   await page.screenshot(path=str(OUT/'storage-denial.png'))
   # On reload no misleading persistent snapshot is advertised.
   await page.reload(wait_until='networkidle');await page.locator('#start').click();await wait(page,'window.lastDawnTelemetry && window.lastDawnTelemetry.modal === "welcome"')
   check(not any(x['text'].startswith('继续本机存档') for x in (await state(page))['buttons']),'Storage-denied save does not falsely survive a page reload')
   fatal=[x for x in denial_logs if x.startswith('PAGEERROR:') or 'SCRIPT ERROR' in x]
   check(not fatal,'Expected IndexedDB denial produces no GDScript/JavaScript crash',denial_logs)
   check(True,'Storage denial is a synthetic browser test; Safari private-mode behaviour is unverified')
   (OUT/'resource-loads.json').write_text(json.dumps(resources,indent=2));(OUT/'storage-denial-console.log').write_text('\n'.join(denial_logs))
  finally:
   (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader software WebGL; NOT Android/iPhone; IndexedDB denial injected','checks':checks,'samples':samples,'console':logs},ensure_ascii=False,indent=2));await browser.close()
asyncio.run(main())
