#!/usr/bin/env bash
set -eu
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
log_dir="$project_dir/tests/logs/phase2-batch1"
mkdir -p "$log_dir"
XDG_DATA_HOME=/tmp/last-dawn-batch1-import godot --headless --rendering-method gl_compatibility --path "$project_dir" --editor --import > "$log_dir/import.log" 2>&1
for suite in SurvivalStateTests ZombieCombatTests BatchOneTests TestRunner TouchInputTests; do
  XDG_DATA_HOME="/tmp/last-dawn-batch1-$suite" godot --headless --rendering-method gl_compatibility --path "$project_dir" "res://tests/$suite.tscn" -- --test > "$log_dir/$suite.log" 2>&1
  rg 'RESULT' "$log_dir/$suite.log"
done
