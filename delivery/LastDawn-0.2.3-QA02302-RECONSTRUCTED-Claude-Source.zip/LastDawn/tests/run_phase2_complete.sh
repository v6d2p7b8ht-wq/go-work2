#!/usr/bin/env bash
set -eu
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
bash "$project_dir/tests/run_quality_audit.sh"
for suite in BuildingTests TradingEnvironmentTests FamilyTests MobileBudgetTests ContentRegressionTests SaveIntegrityTests SessionGuardTests FamilyIncapacitationGateTests; do
 python3 "$project_dir/tests/run_qa_suite.py" "$suite"
done
