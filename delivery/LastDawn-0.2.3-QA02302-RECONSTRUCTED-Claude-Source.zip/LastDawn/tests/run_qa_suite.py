#!/usr/bin/env python3
"""Isolated Godot runner: retain each exit code, reject FAIL/script errors, never count old logs."""
import argparse,json,os,re,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('suite');a=p.parse_args()
root=Path(__file__).resolve().parents[1]
logs=Path(os.environ.get('QA_LOG_ROOT',str(root/'tests/qa-current'))).resolve();logs.mkdir(parents=True,exist_ok=True)
profiles=Path(os.environ.get('QA_PROFILE_ROOT',str(logs/'profiles'))).resolve()
env=os.environ.copy();env['XDG_DATA_HOME']=str(profiles/a.suite)
base=['godot','--headless','--rendering-method','gl_compatibility','--path',str(root)]
status_path=logs/'suite-status.json';status=json.loads(status_path.read_text()) if status_path.exists() else {}
def execute(name,cmd):
 log=logs/(name+'.log');started=time.time()
 try:
  with log.open('w') as f:r=subprocess.run(cmd,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  code=r.returncode
 except subprocess.TimeoutExpired:code=124
 text=log.read_text(errors='replace');errors=re.findall(r'^(?:SCRIPT ERROR:|ERROR:|FAIL\s*\|).*$',text,re.M)
 results=re.findall(r'^RESULT \| (\d+).*?\b(\d+) failures',text,re.M)
 entry={'exit_code':code,'seconds':round(time.time()-started,3),'log':log.name,'errors':errors,'results':[{'checks':int(c),'failures':int(n)} for c,n in results]}
 status[name]=entry;status_path.write_text(json.dumps(status,ensure_ascii=False,indent=2))
 return entry,text
if a.suite=='import':
 e,text=execute('import',base+['--editor','--import'])
 if e['exit_code']==0 and e['errors']:
  # Fresh source has the pre-existing font-cache bootstrap warning; keep first log, retry once.
  e,text=execute('import-second',base+['--editor','--import'])
 ok=e['exit_code']==0 and not e['errors']
elif a.suite=='static':
 e,text=execute('static',[sys.executable,str(root/'tests/fps_static_checks.py')])
 ok=e['exit_code']==0 and not e['errors'] and len(e['results'])==1 and e['results'][0]['failures']==0
else:
 e,text=execute(a.suite,base+[f'res://tests/{a.suite}.tscn','--','--test'])
 ok=e['exit_code']==0 and not e['errors'] and len(e['results'])==1 and e['results'][0]['failures']==0
for line in text.splitlines():
 if line.startswith(('RESULT','SCRIPT ERROR','ERROR:','FAIL |')):print(line)
print(f"SUITE_EXIT | {a.suite} | {e['exit_code']} | clean={ok}",flush=True)
sys.exit(0 if ok else 1)
