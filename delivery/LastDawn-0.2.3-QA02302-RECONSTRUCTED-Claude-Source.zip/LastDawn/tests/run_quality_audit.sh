#!/usr/bin/env bash
set -eu
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$project_dir/tests/run_qa_suite.py" import
for suite in SurvivalStateTests ZombieCombatTests BatchOneTests TestRunner TouchInputTests PerformanceTests QualityRegressionTests CollisionQualityTests; do
  python3 "$project_dir/tests/run_qa_suite.py" "$suite"
done
python3 "$project_dir/tests/run_qa_suite.py" static
