#!/usr/bin/env bash
set -eu
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
test_data_dir="${TMPDIR:-/tmp}/last-dawn-tests"
mkdir -p "$test_data_dir"
XDG_DATA_HOME="$test_data_dir" godot --headless --rendering-method gl_compatibility --path "$project_dir" --editor --import
XDG_DATA_HOME="$test_data_dir" godot --headless --rendering-method gl_compatibility --path "$project_dir" res://tests/TestRunner.tscn -- --test
