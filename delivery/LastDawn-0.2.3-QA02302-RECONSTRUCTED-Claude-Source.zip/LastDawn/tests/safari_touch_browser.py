#!/usr/bin/env python3
"""Chromium mobile-emulation checks for Web touch plumbing. Not an iPhone/Safari device test."""
import asyncio,json,math,sys,os,hashlib
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ.get('QA_BROWSER_OUTPUT',str(ROOT/'tests/safari-results')))
OUT.mkdir(parents=True,exist_ok=True)
URL=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8770'
checks=[];logs=[]
PCK_SHA=hashlib.sha256((ROOT/'export/web-static/index.pck').read_bytes()).hexdigest()
def check(ok,name,detail=None):
    checks.append({'passed':bool(ok),'name':name,'detail':detail})
    print(('PASS | ' if ok else 'FAIL | ')+name,flush=True)
    if not ok: raise AssertionError(str(detail))
async def wait(page,js):
    await page.wait_for_function(js,timeout=60000,polling=150)
async def state(page): return await page.evaluate('window.lastDawnTelemetry')
async def debug(page): return await page.evaluate('window.lastDawnTouchDebug')
async def pause(page): await page.wait_for_timeout(850)
async def button(page,prefix):
    data=await state(page)
    item=next((b for b in data['buttons'] if b['text'].startswith(prefix)),None)
    if not item: raise AssertionError('Missing button '+prefix+': '+str(data['buttons']))
    rect=await page.locator('#canvas').bounding_box();x,y,w,h=item['rect']
    await page.touchscreen.tap(rect['x']+(x+w/2)*rect['width']/data['viewport'][0],rect['y']+(y+h/2)*rect['height']/data['viewport'][1])
    await pause(page)
async def boot(page):
    await page.goto(URL,wait_until='networkidle')
    await page.locator('#start').click()
    await wait(page,'window.lastDawnTelemetry && window.lastDawnTelemetry.modal === "welcome"')
    await button(page,'进入灰松郊区')
    await wait(page,'window.lastDawnTelemetry.modal === "" && window.lastDawnTelemetry.on_floor')
    await button(page,'设置')
    await button(page,'触控调试')
    await wait(page,'window.lastDawnTouchDebug != null')
    await button(page,'×')
    await wait(page,'window.lastDawnTelemetry.modal === ""')
async def touch(session,kind,points):
    await session.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':points})
async def swipe(page,session,dx,dy=0,ident=4):
    p={'id':ident,'x':500,'y':170}
    await touch(session,'touchStart',[p]);await pause(page)
    before=await debug(page)
    await touch(session,'touchMove',[dict(p,x=p['x']+dx,y=p['y']+dy)])
    await pause(page);after=await debug(page)
    await touch(session,'touchEnd',[]);await pause(page)
    return before,after
def diff(a,b): return (b-a+math.pi)%(2*math.pi)-math.pi

async def main():
    async with async_playwright() as p:
        request=await p.request.new_context()
        response=await request.get(URL.rstrip('/')+'/index.pck')
        served_sha=hashlib.sha256(await response.body()).hexdigest()
        assert response.ok and served_sha==PCK_SHA,'Touch regression must use the final QA PCK'
        await request.dispose()
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        def record(message):
            logs.append(message);(OUT/'console.log').write_text('\n'.join(logs))
        try:
            results=[]
            for dpr in [3,1]:
                context=await browser.new_context(viewport={'width':844,'height':390},device_scale_factor=dpr,has_touch=True,is_mobile=True)
                page=await context.new_page()
                page.on('console',lambda m:record(m.type+': '+m.text))
                page.on('pageerror',lambda e:record('PAGEERROR: '+str(e)))
                session=await context.new_cdp_session(page)
                await boot(page)
                before,after=await swipe(page,session,50)
                expected=-50*before['viewport'][1]/390*before['sensitivity']
                observed=diff(before['yaw'],after['yaw'])
                check(abs(observed-expected)<.012,f'DPR {dpr}: right swipe matches one viewport-unit conversion',{'expected':expected,'observed':observed,'debug':after})
                results.append(observed)
                if dpr==1:
                    await context.close();continue
                check(after['browser']['backing']==[1266,585] and after['browser']['dpr']==3,'DPR 3 backing-store cap is independent of input sensitivity',after['browser'])
                before,after=await swipe(page,session,-50)
                check(diff(before['yaw'],after['yaw'])>0,'Left swipe turns in the opposite horizontal direction')
                before,after=await swipe(page,session,0,30)
                check(abs(after['pitch']-before['pitch']+30*before['viewport'][1]/390*before['sensitivity'])<.015,'Down swipe has the expected pitch sign and magnitude')
                before,after=await swipe(page,session,0,-30)
                check(after['pitch']>before['pitch'],'Up swipe reverses the pitch direction')
                stick={'id':1,'x':74,'y':320};look={'id':8,'x':500,'y':170}
                await touch(session,'touchStart',[stick]);await pause(page)
                stick=dict(stick,y=290)
                await touch(session,'touchMove',[stick])
                await touch(session,'touchStart',[stick,look]);await pause(page)
                value=await debug(page)
                roles={x['purpose'] for x in value['pointers']}
                check(value['count']==2 and roles=={'joystick','look'},'Two active browser touches have separate joystick and camera roles',value)
                # CDP touchEnd lists the fingers to end (changedTouches), not those remaining.
                await touch(session,'touchEnd',[stick]);await pause(page)
                value=await debug(page)
                check(value['count']==1 and value['pointers'][0]['purpose']=='look','Alternating release leaves the other camera finger intact',value)
                await touch(session,'touchEnd',[]);await pause(page)
                before=await debug(page)
                for _ in range(5):
                    await touch(session,'touchStart',[{'id':4,'x':500,'y':170}])
                    await touch(session,'touchMove',[{'id':4,'x':560,'y':170}])
                    await touch(session,'touchEnd',[])
                    await page.wait_for_timeout(250)
                await pause(page);after=await debug(page)
                expect_angle=-5*60*before['viewport'][1]/390*before['sensitivity']
                check(abs(diff(before['yaw'],after['yaw'])-expect_angle)<.025,'Fast repeated browser swipes integrate once without index reassignment',after)
                await touch(session,'touchStart',[look]);await pause(page)
                before=await debug(page)
                await page.set_viewport_size({'width':844,'height':350});await pause(page)
                await touch(session,'touchMove',[dict(look,x=510)])
                await pause(page);after=await debug(page)
                check(after['count']==0 and abs(diff(before['yaw'],after['yaw']))<.001,'Held finger cannot rotate after an actual viewport size change',after)
                await touch(session,'touchEnd',[])
                await page.set_viewport_size({'width':844,'height':390});await pause(page)
                await touch(session,'touchStart',[look]);await pause(page);before=await debug(page)
                await page.evaluate("Object.defineProperty(window.visualViewport,'offsetTop',{configurable:true,value:12});window.visualViewport.dispatchEvent(new Event('scroll'))")
                await pause(page)
                await touch(session,'touchMove',[dict(look,x=510)])
                await pause(page);after=await debug(page)
                check(after['count']==0 and abs(diff(before['yaw'],after['yaw']))<.001,'Synthetic VisualViewport toolbar-offset change clears stale touch baselines',after)
                await touch(session,'touchEnd',[])
                await page.evaluate("delete window.visualViewport.offsetTop;window.visualViewport.dispatchEvent(new Event('scroll'))")
                await pause(page)
                for event_name in ['orientationchange','blur','pagehide','pageshow']:
                    await touch(session,'touchStart',[look]);await pause(page);before=await debug(page)
                    await page.evaluate('(name)=>window.dispatchEvent(new Event(name))',event_name)
                    await pause(page)
                    await touch(session,'touchMove',[dict(look,x=510)])
                    await pause(page);after=await debug(page)
                    check(after['count']==0 and abs(diff(before['yaw'],after['yaw']))<.001,'Synthetic '+event_name+' clears gestures without a camera jump',after)
                    await touch(session,'touchEnd',[])
                await touch(session,'touchStart',[look]);await pause(page)
                await touch(session,'touchCancel',[]);await pause(page)
                check((await debug(page))['count']==0,'Actual browser touchCancel leaves no active ownership')
                before=await debug(page)
                await page.dispatch_event('#hint' if await page.locator('#hint').count() else 'body','touchmove',{'bubbles':True,'cancelable':True})
                await pause(page);after=await debug(page)
                check(abs(diff(before['yaw'],after['yaw']))<.001,'Touch outside the game canvas does not produce camera rotation')
                await button(page,'设置')
                value=await debug(page);check(value['count']==0,'UI button tap opens settings without becoming a camera gesture')
                await button(page,'上下方向')
                await wait(page,'window.lastDawnTouchDebug.invert_y === true')
                await button(page,'×')
                before,after=await swipe(page,session,0,20)
                check(after['pitch']>before['pitch'],'Invert Y option changes vertical direction through the real touch UI')
                await button(page,'设置');await button(page,'上下方向');await button(page,'×')
                await page.screenshot(path=str(OUT/'touch-debug-dpr3.png'))
                await context.close()
            check(abs(results[0]-results[1])<.012,'Same CSS swipe at DPR 1 and DPR 3 produces the same camera angle',results)
            errors=[x for x in logs if x.startswith('error:') or x.startswith('PAGEERROR:') or 'SCRIPT ERROR' in x]
            check(not errors,'No JavaScript/GDScript runtime errors during the targeted browser run',errors)
        finally:
            (OUT/'results.json').write_text(json.dumps({'environment':'Linux Chromium / SwiftShader mobile emulation; no physical iPhone; VisualViewport/lifecycle events are synthetic','pck_sha256':PCK_SHA,'served_pck_sha256':served_sha,'checks':checks,'console':logs},ensure_ascii=False,indent=2))
            await browser.close()

asyncio.run(main())
