#!/usr/bin/env python3
"""Expand only the existing OFL font subset; do not regenerate world art or audio."""
from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
ROOT=Path(__file__).resolve().parents[1]
destination=ROOT/'assets/fonts/LastDawnSans.ttf'
source=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if not source.exists():raise SystemExit('Developer build requires the Debian Noto CJK source font (OFL). Players need no tooling.')
previous=TTFont(destination);codepoints=set(previous.getBestCmap());previous.close()
for folder in ['scripts','systems','ui','data']:
    for file in (ROOT/folder).rglob('*'):
        if file.is_file() and file.suffix in ('.gd','.json'):
            codepoints.update(ord(c) for c in file.read_text())
codepoints.update(ord(c) for c in (ROOT/'export/performance_probe.js').read_text())
font=TTFont(source,fontNumber=2)
options=subset.Options();options.layout_features=['kern','liga']
tool=subset.Subsetter(options=options);tool.populate(unicodes=codepoints);tool.subset(font)
for entry in font['name'].names:
    if entry.nameID in (1,4,6,16):
        value='LastDawnSans-Regular' if entry.nameID==6 else 'Last Dawn Sans'
        entry.string=value.encode(entry.getEncoding(),errors='replace')
font.save(destination)
print('Expanded UI font:',destination.stat().st_size,'bytes')
