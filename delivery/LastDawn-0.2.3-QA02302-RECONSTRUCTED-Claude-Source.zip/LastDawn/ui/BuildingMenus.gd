class_name BuildingMenus
extends RefCounted

static func show(hud: SurvivalHUD) -> void:
	hud._open("building","野外建造 / FIELD CRAFT","选好后在前方预览：绿色可建，红色不可建；交互确认，再点建造可取消。")
	hud._paragraph("已建造 %d / %d · 公路和公共营地禁止放置。避难所内部可休息，围墙有实体碰撞，篝火可点燃或熄灭。" % [hud.world.buildings.records.size(),BuildingSystem.LIMIT],20)
	for id in BuildingSystem.TYPES:
		var kind: String = id
		var spec: Dictionary = BuildingSystem.TYPES[id]
		hud.content.add_child(hud._button("选择"+spec["name"]+" · "+cost_text(spec["cost"]),func(): hud.call_deferred("begin_building",kind)))
	hud.content.add_child(hud._button("返回游戏",hud.close_modal,true))

static func cost_text(cost: Dictionary) -> String:
	var parts: Array[String] = []
	for id in cost: parts.append("%s%d" % [InventorySystem.ITEMS[id]["name"],cost[id]])
	return " / ".join(parts)
