class_name QuestMenus
extends RefCounted
static func show(hud: SurvivalHUD) -> void:
	var quest: FamilyQuest = hud.world.family
	var alive: bool = hud.world.player.survival.alive()
	var labels := {"not_started":"尚未接应","following":"正在跟随","waiting":"原地等待","evacuated":"撤离完成"}
	hud._open("family","家人撤离 / BRING HER HOME","一名家人、一次营地撤离。家人不会穿墙传送，走散时会留在地图中等待。")
	hud._paragraph("小雨 · "+labels[quest.stage],27)
	hud._paragraph("家人位置 %.0f, %.0f · 距离 %.0f 米" % [quest.member.position.x,quest.member.position.z,quest.member.position.distance_to(hud.world.player.position)],21)
	if quest.stage=="not_started":
		hud._paragraph("「我在修车厂西侧等你。一起走到东侧营地里面，别只停在围栏外。」\n沿营地北面开口进入，目标大约为 20, 35；保持步行，小雨离得太远会等待。",22)
	if quest.stage in ["not_started","waiting"]:
		var follow: Button = hud._button("跟我去安全区",func(): hud.call_deferred("family_follow"),true)
		follow.disabled = not quest.in_range() or not alive
		hud.content.add_child(follow)
	elif quest.stage=="following":
		hud._paragraph("带小雨和自己都进入营地深处，保持相距七米以内并停留两秒。左侧避难所不算撤离终点。",21)
		var wait: Button = hud._button("在这里等我",func():
			quest.wait_here()
			hud.call_deferred("show_family")
		)
		wait.disabled = not quest.in_range() or not alive
		hud.content.add_child(wait)
	else:
		hud._paragraph("小雨已留在营地，任务不会重复发放奖励。",22)
		if not quest.reward_claimed:
			var claim: Button = hud._button("领取撤离补给",func():
				quest.claim_reward()
				hud.call_deferred("show_family")
			)
			claim.disabled = not alive
			hud.content.add_child(claim)
	hud.status_note = hud._paragraph(quest.last_message if not quest.last_message.is_empty() else "撤离奖励：食品2 / 饮水2，行囊满时可稍后领取。",19)
	hud.content.add_child(hud._button("返回游戏",hud.close_modal,true))
