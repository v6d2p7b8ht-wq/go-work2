class_name SurvivalHUD
extends Control
const ORANGE := Color("d8a66f")
const IVORY := Color("e5e4ce")
const MUTED := Color("9aaea5")
var world: Node3D
var controls: MobileControls
var brand: Label
var fps_label: Label
var compass: Label
var status: Label
var objective: Label
var context: Label
var toast_label: Label
var stamina_bar: ProgressBar
var inventory_button: Button
var settings_button: Button
var build_button: Button
var quest_button: Button
var shade: ColorRect
var modal: PanelContainer
var content: VBoxContainer
var close_button: Button
var status_note: Label
var touch_debug_panel: TouchDebugPanel
var current_modal := ""
var toast_time := 0.0
var refresh_clock := 0.0
var damage_flash: ColorRect
var flash_time := 0.0
var performance_readout: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	theme = Theme.new()
	theme.default_font = load("res://assets/fonts/LastDawnSans.ttf")
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	controls = MobileControls.new()
	add_child(controls)
	brand = _label("L D   /   末日十州\nLAST DAWN  ·  TEN STATES", 27)
	add_child(brand)
	fps_label = _label("FPS  —", 22, ORANGE)
	add_child(fps_label)
	compass = _label("N   ·   000°", 20)
	compass.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(compass)
	status = _label("生命 100   /   体力 100", 20, IVORY)
	add_child(status)
	stamina_bar = ProgressBar.new()
	stamina_bar.show_percentage = false
	stamina_bar.max_value = 100
	var bar_background := _style(Color(0.07, 0.13, 0.13, 0.65), Color(0.15, 0.22, 0.21), 0, 2)
	var bar_fill := _style(Color("9aa980"), Color.TRANSPARENT, 0, 2)
	for bar_style in [bar_background, bar_fill]:
		bar_style.content_margin_top = 0
		bar_style.content_margin_bottom = 0
	stamina_bar.add_theme_stylebox_override("background", bar_background)
	stamina_bar.add_theme_stylebox_override("fill", bar_fill)
	add_child(stamina_bar)
	objective = _label("01  /  灰松郊区\n寻找补给，前往东侧安全区", 19, MUTED)
	add_child(objective)
	inventory_button = _button("背包  0", show_inventory, false)
	settings_button = _button("设置", show_settings, false)
	add_child(inventory_button)
	add_child(settings_button)
	build_button = _button("建造",show_building)
	add_child(build_button)
	quest_button = _button("任务",show_family)
	add_child(quest_button)
	context = _label("", 24, IVORY)
	context.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(context)
	toast_label = _label("", 22, ORANGE)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(toast_label)
	shade = ColorRect.new()
	shade.color = Color(0.018, 0.045, 0.048, 0.67)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.visible = false
	add_child(shade)
	damage_flash = ColorRect.new()
	damage_flash.color = Color(0.5, 0.05, 0.02, 0)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	damage_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(damage_flash)
	controls.ui_hit_test = _touch_over_ui
	touch_debug_panel = TouchDebugPanel.new()
	touch_debug_panel.manager = controls.touch_manager
	touch_debug_panel.rig = world.player.rig
	add_child(touch_debug_panel)
	resized.connect(_layout)
	InventorySystem.changed.connect(_inventory_changed)
	SaveManager.completed.connect(_save_result)
	controls.inventory_requested.connect(show_inventory)
	controls.settings_requested.connect(show_settings)
	controls.save_requested.connect(func(): SaveManager.save_world(world))
	controls.load_requested.connect(func(): SaveManager.load_world(world))
	_layout()

func _label(text: String, size_px: int = 22, color: Color = IVORY) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size_px)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0.02, 0.05, 0.05, 0.85))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 2)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _style(fill: Color, border: Color, width: int = 1, corner: int = 7) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(corner)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style

func _button(text: String, action: Callable, accent: bool = false) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(108, 53)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 22)
	button.add_theme_color_override("font_color", IVORY)
	button.add_theme_stylebox_override("normal", _style(Color("344a43") if accent else Color(0.06, 0.12, 0.13, 0.88), ORANGE if accent else Color("495c54")))
	button.add_theme_stylebox_override("hover", _style(Color("3b5046"), ORANGE))
	button.add_theme_stylebox_override("pressed", _style(Color("5a6249"), ORANGE, 2))
	button.add_theme_stylebox_override("focus", _style(Color(0, 0, 0, 0), ORANGE, 2))
	button.pressed.connect(action)
	return button

func _layout() -> void:
	if not is_instance_valid(brand):
		return
	var safe := controls.safe_margins()
	brand.position = Vector2(safe.x + 12, safe.y + 8)
	brand.size = Vector2(400, 75)
	var narrow := size.x < 1000
	brand.text = "末日十州 / LAST DAWN" if narrow else "L D   /   末日十州\nLAST DAWN  ·  TEN STATES"
	brand.add_theme_font_size_override("font_size", 25 if narrow else 27)
	settings_button.position = Vector2(size.x - safe.z - 120, safe.y + 14)
	settings_button.size = Vector2(108, 54)
	inventory_button.position = Vector2(size.x - safe.z - 248, safe.y + 14)
	inventory_button.size = Vector2(116, 54)
	build_button.position = Vector2(safe.x+12,safe.y+(324 if narrow else 310))
	build_button.size = Vector2(130,52)
	quest_button.position = Vector2(safe.x+154,safe.y+(324 if narrow else 310))
	quest_button.size = Vector2(108,52)
	fps_label.position = Vector2(size.x - safe.z - 475, safe.y + 27)
	fps_label.size = Vector2(215, 35)
	compass.position = Vector2(size.x * 0.5 - 105, safe.y + 22)
	compass.size = Vector2(210, 35)
	status.position = Vector2(safe.x + 12, safe.y + 98)
	status.size = Vector2(460, 58)
	stamina_bar.position = Vector2(safe.x + 12, safe.y + 157)
	stamina_bar.size = Vector2(248, 5)
	objective.position = Vector2(safe.x + 12, safe.y + 178)
	objective.size = Vector2(460, 100)
	if narrow:
		brand.size = Vector2(390, 43)
		fps_label.position = Vector2(safe.x + 12, safe.y + 73)
		compass.position = Vector2(size.x - safe.z - 232, safe.y + 86)
		status.position.y = safe.y + 119
		stamina_bar.position.y = safe.y + 181
		objective.position.y = safe.y + 204
	context.position = Vector2(size.x * 0.5 - 320, size.y - safe.w - 74)
	context.size = Vector2(640, 40)
	if narrow:
		context.position.x = safe.x + 8
		context.size.x = size.x - safe.x - safe.z - 16
	toast_label.position = Vector2(size.x * 0.5 - 390, safe.y + 103)
	toast_label.size = Vector2(780, 40)
	if is_instance_valid(modal):
		modal.size = Vector2(minf(850, size.x - safe.x - safe.z - 60), minf(600, size.y - safe.y - safe.w - 48))
		modal.position = (size - modal.size) * 0.5
		if is_instance_valid(close_button):
			close_button.size = Vector2(50, 50)
			close_button.position = modal.position + Vector2(modal.size.x - 70, 16)

func _process(delta: float) -> void:
	flash_time = maxf(0, flash_time - delta)
	damage_flash.color.a = flash_time * 0.5 if current_modal.is_empty() else 0.0
	toast_time -= delta
	toast_label.visible = toast_time > 0 and current_modal.is_empty()
	refresh_clock -= delta
	if refresh_clock > 0 or world == null or world.player == null:
		return
	refresh_clock = 0.25
	build_button.text = "取消建造" if not world.buildings.selected.is_empty() else "建造"
	if is_instance_valid(performance_readout):
		performance_readout.text = PerformanceDiagnostics.summary_text()
	var fps := Engine.get_frames_per_second()
	fps_label.text = "FPS %d  /  目标 %d" % [fps, GraphicsManager.target_fps]
	fps_label.add_theme_color_override("font_color", Color("a4c3a2") if fps >= GraphicsManager.target_fps * 0.8 else ORANGE)
	var heading := wrapf(-rad_to_deg(world.player.rig.yaw), 0, 360)
	compass.text = "%s   ·   %03d°" % [_direction(heading), int(heading)]
	var safe_zone: bool = world.is_safe(world.player.position)
	var survival: SurvivalSystem = world.player.survival
	status.text = "生命 %d · 体力 %d%s\n饱食 %d · 饮水 %d" % [ceili(survival.health), int(world.player.stamina), " · 安全" if safe_zone else "", ceili(survival.hunger), ceili(survival.thirst)]
	status.add_theme_color_override("font_color", ORANGE if survival.health < 35 or survival.hunger < 20 or survival.thirst < 20 else IVORY)
	stamina_bar.value = world.player.stamina
	var warning := ""
	for zombie in world.zombies:
		if zombie.state == ZombieAI.State.CHASE or zombie.state == ZombieAI.State.ATTACK:
			warning = "感染者接近 / 攻击 · 拉开距离，返回安全区"
			break
	context.text = warning if not warning.is_empty() else world.interaction_text
	objective.text = "灰松郊区 · 感染等级 %d\n%s\n%s" % [world.infection.level_at(world.player.position),world.clock.display_time(),"已联系守望者 · 自由探索" if world.talked_to_npc else "寻找补给，前往东侧安全区"]
	if world.family.stage=="following": objective.text += " · 接应小雨"
	if world.family.stage=="evacuated": objective.text += " · 家人已撤离"
	var action_y := maxf(build_button.position.y,objective.position.y+maxf(objective.size.y,objective.get_combined_minimum_size().y)+14)
	build_button.position.y = action_y
	quest_button.position.y = action_y
	context.visible = current_modal.is_empty()
	if OS.has_feature("web"):
		world.publish_telemetry()

func _direction(degrees: float) -> String:
	return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int((degrees + 22.5) / 45.0) % 8]

func button_regions() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for button in find_children("*", "Button", true, false):
		if button.is_visible_in_tree() and not button.is_queued_for_deletion():
			var rect: Rect2 = button.get_global_rect()
			var clipped := rect
			var parent := button.get_parent()
			while parent != null and parent != self:
				if parent is Control and parent.clip_contents:
					clipped = clipped.intersection(parent.get_global_rect())
				parent = parent.get_parent()
			result.append({"text": button.text, "rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y],"clip":[clipped.position.x,clipped.position.y,clipped.size.x,clipped.size.y]})
	return result

func _touch_over_ui(at: Vector2) -> bool:
	if not current_modal.is_empty():
		return true
	for button in [settings_button, inventory_button, build_button, quest_button]:
		if is_instance_valid(button) and button.is_visible_in_tree() and button.get_global_rect().has_point(at):
			return true
	return false

func _inventory_changed() -> void:
	inventory_button.text = "背包  %d" % InventorySystem.total()
	if current_modal == "inventory":
		call_deferred("_refresh_inventory")

func _refresh_inventory() -> void:
	if current_modal == "inventory":
		show_inventory()

func flash_damage() -> void:
	flash_time = 0.4

func show_survival_settings() -> void:
	SurvivalMenus.settings(self)

func show_incapacitated() -> void:
	SurvivalMenus.incapacitated(self)

func toast(message: String) -> void:
	toast_label.text = message
	toast_time = 4.5
	if is_instance_valid(status_note):
		status_note.text = message

func _save_result(_success: bool, message: String) -> void:
	toast(message)

func _open(kind: String, title: String, subtitle: String) -> void:
	if is_instance_valid(modal):
		remove_child(modal)
		modal.queue_free()
	if is_instance_valid(close_button):
		remove_child(close_button)
		close_button.queue_free()
	status_note = null
	current_modal = kind
	controls.set_enabled(false)
	get_tree().paused = true
	shade.visible = true
	modal = PanelContainer.new()
	modal.add_theme_stylebox_override("panel", _style(Color("142627"), Color("69756a"), 1, 12))
	add_child(modal)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	modal.add_child(scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 13)
	scroll.add_child(content)
	content.add_child(_label(title, 33))
	var note := _label(subtitle, 20, MUTED)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(note)
	close_button = _button("×", close_modal)
	close_button.custom_minimum_size = Vector2(50, 50)
	add_child(close_button)
	_layout()

func _paragraph(text: String, size_px: int = 22) -> Label:
	var label := _label(text, size_px)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(label)
	return label

func close_modal() -> void:
	if not world.player.survival.alive():
		controls.set_enabled(false)
		get_tree().paused = true
		if current_modal != "incapacitated":
			call_deferred("show_incapacitated")
		return
	if world.awaiting_session_choice:
		# Closing a menu is not a session choice: go back to the title, keep saves blocked.
		controls.set_enabled(false)
		get_tree().paused = true
		if current_modal != "welcome":
			call_deferred("show_welcome")
		return
	if is_instance_valid(modal):
		modal.queue_free()
	modal = null
	if is_instance_valid(close_button):
		close_button.queue_free()
	close_button = null
	status_note = null
	current_modal = ""
	shade.visible = false
	controls.set_enabled(true)
	get_tree().paused = false
	world.atmosphere.start_audio()
	_inventory_changed()

func show_welcome() -> void:
	_open("welcome", "末日十州   /   LAST DAWN", "第二阶段 · 剩余批次 / 独立测试 0.2.3    ·    灰松州")
	_paragraph("公路尽头还有人点着灯。\n探索灰松郊区，寻找食品与材料，和营地守望者取得联系。", 25)
	_paragraph("左侧摇杆移动 · 右侧滑动转向\n右下角跳跃 / 奔跑 / 交互 · ＋ − 调整相机距离\n顶部打开背包与设置；建议横屏游玩。", 22)
	_paragraph("森林采木、矿石采矿，左侧建造可放置避难所、围墙与篝火。\n营地北侧商人周交换物资；修车厂西侧小雨等你接应，任务页可查看位置。\n感染者会听声并攻击；目前无玩家武器。昼夜天气会变化，夜晚有局部照明。\n本测试版独立存档，稳定版进度留在原入口。", 19)
	if SaveManager.exists():
		content.add_child(_button("继续本机存档", func():
			if SaveManager.load_world(world):
				close_modal()
		, true))
		content.add_child(_button("开始新游戏", func(): call_deferred("confirm_new_game")))
	else:
		content.add_child(_button("进入灰松郊区", start_new_game, true))
	status_note = _paragraph("", 18)

func confirm_new_game() -> void:
	_open("new_game_confirm", "开始新游戏？ / NEW GAME", "本机已有存档。确认前，存档与备份都保持不变。")
	_paragraph("确认后，下一次保存（每45秒自动保存、切到后台或点保存进度）会用新进度替换本机存档，再下一次保存会替换备份，原进度无法找回。", 22)
	content.add_child(_button("取消，返回上一页", func(): call_deferred("show_welcome"), true))
	content.add_child(_button("确认开始新游戏", start_new_game))

func start_new_game() -> void:
	world.start_new_session()
	close_modal()

func show_inventory() -> void:
	_open("inventory", "行囊   /   SUPPLIES", "24 格行囊，物品按类型自动堆叠；旧档超容量仍保留全部物品。")
	var consumables := HBoxContainer.new()
	consumables.add_theme_constant_override("separation", 12)
	content.add_child(consumables)
	for id in ["food", "water"]:
		var item_id: String = id
		var use_button := _button("使用%s × %d" % [InventorySystem.ITEMS[id]["name"], InventorySystem.items[id]], func(): world.use_item(item_id))
		use_button.disabled = InventorySystem.items[id] <= 0 or not world.player.survival.can_consume(id)
		consumables.add_child(use_button)
	_paragraph("背包格数 %d / %d" % [InventorySystem.slots_used(),InventorySystem.MAX_SLOTS],21)
	for id in InventorySystem.ITEMS:
		var item: Dictionary = InventorySystem.ITEMS[id]
		_paragraph("%s     × %d" % [item["name"], InventorySystem.items[id]], 28)
		_paragraph(item["description"], 19)
	status_note = _paragraph("附近物资出现交互提示时，点击右侧「交互」。", 20)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	content.add_child(row)
	row.add_child(_button("保存进度", func(): SaveManager.save_world(world)))
	row.add_child(_button("返回游戏", close_modal, true))

func show_settings() -> void:
	if current_modal == "settings":
		close_modal()
		return
	_open("settings", "野外终端   /   SETTINGS", "选择的是帧率上限，实际表现以顶部 FPS 实测为准。")
	_paragraph("画质", 23)
	var qualities := HBoxContainer.new()
	qualities.add_theme_constant_override("separation", 8)
	content.add_child(qualities)
	for i in range(5):
		var level := i
		var text: String = GraphicsManager.LABELS[i] + (" ✓" if i == GraphicsManager.quality else "")
		qualities.add_child(_button(text, func():
			GraphicsManager.set_quality(level)
			call_deferred("_refresh_settings")
		, i == GraphicsManager.quality))
	var fps_header := HBoxContainer.new()
	content.add_child(fps_header)
	fps_header.add_child(_label("帧率上限", 23))
	fps_header.add_child(_button("性能诊断", func(): call_deferred("show_performance")))
	var rates := HBoxContainer.new()
	rates.add_theme_constant_override("separation", 8)
	content.add_child(rates)
	for fps in GraphicsManager.FRAME_RATES:
		var cap: int = fps
		rates.add_child(_button(str(fps) + ("*" if fps == 120 and OS.has_feature("web") else "") + (" ✓" if fps == GraphicsManager.target_fps else ""), func():
			GraphicsManager.set_frame_rate(cap)
			call_deferred("_refresh_settings")
		, fps == GraphicsManager.target_fps))
	var preset := GraphicsManager.preset()
	_paragraph("当前内部渲染 %.0f%% · 可视距离 %d m · 植被 %.0f%%\n画质会同时调整阴影、粒子和模型 LOD。设备温度与刷新率也会影响帧率。" % [preset["scale"] * 100, int(preset["distance"]), preset["foliage"] * 100], 18)
	var sensitivity_row := HBoxContainer.new()
	content.add_child(sensitivity_row)
	sensitivity_row.add_child(_label("视角灵敏度  ", 20))
	var slider := HSlider.new()
	slider.min_value = 0.001
	slider.max_value = 0.009
	slider.step = 0.0002
	slider.value = GraphicsManager.sensitivity
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size.y = 38
	slider.value_changed.connect(func(value: float):
		GraphicsManager.sensitivity = value
		GraphicsManager.persist()
	)
	sensitivity_row.add_child(slider)
	var input_options := HBoxContainer.new()
	input_options.add_theme_constant_override("separation", 18)
	content.add_child(input_options)
	var invert_option := CheckButton.new()
	invert_option.text = "上下方向 (Invert Y)"
	invert_option.custom_minimum_size.y = 52
	invert_option.button_pressed = world.player.rig.invert_y
	invert_option.toggled.connect(world.player.rig.set_invert_y)
	input_options.add_child(invert_option)
	var debug_option := CheckButton.new()
	debug_option.text = "触控调试"
	debug_option.custom_minimum_size.y = 52
	debug_option.button_pressed = world.player.rig.touch_debug_enabled
	debug_option.toggled.connect(world.player.rig.set_touch_debug)
	input_options.add_child(debug_option)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	content.add_child(row)
	row.add_child(_button("保存进度", func(): SaveManager.save_world(world)))
	row.add_child(_button("读取存档", func(): SaveManager.load_world(world)))
	row.add_child(_button("返回营地", func():
		world.player.rescue()
		close_modal()
		toast("已返回营地入口")
	))
	row.add_child(_button("生存设置", func(): call_deferred("show_survival_settings")))
	status_note = _paragraph("设置自动保存。进度每 45 秒及切入后台时尝试保存。" if SaveManager.persistence_available() else "浏览器存储不可用，当前进度和设置无法持久保存。", 18)
	_paragraph("120* 为 Web 实验选项，当前浏览器或设备可能不支持。60 为稳定模式；90 / 120 仍取决于实际能力。", 18)
	performance_readout = _paragraph(PerformanceDiagnostics.summary_text(), 18)
	content.add_child(_button("返回游戏", close_modal, true))

func show_performance() -> void:
	_open("performance", "性能诊断   /   FRAME TIMING", "实时采样，不把选择的上限当作实际帧率。")
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	content.add_child(actions)
	actions.add_child(_button("返回游戏采样", close_modal, true))
	actions.add_child(_button("60 FPS 稳定模式", func(): GraphicsManager.set_frame_rate(60)))
	actions.add_child(_button("返回设置", func(): call_deferred("show_settings")))
	performance_readout = _paragraph(PerformanceDiagnostics.summary_text(), 20)
	_paragraph("统计最近约 10 秒的渲染提交间隔。1% Low = 最慢 1% 间隔的平均值取倒数；至少 100 个间隔且 3 秒才显示。不是物理屏幕呈现计数，也不是 GPU 专用计时。", 18)
	_paragraph("菜单暂停游戏逻辑，读数可能比游玩时高。先返回游戏走动 15 秒，再打开诊断查看「上次游戏窗口」。后台、失焦、切画质和帧率后重新采样。", 18)
	if OS.has_feature("web"):
		_paragraph("rAF 由浏览器调度，同样可能受主线程 / 渲染负载拖慢。请另开轻量 rAF 测试页作对照，不能仅凭 60 FPS 判断是 Safari 限制还是 GPU 不足。低电量、限制帧速率、屏幕型号需要人工核对。", 18)
		content.add_child(_button("打开轻量 rAF 测试页", func(): OS.shell_open("fps-probe.html")))

func _refresh_settings() -> void:
	# Rebuild after GUI input propagation, so the clicked control stays in-tree until dispatch ends.
	if current_modal == "settings":
		current_modal = ""
		show_settings()

func show_npc() -> void:
	_open("npc", "守望者 · 林   /   SAFE HAVEN", "营地无线电仍有信号。这里暂时安全。")
	_paragraph("「沿公路向北有超市。东侧森林的树木能采木，矿石能采石头和矿物。采集与奔跑会引来感染者，别靠太近。」", 25)
	_paragraph("「先活过今晚。更多州的道路还没恢复，政府、职业和制作系统会在后续阶段接入。」", 22)
	_paragraph("饱食和饮水充足时，在安全区休息可恢复生命。先拾取入口旁的食品与饮水；设置中可以调整生存数值。", 20)
	content.add_child(_button("收到，继续探索", close_modal, true))

func show_building() -> void:
	if not world.buildings.selected.is_empty():
		world.buildings.cancel()
		return
	BuildingMenus.show(self)

func begin_building(kind: String) -> void:
	close_modal()
	if world.player.survival.alive(): world.buildings.begin(kind)

func show_trading() -> void:
	TradingMenus.show(self)

func refresh_trading() -> void:
	if current_modal=="trading": show_trading()

func show_family() -> void:
	QuestMenus.show(self)

func family_follow() -> void:
	if world.family.start_following(): close_modal()
