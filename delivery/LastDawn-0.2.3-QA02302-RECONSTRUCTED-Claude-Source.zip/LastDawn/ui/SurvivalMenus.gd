class_name SurvivalMenus
extends RefCounted
## Small batch-one UI extension; reuses the existing modal and touch ownership rules.
const OPTIONS := [
	["hunger_per_minute", "饱食消耗 / 分", 0.1], ["thirst_per_minute", "饮水消耗 / 分", 0.1],
	["sprint_drain", "奔跑体力 / 秒", 1.0], ["stamina_regen", "体力恢复 / 秒", 1.0],
	["starvation_damage", "饥饿伤害 / 秒", 0.05], ["dehydration_damage", "缺水伤害 / 秒", 0.05],
	["safe_heal", "安全区生命恢复 / 秒", 0.1], ["zombie_damage", "感染者每次伤害", 1.0],
	["attack_interval", "感染者攻击间隔 / 秒", 0.1], ["gather_cost", "采集体力 / 次", 1.0]
]
static func settings(hud: Control) -> void:
	hud._open("survival_settings", "生存设置 / SURVIVAL", "数值即时生效并保存。饱食和饮水数值越高越好；菜单打开时暂停消耗。")
	var system: SurvivalSystem = hud.world.player.survival
	for option in OPTIONS:
		var key: String = option[0]
		var title: String = option[1]
		var row := VBoxContainer.new()
		hud.content.add_child(row)
		var label: Label = hud._label("%s   %.2f" % [title, system.settings[key]], 20)
		row.add_child(label)
		var slider := HSlider.new()
		var bounds: Vector2 = SurvivalSystem.LIMITS[key]
		slider.min_value = bounds.x
		slider.max_value = bounds.y
		slider.step = float(option[2])
		slider.value = system.settings[key]
		slider.custom_minimum_size = Vector2(0, 46)
		slider.value_changed.connect(func(value: float):
			var changed := system.settings.duplicate()
			changed[key] = value
			system.apply_settings(changed)
			label.text = "%s   %.2f" % [title, value]
		)
		row.add_child(slider)
	hud.content.add_child(hud._button("恢复默认生存设置", func():
		system.apply_settings(SurvivalSystem.DEFAULTS)
		hud.call_deferred("show_survival_settings")
	))
	hud.content.add_child(hud._button("返回游戏", hud.close_modal, true))

static func incapacitated(hud: Control) -> void:
	if hud.world.player.survival.alive():
		return
	hud._open("incapacitated", "失去行动能力 / RECOVERY", "本批提供安全区恢复，背包物资保留。")
	hud._paragraph("避开感染者的近距离攻击，及时使用食品和饮水。饱食或饮水为零会持续损失生命。", 24)
	hud.content.add_child(hud._button("在安全区恢复", func():
		hud.world.player.rescue()
		hud.close_modal()
		hud.toast("已在安全区恢复，休息可继续恢复生命")
	, true))
	hud.content.add_child(hud._button("读取存档", func(): SaveManager.load_world(hud.world)))
