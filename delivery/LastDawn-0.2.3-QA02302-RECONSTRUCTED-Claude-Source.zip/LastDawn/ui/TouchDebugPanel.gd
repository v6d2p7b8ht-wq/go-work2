class_name TouchDebugPanel
extends PanelContainer
## Optional, read-only diagnostics. It does not capture input or change camera transforms.
var manager: TouchInputManager
var rig: CameraController
var text_label: Label
var refresh_clock := 0.0
var was_visible := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.07, 0.075, 0.88)
	style.border_color = Color("819a81")
	style.set_border_width_all(1)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	add_theme_stylebox_override("panel", style)
	text_label = Label.new()
	text_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	text_label.add_theme_font_size_override("font_size", 16)
	text_label.add_theme_color_override("font_color", Color("d4ddc2"))
	add_child(text_label)
	visible = false

func _process(delta: float) -> void:
	if not is_instance_valid(rig) or not is_instance_valid(manager):
		return
	visible = rig.touch_debug_enabled
	if not visible:
		if was_visible and OS.has_feature("web"):
			JavaScriptBridge.eval("window.lastDawnTouchDebug = null;", true)
		was_visible = false
		return
	was_visible = true
	refresh_clock -= delta
	if refresh_clock > 0:
		return
	refresh_clock = 0.1
	position = Vector2(28, 245)
	custom_minimum_size.x = minf(590, get_parent().size.x - 56)
	var data := manager.debug_snapshot()
	data["yaw"] = rig.yaw
	data["pitch"] = rig.pitch
	data["invert_y"] = rig.invert_y
	data["sensitivity"] = GraphicsManager.sensitivity
	var lines := PackedStringArray()
	lines.append("TOUCH DEBUG | count %d | epoch %d" % [data["count"], data["generation"]])
	for pointer in data["pointers"]:
		lines.append("index %s  %s  rel %s" % [pointer["index"], pointer["purpose"], pointer["relative"]])
	lines.append("ScreenDrag.relative %s | accepted %s" % [data["relative"], data["accepted_relative"]])
	lines.append("Yaw %.2f deg | Pitch %.2f deg | invert Y %s" % [rad_to_deg(rig.yaw), rad_to_deg(rig.pitch), rig.invert_y])
	lines.append("Viewport %s | source %s" % [data["viewport"], data["source"]])
	lines.append("drag OK %d / ignored %d | mouse ignored %d" % [data["accepted_drags"], data["rejected_drags"], data["ignored_mouse"]])
	lines.append("reset: %s | %.4f rad / logical px" % [data["last_reset"], GraphicsManager.sensitivity])
	if OS.has_feature("web"):
		var metrics_json = JavaScriptBridge.eval("JSON.stringify(window.lastDawnInputMetrics || {})", true)
		var parsed = JSON.parse_string(String(metrics_json))
		if parsed is Dictionary:
			data["browser"] = parsed
			lines.append("CSS %s / backing %s | DPR %s" % [parsed.get("css", []), parsed.get("backing", []), parsed.get("dpr", 1)])
		JavaScriptBridge.eval("window.lastDawnTouchDebug = " + JSON.stringify(data) + ";", true)
	text_label.text = "\n".join(lines)
