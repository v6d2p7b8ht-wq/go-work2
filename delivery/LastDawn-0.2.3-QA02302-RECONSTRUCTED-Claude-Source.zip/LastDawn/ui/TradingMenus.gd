class_name TradingMenus
extends RefCounted

static func show(hud: SurvivalHUD) -> void:
	var trader: TradingSystem = hud.world.trader
	hud._open("trading","流浪商人 · 周 / BARTER","库存会随交易变化；游玩每五分钟补货。菜单暂停时不计时，交易结果随存档保存。")
	hud.status_note = hud._paragraph(trader.last_message if not trader.last_message.is_empty() else "蓝图为虚构的曙光护具原型图，目前作为物品保存，不解锁未实现的装备系统。",18)
	for id in TradingSystem.OFFERS:
		var offer_id: String = id
		var offer: Dictionary = TradingSystem.OFFERS[id]
		var item: String = offer["reward"].keys()[0]
		hud._paragraph("%s · 库存 %d" % [InventorySystem.ITEMS[item]["name"],trader.stock[item]],22)
		hud.content.add_child(hud._button(offer["name"]+" · "+BuildingMenus.cost_text(offer["cost"]),func():
			trader.trade(offer_id)
			hud.call_deferred("refresh_trading")
		))
	hud.content.add_child(hud._button("继续探索",hud.close_modal,true))
