extends Node
## QA02302-01 RECONSTRUCTION (not the recovered original): while incapacitated, family
## wait/claim commands are refused and their UI buttons are disabled; after recovery the
## reward is still granted exactly once. Runs on unfixed QA02301 to separate before/after.
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func settle() -> void:
	for i in range(3): await get_tree().process_frame
func button(text: String) -> Button:
	for node in world.hud.content.find_children("*","Button",true,false):
		if node.text==text and not node.is_queued_for_deletion(): return node
	return null
func family_menu() -> void:
	world.hud.show_family()
	await settle()
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("run")
func run() -> void:
	InventorySystem.restore({})
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	await settle()
	var player := world.player
	var quest := world.family
	player.set_physics_process(false)
	quest.set_process(false)
	quest.member.set_physics_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
	world.set_process(false)
	player.position = FamilyCompanion.HOME+Vector3(0,0,1)
	expect(quest.start_following() and quest.stage=="following","Setup: escort started while alive and in range")
	player.survival.health = 0.0
	expect(not quest.wait_here() and quest.stage=="following","Incapacitated: wait command is refused and the stage is unchanged")
	await family_menu()
	var wait := button("在这里等我")
	expect(wait!=null and wait.disabled,"Incapacitated: the wait button is disabled")
	quest.stage = "waiting"
	await family_menu()
	var follow := button("跟我去安全区")
	expect(follow!=null and follow.disabled and not quest.start_following() and quest.stage=="waiting","Incapacitated: follow is refused and its button is disabled")
	quest.stage = "evacuated"
	quest.reward_claimed = false
	var before := InventorySystem.snapshot()
	expect(not quest.claim_reward() and not quest.reward_claimed and InventorySystem.snapshot()==before,"Incapacitated: claim is refused, no items granted, reward stays pending")
	await family_menu()
	var claim := button("领取撤离补给")
	expect(claim!=null and claim.disabled,"Incapacitated: the claim button is disabled")
	quest.stage = "following"
	quest.reward_claimed = false
	quest.arrival_time = 0
	quest.member.position = Vector3(20,quest.member.position.y,36)
	player.position = Vector3(21,player.position.y,36)
	quest.check_arrival(3.0)
	expect(quest.stage=="following" and not quest.reward_claimed,"Incapacitated: arrival in camp does not complete evacuation or grant the reward")
	world.hud.close_modal()
	await settle()
	player.survival.recover()
	quest.stage = "evacuated"
	quest.reward_claimed = false
	before = InventorySystem.snapshot()
	await family_menu()
	claim = button("领取撤离补给")
	expect(claim!=null and not claim.disabled,"Recovered: the claim button is enabled")
	claim.pressed.emit()
	await settle()
	expect(quest.reward_claimed and InventorySystem.items["food"]==int(before.get("food",0))+2 and InventorySystem.items["water"]==int(before.get("water",0))+2,"Recovered: the pending reward is granted once (food +2, water +2)")
	var after := InventorySystem.snapshot()
	expect(not quest.claim_reward() and InventorySystem.snapshot()==after,"Recovered: a second claim grants nothing")
	quest.stage = "following"
	player.position = quest.member.position+Vector3(0,0,1)
	expect(quest.wait_here() and quest.stage=="waiting","Recovered: the wait command works again")
	world.hud.close_modal()
	print("RESULT | %d family incapacitation-gate checks | %d failures" % [checks,failures])
	get_tree().paused = false
	get_tree().quit(1 if failures>0 else 0)
