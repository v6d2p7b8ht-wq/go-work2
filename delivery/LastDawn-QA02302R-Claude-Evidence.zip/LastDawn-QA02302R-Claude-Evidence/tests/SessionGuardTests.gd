extends Node
## LD-01/LD-02/LD-03 (reconstruction): the title's fresh world must never replace real progress.
## Only a successful Continue or a confirmed Start New Game may enable saving. Runs on the
## unfixed QA02301 too (missing title actions simply fail), so it separates before/after.
var checks := 0
var failures := 0
var world: WorldManager
func expect(ok: bool, label: String) -> void:
	checks += 1
	print("PASS | " if ok else "FAIL | ",label)
	if not ok: failures += 1
func wipe() -> void:
	for path in [SaveManager.SAVE_PATH,SaveManager.SAVE_PATH+".bak",SaveManager.SAVE_PATH+".tmp"]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
func raw(path: String, text: String) -> void:
	var file := FileAccess.open(path,FileAccess.WRITE)
	file.store_string(text)
	file.close()
func files() -> Array:
	return [FileAccess.get_file_as_bytes(SaveManager.SAVE_PATH),FileAccess.get_file_as_bytes(SaveManager.SAVE_PATH+".bak")]
func disk_wood(path: String) -> Variant:
	return SaveManager._read_candidate(path).get("inventory",{}).get("wood")
func freeze() -> void:
	world.set_process(false)
	world.player.set_physics_process(false)
	world.family.set_process(false)
	world.family.member.set_physics_process(false)
	world.clock.set_process(false)
	world.trader.set_process(false)
	for zombie in world.zombies: zombie.set_physics_process(false)
func settle() -> void:
	for i in range(3): await get_tree().process_frame
func reload() -> void:
	# A page reload restarts autoloads; reproduce their fresh state before the new world exists.
	if is_instance_valid(world):
		remove_child(world)
		world.free()
	get_tree().paused = false
	InventorySystem.restore({})
	world = load("res://scenes/Main.tscn").instantiate()
	add_child(world)
	freeze()
	await settle()
func title() -> void:
	# Same entry the non-headless game uses at startup.
	if world.has_method("open_title"): world.call("open_title")
	else: world.hud.call_deferred("show_welcome")
	await settle()
func buttons() -> Array[String]:
	var result: Array[String] = []
	if is_instance_valid(world.hud.content):
		for button in world.hud.content.find_children("*","Button",true,false):
			if not button.is_queued_for_deletion(): result.append(button.text)
	return result
func press(text: String) -> bool:
	if not is_instance_valid(world.hud.content): return false
	for button in world.hud.content.find_children("*","Button",true,false):
		if button.text==text and not button.is_queued_for_deletion() and not button.disabled:
			button.pressed.emit()
			await settle()
			return true
	return false
func touch_held() -> void:
	var manager := world.hud.controls.touch_manager
	manager.contacts[7] = {"role":"joystick","position":Vector2(120,600),"relative":Vector2.ZERO,"generation":manager.generation}
	manager.joystick_touch = 7
	manager.stick = Vector2(1,0)
	world.hud.controls.sprint_toggled = true
func touch_clean() -> bool:
	var manager := world.hud.controls.touch_manager
	return manager.contacts.is_empty() and manager.joystick_touch==-1 and manager.stick==Vector2.ZERO and not world.hud.controls.sprint_toggled
func backgrounded() -> void:
	world._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
func protected() -> bool:
	var waiting = world.get("awaiting_session_choice")
	return waiting is bool and waiting
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	call_deferred("run")
func run() -> void:
	wipe()
	await reload()
	InventorySystem.restore({"wood":17,"stone":5,"food":3})
	world.picked["s01_loot_00"] = true
	var seeded := SaveManager.save_world(world)
	InventorySystem.add_item("wood",4)
	seeded = SaveManager.save_world(world) and seeded
	expect(seeded and disk_wood(SaveManager.SAVE_PATH)==21.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==17.0,"Seed: primary wood 21, backup wood 17")
	var original := files()
	# --- Title over an existing save ---
	await reload()
	await title()
	var labels := buttons()
	expect(world.hud.current_modal=="welcome" and InventorySystem.items["wood"]==0,"Title runs a fresh world over an existing save")
	expect("继续本机存档" in labels and "开始新游戏" in labels and "进入灰松郊区" not in labels,"With a save, the title offers Continue and an explicit Start New Game only")
	touch_held()
	backgrounded()
	backgrounded()
	expect(files()==original,"LD-01: two background transitions on the title leave both save files unchanged")
	expect(touch_clean(),"Background on the title still clears touch ownership although saving is blocked")
	world.autosave_clock = 0
	world._process(0.016)
	expect(files()==original,"LD-01: an autosave tick on the title leaves both save files unchanged")
	expect(not SaveManager.save_world(world) and files()==original,"A manual save request on the title is refused and changes nothing")
	# Settings over the title, then closed: no implicit session.
	world.hud.show_settings()
	await settle()
	var settings_save := await press("保存进度")
	expect(settings_save and files()==original,"Settings' Save button on the title writes nothing")
	world.hud.close_modal()
	await settle()
	expect(world.hud.current_modal=="welcome" and protected(),"Closing Settings returns to the title and keeps protection")
	backgrounded()
	expect(files()==original,"After closing Settings, background still leaves both save files unchanged")
	# Dismissing the title itself.
	world.hud.close_modal()
	await settle()
	backgrounded()
	expect(world.hud.current_modal=="welcome" and protected() and files()==original,"Dismissing the title keeps it open, protected, files unchanged")
	# Start New Game requires confirmation; cancel and × both keep everything.
	var asked := await press("开始新游戏")
	expect(asked and world.hud.current_modal=="new_game_confirm" and files()==original,"LD-02: Start New Game with a save asks for confirmation first")
	backgrounded()
	expect(files()==original and protected(),"LD-02: background during the confirmation changes nothing")
	var cancelled := await press("取消，返回上一页")
	backgrounded()
	expect(cancelled and world.hud.current_modal=="welcome" and protected() and files()==original,"LD-02: Cancel returns to the title; both files unchanged; protection kept")
	await press("开始新游戏")
	world.hud.close_modal()
	await settle()
	backgrounded()
	expect(world.hud.current_modal=="welcome" and protected() and files()==original,"LD-02: closing the confirmation acts as Cancel")
	# Continue restores and re-enables saving.
	var continued := await press("继续本机存档")
	expect(continued and world.hud.current_modal=="" and not protected() and InventorySystem.items["wood"]==21 and world.picked.has("s01_loot_00") and files()==original,"Continue restores the real progress without writing")
	InventorySystem.add_item("wood",1)
	backgrounded()
	expect(disk_wood(SaveManager.SAVE_PATH)==22.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==21.0,"After Continue, background saves resume and rotate normally")
	# Confirmed new game is the only path that replaces progress.
	await reload()
	await title()
	await press("开始新游戏")
	var confirmed := await press("确认开始新游戏")
	expect(confirmed and world.hud.current_modal=="" and not protected() and InventorySystem.items["wood"]==0,"LD-02: confirmed Start New Game begins a fresh session")
	backgrounded()
	expect(disk_wood(SaveManager.SAVE_PATH)==0.0 and disk_wood(SaveManager.SAVE_PATH+".bak")==22.0,"LD-02: only after confirmation does saving replace the primary (backup keeps prior progress)")
	# A failed Continue keeps protection.
	raw(SaveManager.SAVE_PATH,"{broken")
	raw(SaveManager.SAVE_PATH+".bak","{also broken")
	var unreadable := files()
	await reload()
	await title()
	var failed := await press("继续本机存档")
	backgrounded()
	world.autosave_clock = 0
	world._process(0.016)
	expect(failed and world.hud.current_modal=="welcome" and protected() and files()==unreadable,"Failed Continue stays on the title and writes nothing")
	expect(is_instance_valid(world.hud.status_note) and not world.hud.status_note.text.is_empty(),"Failed Continue shows its reason on the title")
	# A brand-new player is not blocked.
	wipe()
	await reload()
	await title()
	labels = buttons()
	expect("继续本机存档" not in labels and "开始新游戏" not in labels and "进入灰松郊区" in labels,"Without a save, the title offers Enter only")
	var entered := await press("进入灰松郊区")
	InventorySystem.add_item("wood",3)
	backgrounded()
	expect(entered and world.hud.current_modal=="" and disk_wood(SaveManager.SAVE_PATH)==3.0,"New player enters without confirmation and the first background save is written")
	# LD-03
	var legacy := {"version":1,"state_id":5,"position":[4,0.5,31],"inventory":{"wood":1},"settings":{},"picked":[],"stamina":100}
	expect(not SaveManager.valid_snapshot(legacy),"LD-03: legacy file with numeric state_id is rejected")
	wipe()
	print("RESULT | %d session-guard checks | %d failures" % [checks,failures])
	get_tree().paused = false
	get_tree().quit(1 if failures>0 else 0)
