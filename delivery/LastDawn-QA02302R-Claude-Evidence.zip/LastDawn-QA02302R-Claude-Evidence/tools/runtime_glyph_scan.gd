extends SceneTree
func _init() -> void:
	var font = load("res://assets/fonts/LastDawnSans.ttf")
	for dir in ["res://scripts","res://systems","res://ui"]:
		for file in DirAccess.get_files_at(dir):
			if not file.ends_with(".gd"): continue
			var missing := ""
			for character in FileAccess.get_file_as_string(dir+"/"+file):
				var c: int = character.unicode_at(0)
				if c >= 0x3400 and c <= 0x9fff and not font.has_char(c) and not missing.contains(character): missing += character
			if not missing.is_empty(): print("MISSING | ", dir, "/", file, " | ", missing)
	print("GLYPH SCAN DONE")
	quit()
